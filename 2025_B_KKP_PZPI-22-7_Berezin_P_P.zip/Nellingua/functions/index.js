const functions = require('firebase-functions');
const speech = require('@google-cloud/speech');
const fetch = require('node-fetch');

// Використовуємо дефолтні облікові дані, тому keyFilename не потрібен
const client = new speech.SpeechClient();

exports.recognizeSpeech = functions.https.onCall(async (data, context) => {
	// Якщо payload прийшов у полі data.data, беремо звідти
	const payload = data.data !== undefined ? data.data : data;

	console.log('recognizeSpeech отримав payload:', payload);

	const audioUrl = payload.audioUrl;
	const language = payload.language || 'pl-PL';

	if (!audioUrl) {
		console.error('!!! Помилка: audioUrl =', audioUrl);
		throw new functions.https.HttpsError('invalid-argument', 'audioUrl не передано');
	}

	try {
		console.log('recognizeSpeech: робимо fetch за', audioUrl);
		const response = await fetch(audioUrl);
		console.log('recognizeSpeech: fetch статус =', response.status);

		const buffer = await response.buffer();
		console.log('recognizeSpeech: отримано buffer, size=', buffer.length);

		const audioBytes = buffer.toString('base64');
		console.log('recognizeSpeech: base64 length =', audioBytes.length);

		const [result] = await client.recognize({
			audio: { content: audioBytes },
			config: {
				encoding: 'WEBM_OPUS',
				sampleRateHertz: 48000,
				languageCode: language,
				enableAutomaticPunctuation: true
			}
		});
		console.log('recognizeSpeech: client.recognize завершився, result=', result);

		const transcription = result.results.map((r) => r.alternatives[0].transcript).join(' ');
		console.log('recognizeSpeech: передаю транскрипт:', transcription);

		return { transcript: transcription };
	} catch (e) {
		console.error('recognizeSpeech: поймали помилку:', e);
		throw new functions.https.HttpsError('internal', 'Speech recognition failed');
	}
});