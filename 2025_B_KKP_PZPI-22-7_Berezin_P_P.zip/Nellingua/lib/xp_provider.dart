import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class XpProvider extends ChangeNotifier {
  int _xp = 0;
  int _gems = 0;
  double _xpMultiplier = 1.0;
  int? _multiplierEndTimestamp; // Unix timestamp in milliseconds
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  XpProvider() {
    initialize();
  }

  int get xp => _xp;
  int get gems => _gems;
  double get xpMultiplier => _xpMultiplier;
  int? get multiplierEndTimestamp => _multiplierEndTimestamp; // Public getter for _multiplierEndTimestamp
  bool get hasActiveMultiplier => _multiplierEndTimestamp != null && _multiplierEndTimestamp! > DateTime.now().millisecondsSinceEpoch;

  Future<void> initialize() async {
    final user = _auth.currentUser;
    if (user == null) {
      print('[DEBUG] XpProvider.initialize: No user, using default XP and gems');
      return;
    }
    await _loadUserData(user.uid);
    _checkMultiplierExpiration();
  }

  Future<void> _loadUserData(String userId) async {
    try {
      final doc = await _db.collection('users').doc(userId).get();
      final data = doc.data();
      if (data != null) {
        _xp = (data['xp'] as num?)?.toInt() ?? 0;
        _gems = (data['gems'] as num?)?.toInt() ?? 0;
        _xpMultiplier = (data['xpMultiplier'] as num?)?.toDouble() ?? 1.0;
        _multiplierEndTimestamp = data['xpMultiplierEnd'] as int?;
        print('[DEBUG] XpProvider._loadUserData: Loaded XP=$_xp, Gems=$_gems, Multiplier=$_xpMultiplier, EndTimestamp=$_multiplierEndTimestamp');
        notifyListeners();
      }
    } catch (e) {
      print('[DEBUG] XpProvider._loadUserData error: $e');
    }
  }

  Future<void> _saveUserData() async {
    final user = _auth.currentUser;
    if (user == null) {
      print('[DEBUG] XpProvider._saveUserData: No authenticated user');
      return;
    }
    try {
      await _db.collection('users').doc(user.uid).set({
        'xp': _xp,
        'gems': _gems,
        'xpMultiplier': _xpMultiplier,
        'xpMultiplierEnd': _multiplierEndTimestamp,
      }, SetOptions(merge: true));
      print('[DEBUG] XpProvider._saveUserData: Saved XP=$_xp, Gems=$_gems, Multiplier=$_xpMultiplier, EndTimestamp=$_multiplierEndTimestamp');
    } catch (e) {
      print('[DEBUG] XpProvider._saveUserData error: $e');
    }
  }

  void _checkMultiplierExpiration() {
    if (_multiplierEndTimestamp != null && _multiplierEndTimestamp! <= DateTime.now().millisecondsSinceEpoch) {
      _xpMultiplier = 1.0;
      _multiplierEndTimestamp = null;
      _saveUserData();
      notifyListeners();
      print('[DEBUG] XpProvider._checkMultiplierExpiration: Multiplier expired, reset to 1.0');
    }
  }

  Future<void> awardXp(String type, {bool isRepeat = false}) async {
    _checkMultiplierExpiration();
    int baseXp = 0;
    switch (type) {
      case 'theory_lesson':
        baseXp = isRepeat ? 1 : 5;
        break;
      case 'theory_level':
        baseXp = isRepeat ? 1 : 15;
        break;
      case 'practice_lesson':
        baseXp = isRepeat ? 1 : 10;
        break;
      case 'practice_level':
        baseXp = isRepeat ? 1 : 30;
        break;
      case 'unit':
        baseXp = isRepeat ? 1 : 50;
        break;
      default:
        print('[DEBUG] XpProvider.awardXp: Unknown type $type');
        return;
    }
    final totalXp = (baseXp * _xpMultiplier).round();
    _xp += totalXp;
    await _saveUserData();
    notifyListeners();
    print('[DEBUG] XpProvider.awardXp: Awarded $totalXp XP (base=$baseXp, multiplier=$_xpMultiplier) for $type');
  }

  Future<bool> purchaseMultiplier(double multiplier, int durationMinutes, int gemCost) async {
    if (_gems < gemCost) {
      print('[DEBUG] XpProvider.purchaseMultiplier: Insufficient gems ($_gems < $gemCost)');
      return false;
    }
    _gems -= gemCost;
    _xpMultiplier = multiplier;
    _multiplierEndTimestamp = DateTime.now().add(Duration(minutes: durationMinutes)).millisecondsSinceEpoch;
    await _saveUserData();
    notifyListeners();
    print('[DEBUG] XpProvider.purchaseMultiplier: Purchased x$multiplier for $durationMinutes minutes, cost=$gemCost gems');
    return true;
  }

  Future<void> awardGems(int amount) async {
    _gems += amount;
    await _saveUserData();
    notifyListeners();
    print('[DEBUG] XpProvider.awardGems: Awarded $amount gems, total=$_gems');
  }
}