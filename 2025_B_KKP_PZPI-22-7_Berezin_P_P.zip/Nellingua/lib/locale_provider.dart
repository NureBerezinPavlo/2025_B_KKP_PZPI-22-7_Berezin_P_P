import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class LocaleProvider extends ChangeNotifier {
  Locale _locale = const Locale('en'); // Резервна мова
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  Locale get locale => _locale;

  Future<void> initialize(String? userId, String? courseId) async {
    if (userId == null || courseId == null) {
      print('[DEBUG] LocaleProvider.initialize: userId or courseId is null, using default locale: ${_locale.languageCode}');
      return;
    }

    await _loadLocale(userId, courseId);
  }

  Future<void> updateLocale(String userId, String courseId) async {
    await _loadLocale(userId, courseId);
  }

  Future<void> _loadLocale(String userId, String courseId) async {
    try {
      final courseDoc = await _db.collection('courses').doc(courseId).get();
      if (!courseDoc.exists) {
        print('[DEBUG] LocaleProvider._loadLocale: Course $courseId not found, keeping locale: ${_locale.languageCode}');
        return;
      }

      final baseLanguage = courseDoc.data()?['base_language'] as String? ?? 'en';
      final newLocale = Locale(baseLanguage);

      if (_locale != newLocale) {
        _locale = newLocale;
        print('[DEBUG] LocaleProvider._loadLocale: Updated locale to $baseLanguage for course $courseId');
        notifyListeners();
      }
    } catch (e) {
      print('[DEBUG] LocaleProvider._loadLocale error: $e');
    }
  }
}