import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class ThemeProvider extends ChangeNotifier {
  ThemeMode _themeMode = ThemeMode.system;
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  ThemeProvider() {}

  ThemeMode get themeMode => _themeMode;

  Future<void> initialize(String? userId) async {
    if (userId == null) {
      print('[DEBUG] ThemeProvider.initialize: No userId, using default ThemeMode.system');
      _themeMode = ThemeMode.system;
      notifyListeners();
      return;
    }

    await _loadThemeMode(userId);
  }

  Future<void> setThemeMode(ThemeMode mode) async {
    _themeMode = mode;
    print('[DEBUG] ThemeProvider.setThemeMode: Notifying listeners with themeMode = $_themeMode');
    notifyListeners();
    await _saveThemeMode();
  }

  Future<void> _loadThemeMode(String userId) async {
    try {
      final doc = await _db.collection('users').doc(userId).get();
      final themeString = doc.data()?['themeMode'] as String?;
      print('[DEBUG] ThemeProvider._loadThemeMode: Loaded themeMode = $themeString for user $userId');

      if (themeString != null) {
        _themeMode = _stringToThemeMode(themeString);
      } else {
        _themeMode = ThemeMode.system;
        print('[DEBUG] ThemeProvider._loadThemeMode: No themeMode found, defaulting to system');
      }
      print('[DEBUG] ThemeProvider._loadThemeMode: Notifying listeners with themeMode = $_themeMode');
      notifyListeners();
    } catch (e, stackTrace) {
      print('[DEBUG] ThemeProvider._loadThemeMode error: $e');
      print('[DEBUG] Stack trace: $stackTrace');
      _themeMode = ThemeMode.system;
      notifyListeners();
    }
  }

  Future<void> _saveThemeMode() async {
    final user = _auth.currentUser;
    if (user == null) {
      print('[DEBUG] ThemeProvider._saveThemeMode: No authenticated user, cannot save themeMode');
      return;
    }

    try {
      final themeString = _themeModeToString(_themeMode);
      await _db.collection('users').doc(user.uid).set(
        {'themeMode': themeString},
        SetOptions(merge: true),
      );
      print('[DEBUG] ThemeProvider._saveThemeMode: Saved themeMode = $themeString for user ${user.uid}');
    } catch (e, stackTrace) {
      print('[DEBUG] ThemeProvider._saveThemeMode error: $e');
      print('[DEBUG] Stack trace: $stackTrace');
    }
  }

  String _themeModeToString(ThemeMode mode) {
    switch (mode) {
      case ThemeMode.light:
        return 'light';
      case ThemeMode.dark:
        return 'dark';
      case ThemeMode.system:
        return 'system';
    }
  }

  ThemeMode _stringToThemeMode(String themeString) {
    switch (themeString) {
      case 'light':
        return ThemeMode.light;
      case 'dark':
        return ThemeMode.dark;
      case 'system':
      default:
        return ThemeMode.system;
    }
  }

  static ThemeData lightTheme = ThemeData(
    useMaterial3: true,
    colorScheme: ColorScheme.fromSeed(
      seedColor: const Color(0xFF58CC02),
      brightness: Brightness.light,
      primary: const Color(0xFF58CC02),
      secondary: const Color(0xFF1CB0F6),
      surface: Colors.white,
      onSurface: Colors.black87,
      error: const Color(0xFFFF3B30),
    ),
    scaffoldBackgroundColor: Colors.white,
    appBarTheme: const AppBarTheme(
      backgroundColor: Colors.white,
      foregroundColor: Colors.black87,
      elevation: 0,
      centerTitle: true,
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: const Color(0xFF58CC02),
        foregroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 24),
        textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
      ),
    ),
    textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(
        foregroundColor: const Color(0xFF1CB0F6),
        textStyle: const TextStyle(fontSize: 16),
      ),
    ),
    textTheme: const TextTheme(
      displayLarge: TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: Colors.black87),
      headlineSmall: TextStyle(fontSize: 24, fontWeight: FontWeight.w600, color: Colors.black87),
      bodyMedium: TextStyle(fontSize: 16, color: Colors.black87),
      bodySmall: TextStyle(fontSize: 14, color: Colors.black54),
    ),
    cardTheme: CardThemeData(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      elevation: 4,
    ),
  );

  static ThemeData darkTheme = ThemeData(
    useMaterial3: true,
    colorScheme: ColorScheme.fromSeed(
      seedColor: const Color(0xFF58CC02),
      brightness: Brightness.dark,
      primary: const Color(0xFF58CC02),
      secondary: const Color(0xFF1CB0F6),
      surface: const Color(0xFF121212),
      onSurface: Colors.white,
      error: const Color(0xFFFF3B30),
    ),
    scaffoldBackgroundColor: const Color(0xFF121212),
    appBarTheme: const AppBarTheme(
      backgroundColor: Color(0xFF1A1A1A),
      foregroundColor: Colors.white,
      elevation: 0,
      centerTitle: true,
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: const Color(0xFF58CC02),
        foregroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 24),
        textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
      ),
    ),
    textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(
        foregroundColor: const Color(0xFF1CB0F6),
        textStyle: const TextStyle(fontSize: 16),
      ),
    ),
    textTheme: const TextTheme(
      displayLarge: TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: Colors.white),
      headlineSmall: TextStyle(fontSize: 24, fontWeight: FontWeight.w600, color: Colors.white),
      bodyMedium: TextStyle(fontSize: 16, color: Colors.white),
      bodySmall: TextStyle(fontSize: 14, color: Colors.white70),
    ),
    cardTheme: CardThemeData(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      elevation: 4,
      color: const Color(0xFF1A1A1A),
    ),
  );
}