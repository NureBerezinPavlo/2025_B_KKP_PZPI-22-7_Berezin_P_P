import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:provider/provider.dart';
import 'firebase_options.dart';
import 'l10n/app_localizations.dart';
import 'models/user_progress_model.dart';
import 'screens/auth_screen.dart';
import 'screens/home_screen.dart';
import 'screens/course_selection_screen.dart';
import 'screens/unit_screen.dart';
import 'screens/settings_screen.dart';
import 'screens/shop_screen.dart';
import 'theme_provider.dart';
import 'locale_provider.dart';
import 'xp_provider.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);

  FirebaseFirestore.instance.settings = const Settings(persistenceEnabled: false);

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => ThemeProvider()),
        ChangeNotifierProvider(create: (_) => LocaleProvider()),
        ChangeNotifierProvider(create: (_) => XpProvider()),
      ],
      child: Builder(
        builder: (context) {
          return StreamBuilder<User?>(
            stream: FirebaseAuth.instance.authStateChanges(),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const MaterialApp(
                  home: Scaffold(
                    body: Center(child: CircularProgressIndicator()),
                  ),
                );
              }

              final user = snapshot.data;
              final themeProvider = Provider.of<ThemeProvider>(context, listen: false);
              final localeProvider = Provider.of<LocaleProvider>(context, listen: false);

              return FutureBuilder<String?>(
                future: _getCurrentCourseId(user?.uid),
                builder: (context, courseSnapshot) {
                  if (courseSnapshot.connectionState == ConnectionState.waiting) {
                    return const MaterialApp(
                      home: Scaffold(
                        body: Center(child: CircularProgressIndicator()),
                      ),
                    );
                  }

                  final userProgress = UserProgressModel(
                    user?.uid ?? '',
                    courseSnapshot.data ?? '',
                  );

                  return MultiProvider(
                    providers: [
                      ChangeNotifierProvider.value(value: userProgress),
                    ],
                    child: FutureBuilder(
                      future: Future.wait([
                        themeProvider.initialize(user?.uid),
                        localeProvider.initialize(user?.uid, courseSnapshot.data),
                      ]),
                      builder: (context, initSnapshot) {
                        if (initSnapshot.connectionState == ConnectionState.waiting) {
                          return const MaterialApp(
                            home: Scaffold(
                              body: Center(child: CircularProgressIndicator()),
                            ),
                          );
                        }

                        return Selector2<ThemeProvider, LocaleProvider, Tuple2<ThemeMode, Locale>>(
                          selector: (_, themeProvider, localeProvider) => Tuple2(themeProvider.themeMode, localeProvider.locale),
                          builder: (context, tuple, child) {
                            return MaterialApp(
                              navigatorKey: UserProgressModel.navigatorKey,
                              title: 'Nellingua',
                              debugShowCheckedModeBanner: false,
                              theme: ThemeProvider.lightTheme,
                              darkTheme: ThemeProvider.darkTheme,
                              themeMode: tuple.item1,
                              locale: tuple.item2,
                              supportedLocales: const [
                                Locale('en'),
                                Locale('uk'),
                                Locale('pl'),
                              ],
                              localizationsDelegates: const [
                                AppLocalizations.delegate,
                                GlobalMaterialLocalizations.delegate,
                                GlobalWidgetsLocalizations.delegate,
                                GlobalCupertinoLocalizations.delegate,
                              ],
                              home: user != null ? const HomeScreen() : const AuthScreen(),
                              routes: {
                                '/home': (context) => const HomeScreen(),
                                '/auth': (context) => const AuthScreen(),
                                '/courses': (context) => const CourseSelectionScreen(),
                                '/unit': (context) => const UnitScreen(),
                                '/settings': (context) => const SettingsScreen(),
                                '/shop': (context) => const ShopScreen(),
                              },
                            );
                          },
                        );
                      },
                    ),
                  );
                },
              );
            },
          );
        },
      ),
    );
  }

  Future<String?> _getCurrentCourseId(String? userId) async {
    if (userId == null) return null;
    try {
      final doc = await FirebaseFirestore.instance.collection('users').doc(userId).get();
      return doc.data()?['currentCourseId'] as String?;
    } catch (e) {
      print('[DEBUG] Error fetching currentCourseId: $e');
      return null;
    }
  }
}

class Tuple2<T1, T2> {
  final T1 item1;
  final T2 item2;

  Tuple2(this.item1, this.item2);
}