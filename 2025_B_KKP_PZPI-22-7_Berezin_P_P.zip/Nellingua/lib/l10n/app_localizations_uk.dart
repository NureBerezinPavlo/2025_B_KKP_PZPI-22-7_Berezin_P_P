// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Ukrainian (`uk`).
class AppLocalizationsUk extends AppLocalizations {
  AppLocalizationsUk([String locale = 'uk']) : super(locale);

  @override
  String get appTitle => 'Nellingua';

  @override
  String get welcomeToNellingua => 'Ласкаво просимо до Nellingua!';

  @override
  String welcomeUsername(Object username) {
    return 'Ласкаво просимо, $username!';
  }

  @override
  String get login => 'Увійти';

  @override
  String get signUp => 'Зареєструватися';

  @override
  String get settings => 'Налаштування';

  @override
  String get themeType => 'Тема';

  @override
  String get lightTheme => 'Світла';

  @override
  String get darkTheme => 'Темна';

  @override
  String get systemTheme => 'Як встановлено на пристрої';

  @override
  String get dailyQuests => 'Щоденні квести';

  @override
  String get chooseCourse => 'Обрати курс';

  @override
  String get startLearning => 'Почати навчатися';

  @override
  String get myCourses => 'Мої курси';

  @override
  String get allCourses => 'Усі курси';

  @override
  String get noCoursesEnrolled => 'Ви ще не записалися на жоден курс';

  @override
  String get unnamedCourse => 'Курс без назви';

  @override
  String get enroll => 'Записатися';

  @override
  String get userName => 'Ім\'я користувача';

  @override
  String get email => 'Email';

  @override
  String get password => 'Пароль';

  @override
  String get signInWithGoogle => 'Увійти через Google';

  @override
  String get noAccountSignUp => 'Немає акаунту? Зареєструватися';

  @override
  String get haveAccountLogin => 'Вже є акаунт? Увійти';

  @override
  String questCompleteLessons(Object count) {
    final countStr = count.toString();
    if (RegExp(r'^(?!11$|.*\d11$).*1$').hasMatch(countStr)) {
      return 'Пройдіть $count урок';
    } else if (RegExp(r'^(?!12$|.*\d12$|13$|.*\d13$|14$|.*\d14$).*([234])$').hasMatch(countStr)) {
      return 'Пройдіть $count уроки';
    } else {
      return 'Пройдіть $count уроків';
    }
  }

  @override
  String questCompleteLevels(Object count) {
    final countStr = count.toString();
    if (RegExp(r'^(?!11$|.*\d11$).*1$').hasMatch(countStr)) {
      return 'Пройдіть $count рівень';
    } else if (RegExp(r'^(?!12$|.*\d12$|13$|.*\d13$|14$|.*\d14$).*([234])$').hasMatch(countStr)) {
      return 'Пройдіть $count рівні';
    } else {
      return 'Пройдіть $count рівнів';
    }
  }

  @override
  String get questCompleteTheoryLevel => 'Пройдіть рівень типу «Теорія»';

  @override
  String get questCompletePracticeLevel => 'Пройдіть рівень типу «Практика»';

  @override
  String questCompleteSpeakingTasks(Object count) {
    final countStr = count.toString();
    if (RegExp(r'^(?!11$|.*\d11$).*1$').hasMatch(countStr)) {
      return 'Виконайте $count вправу на говоріння';
    } else if (RegExp(r'^(?!12$|.*\d12$|13$|.*\d13$|14$|.*\d14$).*([234])$').hasMatch(countStr)) {
      return 'Виконайте $count вправи на говоріння';
    } else {
      return 'Виконайте $count вправ на говоріння';
    }
  }

  @override
  String questCompleteListeningTasks(Object count) {
    final countStr = count.toString();
    if (RegExp(r'^(?!11$|.*\d11$).*1$').hasMatch(countStr)) {
      return 'Виконайте $count вправу на слухання';
    } else if (RegExp(r'^(?!12$|.*\d12$|13$|.*\d13$|14$|.*\d14$).*([234])$').hasMatch(countStr)) {
      return 'Виконайте $count вправи на слухання';
    } else {
      return 'Виконайте $count вправ на слухання';
    }
  }

  @override
  String get remainingTime => 'Залишилося до скидання';

  @override
  String unitAOfB(Object currentUnitIndex, Object unitsCount) {
    return 'Тема $currentUnitIndex з $unitsCount';
  }

  @override
  String get selectLesson => 'Оберіть урок';

  @override
  String get cancel => 'Скасувати';

  @override
  String lessonTitle(Object lessonName) {
    return 'Урок: $lessonName';
  }

  @override
  String get translateSentence => 'Перекладіть речення: ';

  @override
  String get check => 'Перевірити';

  @override
  String get correctAnswer => 'Правильно!';

  @override
  String get nextTask => 'Далі';

  @override
  String get lessonCompleted => 'Урок пройдено!';

  @override
  String timeSpent(Object spentTime) {
    return 'Проведено часу: $spentTime';
  }

  @override
  String get continueButton => 'Продовжити';

  @override
  String get repeatSentenceAloud => 'Повторіть речення вголос:';

  @override
  String get turnOnMicrophone => 'Говорити';

  @override
  String get skip => 'Пропустити';

  @override
  String get stop => 'Зупинити';

  @override
  String tryAgainSpeakingTask(Object percents) {
    return 'Спробуйте ще раз. Збіг: $percents%';
  }

  @override
  String get enterTranslationPlaceholder => 'Введіть свій переклад тут...';

  @override
  String get collectMatchingPairs => 'Зберіть пари:';

  @override
  String get strokePracticeCompleted => 'Вітаємо! Ви написали:';

  @override
  String get restart => 'Заново';

  @override
  String get strokePracticeMode1 => 'Всі контурні риски';

  @override
  String get strokePracticeMode2 => 'Поточна контурна риска';

  @override
  String get strokePracticeMode3 => 'Без контурних рисок';

  @override
  String get shop => 'Магазин';

  @override
  String get xpMultipliers => 'Множники XP';

  @override
  String get gems => 'Самоцвіти';

  @override
  String get price => 'Ціна';

  @override
  String get buy => 'Купити';

  @override
  String get insufficientGems => 'Бракує самоцвітів';

  @override
  String get purchased => 'Придбано';

  @override
  String get verificationEmailSent => 'Лист із підтвердженням надіслано. Перевірте вашу пошту.';

  @override
  String get emailNotVerified => 'Будь ласка, підтвердіть ваш email перед входом.';

  @override
  String get userNotFound => 'Користувача не знайдено.';

  @override
  String get wrongPassword => 'Неправильний пароль.';

  @override
  String get emailAlreadyInUse => 'Цей email вже використовується.';

  @override
  String get weakPassword => 'Пароль занадто слабкий.';

  @override
  String get authError => 'Помилка автентифікації.';

  @override
  String xpEarned(Object xp) {
    return 'Зароблено XP: $xp';
  }

  @override
  String totalXp(Object xp) {
    return 'Загальна кількість XP: $xp';
  }

  @override
  String xpMultiplierActive(Object multiplier) {
    return 'Множник XP: x$multiplier';
  }

  @override
  String xpMultiplierActiveWithTime(Object multiplier, Object minutes, Object seconds) {
    return 'x$multiplier (залишилось ${minutes}хв ${seconds}с)';
  }
}