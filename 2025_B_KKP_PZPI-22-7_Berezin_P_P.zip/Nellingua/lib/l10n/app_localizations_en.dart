// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for English (`en`).
class AppLocalizationsEn extends AppLocalizations {
  AppLocalizationsEn([String locale = 'en']) : super(locale);

  @override
  String get appTitle => 'Nellingua';

  @override
  String get welcomeToNellingua => 'Welcome to Nellingua!';

  @override
  String welcomeUsername(Object username) {
    return 'Welcome, $username!';
  }

  @override
  String get login => 'Log In';

  @override
  String get signUp => 'Sign Up';

  @override
  String get settings => 'Settings';

  @override
  String get themeType => 'Theme';

  @override
  String get lightTheme => 'Light';

  @override
  String get darkTheme => 'Dark';

  @override
  String get systemTheme => 'System';

  @override
  String get dailyQuests => 'Daily Quests';

  @override
  String get chooseCourse => 'Choose a course';

  @override
  String get startLearning => 'Start learning';

  @override
  String get myCourses => 'My Courses';

  @override
  String get allCourses => 'All Courses';

  @override
  String get noCoursesEnrolled => 'You haven\'t enrolled in any courses yet';

  @override
  String get unnamedCourse => 'Unnamed course';

  @override
  String get enroll => 'Enroll';

  @override
  String get userName => 'Username';

  @override
  String get email => 'Email';

  @override
  String get password => 'Password';

  @override
  String get signInWithGoogle => 'Sign in with Google';

  @override
  String get noAccountSignUp => 'No account? Sign up';

  @override
  String get haveAccountLogin => 'Already have an account? Log in';

  @override
  String questCompleteLessons(Object count) {
    return intl.Intl.pluralLogic(
      int.parse(count.toString()),
      locale: localeName,
      one: 'Complete $count lesson',
      other: 'Complete $count lessons',
    );
  }

  @override
  String questCompleteLevels(Object count) {
    return intl.Intl.pluralLogic(
      int.parse(count.toString()),
      locale: localeName,
      one: 'Complete $count level',
      other: 'Complete $count levels',
    );
  }

  @override
  String get questCompleteTheoryLevel => 'Complete a Theory level';

  @override
  String get questCompletePracticeLevel => 'Complete a Practice level';

  @override
  String questCompleteSpeakingTasks(Object count) {
    return intl.Intl.pluralLogic(
      int.parse(count.toString()),
      locale: localeName,
      one: 'Complete $count speaking task',
      other: 'Complete $count speaking tasks',
    );
  }

  @override
  String questCompleteListeningTasks(Object count) {
    return intl.Intl.pluralLogic(
      int.parse(count.toString()),
      locale: localeName,
      one: 'Complete $count listening task',
      other: 'Complete $count listening tasks',
    );
  }

  @override
  String get remainingTime => 'Remaining time until reset';

  @override
  String unitAOfB(Object currentUnitIndex, Object unitsCount) {
    return 'Unit $currentUnitIndex of $unitsCount';
  }

  @override
  String get selectLesson => 'Select lesson';

  @override
  String get cancel => 'Cancel';

  @override
  String lessonTitle(Object lessonName) {
    return 'Lesson: $lessonName';
  }

  @override
  String get translateSentence => 'Translate the sentence: ';

  @override
  String get check => 'Check';

  @override
  String get correctAnswer => 'Correct!';

  @override
  String get nextTask => 'Next';

  @override
  String get lessonCompleted => 'Lesson completed!';

  @override
  String timeSpent(Object spentTime) {
    return 'Time spent: $spentTime';
  }

  @override
  String get continueButton => 'Continue';

  @override
  String get repeatSentenceAloud => 'Repeat the sentence aloud:';

  @override
  String get turnOnMicrophone => 'Say';

  @override
  String get skip => 'Skip';

  @override
  String get stop => 'Stop';

  @override
  String tryAgainSpeakingTask(Object percents) {
    return 'Try again. Match: $percents%';
  }

  @override
  String get enterTranslationPlaceholder => 'Enter your translation here...';

  @override
  String get collectMatchingPairs => 'Collect the matching pairs:';

  @override
  String get strokePracticeCompleted => 'Congratulations! You\'ve written:';

  @override
  String get restart => 'Restart';

  @override
  String get strokePracticeMode1 => 'All contour strokes';

  @override
  String get strokePracticeMode2 => 'Current contour stroke';

  @override
  String get strokePracticeMode3 => 'Without contour strokes';

  @override
  String get shop => 'Shop';

  @override
  String get xpMultipliers => 'XP Multipliers';

  @override
  String get gems => 'Gems';

  @override
  String get buy => 'Buy';

  @override
  String get insufficientGems => 'Not enough gems';

  @override
  String get purchased => 'Purchased';

  @override
  String get price => 'Price';

  @override
  String get verificationEmailSent => 'Verification email sent. Please check your inbox.';

  @override
  String get emailNotVerified => 'Please verify your email before logging in.';

  @override
  String get userNotFound => 'User not found.';

  @override
  String get wrongPassword => 'Incorrect password.';

  @override
  String get emailAlreadyInUse => 'This email is already in use.';

  @override
  String get weakPassword => 'Password is too weak.';

  @override
  String get authError => 'Authentication error.';

  @override
  String xpEarned(Object xp) {
    return 'XP Earned: $xp';
  }

  @override
  String totalXp(Object xp) {
    return 'Total XP: $xp';
  }

  @override
  String xpMultiplierActive(Object multiplier) {
    return 'XP Multiplier: x$multiplier';
  }

  @override
  String xpMultiplierActiveWithTime(Object multiplier, Object minutes, Object seconds) {
    return 'x$multiplier (${minutes}m ${seconds}s left)';
  }
}