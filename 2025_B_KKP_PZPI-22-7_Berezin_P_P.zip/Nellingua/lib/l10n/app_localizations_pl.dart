// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Polish (`pl`).
class AppLocalizationsPl extends AppLocalizations {
  AppLocalizationsPl([String locale = 'pl']) : super(locale);

  @override
  String get appTitle => 'Nellingua';

  @override
  String get welcomeToNellingua => 'Witamy w Nellingua!';

  @override
  String welcomeUsername(Object username) {
    return 'Witamy, $username!';
  }

  @override
  String get login => 'Zaloguj się';

  @override
  String get signUp => 'Załóż konto';

  @override
  String get settings => 'Ustawienia';

  @override
  String get themeType => 'Tryb';

  @override
  String get lightTheme => 'Światły';

  @override
  String get darkTheme => 'Ciemny';

  @override
  String get systemTheme => 'Domyślne ustawienie systemowe';

  @override
  String get dailyQuests => 'Questy dzienne';

  @override
  String get chooseCourse => 'Wybierz kurs';

  @override
  String get startLearning => 'Zacznij naukę';

  @override
  String get myCourses => 'Moje kursy';

  @override
  String get allCourses => 'Wszystkie kursy';

  @override
  String get noCoursesEnrolled => 'Nie zapisałeś/aś się jeszcze na żaden kurs';

  @override
  String get unnamedCourse => 'Kurz bez nazwy';

  @override
  String get enroll => 'Zapisz się';

  @override
  String get userName => 'Nazwa użytkownika';

  @override
  String get email => 'Email';

  @override
  String get password => 'Hasło';

  @override
  String get signInWithGoogle => 'Zaloguj się przez Google';

  @override
  String get noAccountSignUp => 'Nie masz konta? Załóż go';

  @override
  String get haveAccountLogin => 'Masz już konto? Zaloguj się';

  @override
  String questCompleteLessons(Object count) {
    final countStr = count.toString();
    if (RegExp(r'^1$').hasMatch(countStr)) {
      return 'Ukończ $count lekcję';
    } else if (RegExp(r'^(?!.*1[2-4]$).*([234])$').hasMatch(countStr)) {
      return 'Ukończ $count lekcje';
    } else {
      return 'Ukończ $count lekcji';
    }
  }

  @override
  String questCompleteLevels(Object count) {
    final countStr = count.toString();
    if (RegExp(r'^1$').hasMatch(countStr)) {
      return 'Ukończ $count poziom';
    } else if (RegExp(r'^(?!.*1[2-4]$).*([234])$').hasMatch(countStr)) {
      return 'Ukończ $count poziomy';
    } else {
      return 'Ukończ $count poziomów';
    }
  }

  @override
  String get questCompleteTheoryLevel => 'Ukończ poziom typu \"Teoria\"';

  @override
  String get questCompletePracticeLevel => 'Ukończ poziom typu \"Praktyka\"';

  @override
  String questCompleteSpeakingTasks(Object count) {
    final countStr = count.toString();
    if (RegExp(r'^1$').hasMatch(countStr)) {
      return 'Wykonaj $count ćwiczenie na mówienie';
    } else if (RegExp(r'^(?!.*1[2-4]$).*([234])$').hasMatch(countStr)) {
      return 'Wykonaj $count ćwiczenia na mówienie';
    } else {
      return 'Wykonaj $count ćwiczeń na mówienie';
    }
  }

  @override
  String questCompleteListeningTasks(Object count) {
    final countStr = count.toString();
    if (RegExp(r'^1$').hasMatch(countStr)) {
      return 'Wykonaj $count ćwiczenie na słuchanie';
    } else if (RegExp(r'^(?!.*1[2-4]$).*([234])$').hasMatch(countStr)) {
      return 'Wykonaj $count ćwiczenia na słuchanie';
    } else {
      return 'Wykonaj $count ćwiczeń na słuchanie';
    }
  }

  @override
  String get remainingTime => 'Pozostały czas do zresetowania';

  @override
  String unitAOfB(Object currentUnitIndex, Object unitsCount) {
    return 'Sekcja $currentUnitIndex z $unitsCount';
  }

  @override
  String get selectLesson => 'Wybierz lekcję';

  @override
  String get cancel => 'Cofnij';

  @override
  String lessonTitle(Object lessonName) {
    return 'Lekcja: $lessonName';
  }

  @override
  String get translateSentence => 'Przetłumacz zdanie: ';

  @override
  String get check => 'Sprawdź';

  @override
  String get correctAnswer => 'Poprawnie!';

  @override
  String get nextTask => 'Dalej';

  @override
  String get lessonCompleted => 'Lekcja ukończona!';

  @override
  String timeSpent(Object spentTime) {
    return 'Czas spędzony: $spentTime';
  }

  @override
  String get continueButton => 'Kontynuuj';

  @override
  String get repeatSentenceAloud => 'Powtórz zdanie na głos:';

  @override
  String get turnOnMicrophone => 'Mów';

  @override
  String get skip => 'Pomiń';

  @override
  String get stop => 'Zatrzymaj';

  @override
  String tryAgainSpeakingTask(Object percents) {
    return 'Spróbuj ponownie. Dopasowanie: $percents%';
  }

  @override
  String get enterTranslationPlaceholder => 'Wpisz tutaj swoje tłumaczenie...';

  @override
  String get collectMatchingPairs => 'Zbierz pary:';

  @override
  String get strokePracticeCompleted => 'Gratulacje! Napisałeś/aś:';

  @override
  String get restart => 'Zrestartuj';

  @override
  String get strokePracticeMode1 => 'Wszystkie konturowe kreski';

  @override
  String get strokePracticeMode2 => 'Bieżąca konturowa kreska';

  @override
  String get strokePracticeMode3 => 'Bez konturowych kresek';

  @override
  String get shop => 'Sklep';

  @override
  String get xpMultipliers => 'Mnożniki XP';

  @override
  String get gems => 'Klejnoty';

  @override
  String get buy => 'Kup';

  @override
  String get insufficientGems => 'Za mało klejnotów';

  @override
  String get purchased => 'Zakupiono';

  @override
  String get price => 'Cena';

  @override
  String get verificationEmailSent => 'Wysłano e-mail weryfikacyjny. Sprawdź swoją skrzynkę odbiorczą.';

  @override
  String get emailNotVerified => 'Zweryfikuj swój adres e-mail przed zalogowaniem.';

  @override
  String get userNotFound => 'Nie znaleziono użytkownika.';

  @override
  String get wrongPassword => 'Nieprawidłowe hasło.';

  @override
  String get emailAlreadyInUse => 'Ten e-mail jest już używany.';

  @override
  String get weakPassword => 'Hasło jest za słabe.';

  @override
  String get authError => 'Błąd autoryzacji.';

  @override
  String xpEarned(Object xp) {
    return 'Zdobyto XP: $xp';
  }

  @override
  String totalXp(Object xp) {
    return 'Całkowite XP: $xp';
  }

  @override
  String xpMultiplierActive(Object multiplier) {
    return 'Mnożnik XP: x$multiplier';
  }

  @override
  String xpMultiplierActiveWithTime(Object multiplier, Object minutes, Object seconds) {
    return 'x$multiplier (pozostało ${minutes}m ${seconds}s)';
  }
}