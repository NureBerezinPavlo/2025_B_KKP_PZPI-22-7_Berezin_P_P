import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:intl/intl.dart' as intl;

import 'app_localizations_en.dart';
import 'app_localizations_pl.dart';
import 'app_localizations_uk.dart';

abstract class AppLocalizations {
  AppLocalizations(String locale) : localeName = intl.Intl.canonicalizedLocale(locale.toString());

  final String localeName;

  static AppLocalizations? of(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations);
  }

  static const LocalizationsDelegate<AppLocalizations> delegate = _AppLocalizationsDelegate();

  /// A list of this localizations delegate along with the default localizations
  /// delegates.
  ///
  /// Returns a list of localizations delegates containing this delegate along with
  /// GlobalMaterialLocalizations.delegate, GlobalCupertinoLocalizations.delegate,
  /// and GlobalWidgetsLocalizations.delegate.
  ///
  /// Additional delegates can be added by appending to this list in
  /// MaterialApp. This list does not have to be used at all if a custom list
  /// of delegates is preferred or required.
  static const List<LocalizationsDelegate<dynamic>> localizationsDelegates = <LocalizationsDelegate<dynamic>>[
    delegate,
    GlobalMaterialLocalizations.delegate,
    GlobalCupertinoLocalizations.delegate,
    GlobalWidgetsLocalizations.delegate,
  ];

  /// A list of this localizations delegate's supported locales.
  static const List<Locale> supportedLocales = <Locale>[
    Locale('en'),
    Locale('pl'),
    Locale('uk')
  ];

  /// No description provided for @appTitle.
  ///
  /// In en, this message translates to:
  /// **'Nellingua'**
  String get appTitle;

  /// No description provided for @welcomeToNellingua.
  ///
  /// In en, this message translates to:
  /// **'Welcome to Nellingua!'**
  String get welcomeToNellingua;

  /// Welcome message with username placeholder.
  ///
  /// In en, this message translates to:
  /// **'Welcome, {username}!'**
  String welcomeUsername(Object username);

  /// No description provided for @login.
  ///
  /// In en, this message translates to:
  /// **'Log In'**
  String get login;

  /// No description provided for @signUp.
  ///
  /// In en, this message translates to:
  /// **'Sign Up'**
  String get signUp;

  /// No description provided for @settings.
  ///
  /// In en, this message translates to:
  /// **'Settings'**
  String get settings;

  /// No description provided for @themeType.
  ///
  /// In en, this message translates to:
  /// **'Theme'**
  String get themeType;

  /// No description provided for @lightTheme.
  ///
  /// In en, this message translates to:
  /// **'Light'**
  String get lightTheme;

  /// No description provided for @darkTheme.
  ///
  /// In en, this message translates to:
  /// **'Dark'**
  String get darkTheme;

  /// No description provided for @systemTheme.
  ///
  /// In en, this message translates to:
  /// **'System'**
  String get systemTheme;

  /// No description provided for @dailyQuests.
  ///
  /// In en, this message translates to:
  /// **'Daily Quests'**
  String get dailyQuests;

  /// No description provided for @chooseCourse.
  ///
  /// In en, this message translates to:
  /// **'Choose a course'**
  String get chooseCourse;

  /// No description provided for @startLearning.
  ///
  /// In en, this message translates to:
  /// **'Start learning'**
  String get startLearning;

  /// No description provided for @myCourses.
  ///
  /// In en, this message translates to:
  /// **'My Courses'**
  String get myCourses;

  /// No description provided for @allCourses.
  ///
  /// In en, this message translates to:
  /// **'All Courses'**
  String get allCourses;

  /// No description provided for @noCoursesEnrolled.
  ///
  /// In en, this message translates to:
  /// **'You haven\'t enrolled in any courses yet'**
  String get noCoursesEnrolled;

  /// No description provided for @unnamedCourse.
  ///
  /// In en, this message translates to:
  /// **'Unnamed course'**
  String get unnamedCourse;

  /// No description provided for @enroll.
  ///
  /// In en, this message translates to:
  /// **'Enroll'**
  String get enroll;

  /// No description provided for @userName.
  ///
  /// In en, this message translates to:
  /// **'Username'**
  String get userName;

  /// No description provided for @email.
  ///
  /// In en, this message translates to:
  /// **'Email'**
  String get email;

  /// No description provided for @password.
  ///
  /// In en, this message translates to:
  /// **'Password'**
  String get password;

  /// No description provided for @signInWithGoogle.
  ///
  /// In en, this message translates to:
  /// **'Sign in with Google'**
  String get signInWithGoogle;

  /// No description provided for @noAccountSignUp.
  ///
  /// In en, this message translates to:
  /// **'No account? Sign up'**
  String get noAccountSignUp;

  /// No description provided for @haveAccountLogin.
  ///
  /// In en, this message translates to:
  /// **'Already have an account? Log in'**
  String get haveAccountLogin;

  /// Prompt to complete a specific number of lessons for a daily quest.
  ///
  /// In en, this message translates to:
  /// **'{count, plural, one{Complete {count} lesson} other{Complete {count} lessons}}'**
  String questCompleteLessons(num count);

  /// Prompt to complete a specific number of levels for a daily quest.
  ///
  /// In en, this message translates to:
  /// **'{count, plural, one{Complete {count} level} other{Complete {count} levels}}'**
  String questCompleteLevels(num count);

  /// No description provided for @questCompleteTheoryLevel.
  ///
  /// In en, this message translates to:
  /// **'Complete a Theory level'**
  String get questCompleteTheoryLevel;

  /// No description provided for @questCompletePracticeLevel.
  ///
  /// In en, this message translates to:
  /// **'Complete a Practice level'**
  String get questCompletePracticeLevel;

  /// Prompt to complete a specific number of speaking tasks for a daily quest.
  ///
  /// In en, this message translates to:
  /// **'{count, plural, one{Complete {count} speaking task} other{Complete {count} speaking tasks}}'**
  String questCompleteSpeakingTasks(num count);

  /// Prompt to complete a specific number of listening tasks for a daily quest.
  ///
  /// In en, this message translates to:
  /// **'{count, plural, one{Complete {count} listening task} other{Complete {count} listening tasks}}'**
  String questCompleteListeningTasks(num count);

  /// No description provided for @remainingTime.
  ///
  /// In en, this message translates to:
  /// **'Remaining time until reset'**
  String get remainingTime;

  /// Text showing current unit number out of total units.
  ///
  /// In en, this message translates to:
  /// **'Unit {currentUnitIndex} of {unitsCount}'**
  String unitAOfB(Object currentUnitIndex, Object unitsCount);

  /// No description provided for @selectLesson.
  ///
  /// In en, this message translates to:
  /// **'Select lesson'**
  String get selectLesson;

  /// No description provided for @cancel.
  ///
  /// In en, this message translates to:
  /// **'Cancel'**
  String get cancel;

  /// Title of a lesson with lesson name placeholder.
  ///
  /// In en, this message translates to:
  /// **'Lesson: {lessonName}'**
  String lessonTitle(Object lessonName);

  /// No description provided for @translateSentence.
  ///
  /// In en, this message translates to:
  /// **'Translate the sentence: '**
  String get translateSentence;

  /// No description provided for @check.
  ///
  /// In en, this message translates to:
  /// **'Check'**
  String get check;

  /// No description provided for @correctAnswer.
  ///
  /// In en, this message translates to:
  /// **'Correct!'**
  String get correctAnswer;

  /// No description provided for @nextTask.
  ///
  /// In en, this message translates to:
  /// **'Next'**
  String get nextTask;

  /// No description provided for @lessonCompleted.
  ///
  /// In en, this message translates to:
  /// **'Lesson completed!'**
  String get lessonCompleted;

  /// Text showing time spent on a lesson with time placeholder.
  ///
  /// In en, this message translates to:
  /// **'Time spent: {spentTime}'**
  String timeSpent(Object spentTime);

  /// No description provided for @continue.
  ///
  /// In en, this message translates to:
  /// **'Continue'**
  String get continueButton;

  /// No description provided for @repeatSentenceAloud.
  ///
  /// In en, this message translates to:
  /// **'Repeat the sentence aloud:'**
  String get repeatSentenceAloud;

  /// No description provided for @turnOnMicrophone.
  ///
  /// In en, this message translates to:
  /// **'Say'**
  String get turnOnMicrophone;

  /// No description provided for @skip.
  ///
  /// In en, this message translates to:
  /// **'Skip'**
  String get skip;

  /// No description provided for @stop.
  ///
  /// In en, this message translates to:
  /// **'Stop'**
  String get stop;

  /// Prompt to try again a speaking task with percentage match placeholder.
  ///
  /// In en, this message translates to:
  /// **'Try again. Match: {percents}%'**
  String tryAgainSpeakingTask(Object percents);

  /// No description provided for @enterTranslationPlaceholder.
  ///
  /// In en, this message translates to:
  /// **'Enter your translation here...'**
  String get enterTranslationPlaceholder;

  /// No description provided for @collectMatchingPairs.
  ///
  /// In en, this message translates to:
  /// **'Collect the matching pairs:'**
  String get collectMatchingPairs;

  /// No description provided for @strokePracticeCompleted.
  ///
  /// In en, this message translates to:
  /// **'Congratulations! You\'ve written:'**
  String get strokePracticeCompleted;

  /// No description provided for @restart.
  ///
  /// In en, this message translates to:
  /// **'Restart'**
  String get restart;

  /// No description provided for @strokePracticeMode1.
  ///
  /// In en, this message translates to:
  /// **'All contour strokes'**
  String get strokePracticeMode1;

  /// No description provided for @strokePracticeMode2.
  ///
  /// In en, this message translates to:
  /// **'Current contour stroke'**
  String get strokePracticeMode2;

  /// No description provided for @strokePracticeMode3.
  ///
  /// In en, this message translates to:
  /// **'Without contour strokes'**
  String get strokePracticeMode3;

  /// No description provided for @shop.
  ///
  /// In en, this message translates to:
  /// **'Shop'**
  String get shop;

  /// No description provided for @xpMultipliers.
  ///
  /// In en, this message translates to:
  /// **'XP Multipliers'**
  String get xpMultipliers;

  /// No description provided for @gems.
  ///
  /// In en, this message translates to:
  /// **'Gems'**
  String get gems;

  /// No description provided for @buy.
  ///
  /// In en, this message translates to:
  /// **'Buy'**
  String get buy;

  /// No description provided for @insufficientGems.
  ///
  /// In en, this message translates to:
  /// **'Not enough gems'**
  String get insufficientGems;

  /// No description provided for @purchased.
  ///
  /// In en, this message translates to:
  /// **'Purchased'**
  String get purchased;

  String get price;

  String get verificationEmailSent;

  String get emailNotVerified;

  String get userNotFound;

  String get wrongPassword;

  String get emailAlreadyInUse;

  String get weakPassword;

  String get authError;

  /// Shows XP earned for completing a lesson
  ///
  /// In en, this message translates to:
  /// **'XP Earned: %xp%'**
  String xpEarned(Object xp);

  /// Shows total accumulated XP
  ///
  /// In en, this message translates to:
  /// **'Total XP: %xp%'**
  String totalXp(Object xp);

  /// Shows active XP multiplier
  ///
  /// In en, this message translates to:
  /// **'XP Multiplier: x%multiplier%'**
  String xpMultiplierActive(Object multiplier);

  /// Shows active XP multiplier with remaining time
  ///
  /// In en, this message translates to:
  /// **'x%multiplier% (%minutes%m %seconds%s left)'**
  String xpMultiplierActiveWithTime(Object multiplier, Object minutes, Object seconds);
}

class _AppLocalizationsDelegate extends LocalizationsDelegate<AppLocalizations> {
  const _AppLocalizationsDelegate();

  @override
  Future<AppLocalizations> load(Locale locale) {
    return SynchronousFuture<AppLocalizations>(lookupAppLocalizations(locale));
  }

  @override
  bool isSupported(Locale locale) => <String>['en', 'pl', 'uk'].contains(locale.languageCode);

  @override
  bool shouldReload(_AppLocalizationsDelegate old) => false;
}

AppLocalizations lookupAppLocalizations(Locale locale) {
  // Lookup logic when only language code is specified.
  switch (locale.languageCode) {
    case 'en': return AppLocalizationsEn();
    case 'pl': return AppLocalizationsPl();
    case 'uk': return AppLocalizationsUk();
  }

  throw FlutterError(
    'AppLocalizations.delegate failed to load unsupported locale "$locale". This is likely '
    'an issue with the localizations generation tool. Please file an issue '
    'on GitHub with a reproducible sample app and the gen-l10n configuration '
    'that was used.'
  );
}