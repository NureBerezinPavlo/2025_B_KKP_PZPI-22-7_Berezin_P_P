import 'dart:convert';
import 'package:flutter/services.dart' show rootBundle;
import 'dart:ui';

class GraphicsRepository {
  static Map<String, List<String>>? _cachedStrokes;
  static Map<String, List<List<List<num>>>>? _cachedMedians;

  static Future<void> _loadGraphicsData() async {
    final raw = await rootBundle.loadString('assets/graphics.txt');
    final lines = raw.split('\n');
    final Map<String, List<String>> strokesMap = {};
    final Map<String, List<List<List<num>>>> mediansMap = {};

    for (final line in lines) {
      if (line.trim().isEmpty) continue;
      final parsed = json.decode(line);
      final char = parsed['character'];
      if (char != null) {
        if (parsed['strokes'] != null) {
          strokesMap[char] = List<String>.from(parsed['strokes']);
        }
        if (parsed['medians'] != null) {
          mediansMap[char] = List<List<List<num>>>.from(
            parsed['medians'].map((stroke) => List<List<num>>.from(
              stroke.map((point) => List<num>.from(point)),
            )),
          );
        }
      }
    }
    _cachedStrokes = strokesMap;
    _cachedMedians = mediansMap;
  }

  static Future<List<String>> getStrokes(String character) async {
    if (_cachedStrokes == null) {
      await _loadGraphicsData();
    }

    return _cachedStrokes![character] ?? [];
  }

  static Future<List<List<List<num>>>> getMedians(String character) async {
    if (_cachedMedians == null) {
      await _loadGraphicsData();
    }
    return _cachedMedians![character] ?? [];
  }
}