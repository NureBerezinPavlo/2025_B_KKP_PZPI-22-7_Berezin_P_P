import 'dart:math';
import 'package:nellingua/models/sentence_model.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class SentenceRepository {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  Future<List<Sentence>> fetchSentencesForCourse(String courseId) async {
    try {
      final snapshot = await _db
          .collection('sentences')
          .where('course_id', isEqualTo: courseId)
          .get();

      return snapshot.docs
          .map((doc) => Sentence.fromJson(doc.data()))
          .toList();
    } catch (e) {
      print('Error fetching sentences: $e');
      return [];
    }
  }

  Future<Sentence> getRandomSentenceForLesson(
      String courseId,
      List<String> vocabularyIds,
      List<String> learnedWordIds,
      ) async {
    final allSentences = await fetchSentencesForCourse(courseId);
    final wordIds = [...vocabularyIds, ...learnedWordIds];

    // Фільтруємо речення, що містять потрібні слова
    final filteredSentences = allSentences.where((sentence) {
      final foreignWords = sentence.foreign.defaultOptions.expand((option) =>
          option.highlightedWords.map((word) => word.wordID));

      final nativeWords = sentence.native.defaultOptions.expand((option) =>
          option.highlightedWords.map((word) => word.wordID));

      final allWords = {...foreignWords, ...nativeWords};
      return allWords.any((word) => wordIds.contains(word));
    }).toList();

    if (filteredSentences.isEmpty) {
      throw Exception('No sentences found for vocabulary');
    }

    // Вибираємо випадкове речення
    return filteredSentences[Random().nextInt(filteredSentences.length)];
  }
}