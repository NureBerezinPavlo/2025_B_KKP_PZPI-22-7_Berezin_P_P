import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nellingua/services/sentence_repository.dart';
import 'package:nellingua/services/word_repository.dart';
import 'package:nellingua/models/lesson.dart';
import 'package:nellingua/models/theory_slide.dart';
import 'dart:math';

class LessonLoader {
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  final SentenceRepository _sentenceRepo = SentenceRepository();
  final WordRepository _wordRepo = WordRepository();

  Future<Lesson> fetchLesson({
    required String courseId,
    required int unitIndex,
    required int levelIndex,
    required int lessonIndex,
    required String userId,
  }) async {
    final courseSnap = await _db.collection('courses').doc(courseId).get();
    final List<String> unitIds = List<String>.from(courseSnap.data()?['units'] ?? []);

    final unitSnap = await _db.collection('units').doc(unitIds[unitIndex]).get();
    final unitData = unitSnap.data();
    if (unitData == null) throw Exception('Unit not found');

    final levels = List<Map<String, dynamic>>.from(unitData['levels'] ?? []);
    final levelData = Map<String, dynamic>.from(levels[levelIndex]);

    final lessons = List<Map<String, dynamic>>.from(levelData['lessons'] ?? []);
    if (lessonIndex < 0 || lessonIndex >= lessons.length) {
      throw Exception('Lesson index out of range');
    }

    final lessonData = lessons[lessonIndex];

    // Перевіряємо тип рівня
    if (levelData['type'] == 'practice') {
      print('[DEBUG] Fetching practice lesson for courseId=$courseId, unitIndex=$unitIndex, levelIndex=$levelIndex, lessonIndex=$lessonIndex');
      return _buildPracticeLesson(levelData, courseId, userId, lessonData);
    }

    print('[DEBUG] Fetching theory lesson: lessonData = $lessonData');
    return Lesson.fromJson(lessonData);
  }

  Future<Lesson> _buildPracticeLesson(
      Map<String, dynamic> levelData,
      String courseId,
      String userId,
      Map<String, dynamic> lessonData,
      ) async {
    final title = lessonData['title'] ?? 'Практика';
    final vocabularyIds = List<String>.from(lessonData['vocabulary'] ?? []);
    final taskGroups = List<Map<String, dynamic>>.from(lessonData['task_groups'] ?? []);

    print('[DEBUG] _buildPracticeLesson: title=$title, vocabularyIds=$vocabularyIds, taskGroups=$taskGroups');

    if (taskGroups.isEmpty) {
      print('[DEBUG] _buildPracticeLesson: taskGroups is empty');
      return Lesson(title: title, slides: []);
    }

    final slides = <TheorySlide>[];
    final random = Random();

    // Отримуємо вивчені слова користувача
    final learnedWords = await _wordRepo.fetchLearnedWords(userId);
    final learnedWordIds = learnedWords.map((word) => word['wordId'] as String).toList();

    // Отримуємо всі речення для курсу
    final allSentences = await _sentenceRepo.fetchSentencesForCourse(courseId);

    // Фільтруємо речення, які містять слова з vocabulary або learnedWordIds
    final wordIds = [...vocabularyIds, ...learnedWordIds];
    final filteredSentences = allSentences.where((sentence) {
      final foreignWords = sentence.foreign.defaultOptions.expand((option) =>
          option.highlightedWords.map((word) => word.wordID));
      final nativeWords = sentence.native.defaultOptions.expand((option) =>
          option.highlightedWords.map((word) => word.wordID));
      final allWords = {...foreignWords, ...nativeWords};
      return allWords.any((word) => wordIds.contains(word));
    }).toList();

    print('[DEBUG] _buildPracticeLesson: filteredSentences count=${filteredSentences.length}');

    if (filteredSentences.isEmpty) {
      print('[DEBUG] _buildPracticeLesson: No valid sentences found');
      return Lesson(title: title, slides: []);
    }

    // Генеруємо слайди для кожної групи завдань
    for (final group in taskGroups) {
      final exercisesCount = group['exercises_count'] as int;
      final types = List<String>.from(group['types'] ?? []);
      types.shuffle(random); // Перемішуємо типи

      // Вибираємо перші exercises_count типів
      final selectedTypes = types.take(exercisesCount).toList();

      for (final type in selectedTypes) {
        // Випадковий напрямок
        final direction = random.nextBool() ? 'native_to_foreign' : 'foreign_to_native';

        // Вибираємо випадкове речення
        final sentence = filteredSentences[random.nextInt(filteredSentences.length)];

        slides.add(TheorySlide(
          id: 'slide_${DateTime.now().millisecondsSinceEpoch}_${slides.length}',
          type: type,
          content: [], // Порожній, оскільки використовується translationBlockData
          translationBlockData: {
            'direction': direction,
            'sentence_ids': [sentence.sentenceId],
          },
        ));
      }
    }

    print('[DEBUG] _buildPracticeLesson: Generated ${slides.length} slides');
    return Lesson(title: title, slides: slides);
  }
}