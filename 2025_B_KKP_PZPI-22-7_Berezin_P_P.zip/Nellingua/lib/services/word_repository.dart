import 'package:cloud_firestore/cloud_firestore.dart';

class WordRepository {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  Future<List<Map<String, dynamic>>> fetchVocabularyForCourse(String courseId) async {
    try {
      final snapshot = await _db
          .collection('vocabulary')
          .where('course_id', isEqualTo: courseId)
          .get();

      return snapshot.docs.map((doc) => doc.data()).toList();
    } catch (e) {
      print('Error fetching vocabulary: $e');
      return [];
    }
  }

  Future<List<Map<String, dynamic>>> fetchLearnedWords(String userId) async {
    try {
      final snapshot = await _db
          .collection('users')
          .doc(userId)
          .collection('learned_words')
          .get();

      return snapshot.docs.map((doc) => doc.data()).toList();
    } catch (e) {
      print('Error fetching learned words: $e');
      return [];
    }
  }
}