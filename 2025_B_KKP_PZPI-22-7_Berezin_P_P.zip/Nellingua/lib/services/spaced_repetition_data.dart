import 'dart:math';
import 'package:cloud_firestore/cloud_firestore.dart';

class SpacedRepetitionData {
  final String wordId;
  final String courseId;
  final int repetitionNumber;
  final double easinessFactor;
  final int interval;
  final DateTime nextReviewDate;
  final DateTime lastReviewDate;
  final int streak;
  final int totalReviews;
  final int lastQuality;

  SpacedRepetitionData({
    required this.wordId,
    required this.courseId,
    this.repetitionNumber = 0,
    this.easinessFactor = 2.5,
    this.interval = 1,
    required this.nextReviewDate,
    required this.lastReviewDate,
    this.streak = 0,
    this.totalReviews = 0,
    this.lastQuality = 0,
  });

  factory SpacedRepetitionData.initial(String wordId, String courseId) {
    final now = DateTime.now();
    return SpacedRepetitionData(
      wordId: wordId,
      courseId: courseId,
      nextReviewDate: now,
      lastReviewDate: now,
    );
  }

  SpacedRepetitionData update(int quality) {
    assert(quality >= 0 && quality <= 5);

    // Модифікована формула SM-2
    double newEF = easinessFactor + (0.1 - (5 - quality) * (0.08 + (5 - quality) * 0.02));
    newEF = max(newEF, 1.3);

    int newRepetition = repetitionNumber;
    int newInterval;
    int newStreak = streak;
    final now = DateTime.now();

    if (quality < 3) {
      newRepetition = 0;
      newInterval = 1;
      newStreak = 0;
    } else {
      newStreak = streak + 1;
      newRepetition = repetitionNumber + 1;

      if (newRepetition == 1) {
        newInterval = 1;
      } else if (newRepetition == 2) {
        newInterval = 3;
      } else {
        newInterval = (interval * newEF).round();
      }
    }

    return SpacedRepetitionData(
      wordId: wordId,
      courseId: courseId,
      repetitionNumber: newRepetition,
      easinessFactor: newEF,
      interval: newInterval,
      nextReviewDate: now.add(Duration(days: newInterval)),
      lastReviewDate: now,
      streak: newStreak,
      totalReviews: totalReviews + 1,
      lastQuality: quality,
    );
  }

  Map<String, dynamic> toMap() => {
    'wordId': wordId,
    'courseId': courseId,
    'repetitionNumber': repetitionNumber,
    'easinessFactor': easinessFactor,
    'interval': interval,
    'nextReviewDate': nextReviewDate.toIso8601String(),
    'lastReviewDate': lastReviewDate.toIso8601String(),
    'streak': streak,
    'totalReviews': totalReviews,
    'lastQuality': lastQuality,
  };

  factory SpacedRepetitionData.fromMap(Map<String, dynamic> map) {
    return SpacedRepetitionData(
      wordId: map['wordId'],
      courseId: map['courseId'],
      repetitionNumber: map['repetitionNumber'] ?? 0,
      easinessFactor: map['easinessFactor']?.toDouble() ?? 2.5,
      interval: map['interval'] ?? 1,
      nextReviewDate: DateTime.parse(map['nextReviewDate']),
      lastReviewDate: DateTime.parse(map['lastReviewDate']),
      streak: map['streak'] ?? 0,
      totalReviews: map['totalReviews'] ?? 0,
      lastQuality: map['lastQuality'] ?? 0,
    );
  }
}

class SpacedRepetitionSystem {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  Future<void> saveRepetitionData(SpacedRepetitionData data, String userId) async {
    try {
      print('[DEBUG] saveRepetitionData: Saving wordId=${data.wordId} for userId=$userId');
      await _db
          .collection('users')
          .doc(userId)
          .collection('learned_words')
          .doc(data.wordId)
          .set(data.toMap(), SetOptions(merge: true));
      print('[DEBUG] saveRepetitionData: Successfully saved wordId=${data.wordId}');
    } catch (e, stackTrace) {
      print('[ERROR] saveRepetitionData: Failed to save wordId=${data.wordId}, error=$e');
      print('[ERROR] Stack trace: $stackTrace');
      rethrow; // Перекидаємо помилку, щоб її можна було зловити вище
    }
  }

  Future<List<SpacedRepetitionData>> getDueCards(String userId) async {
    final now = DateTime.now();
    final snapshot = await _db
        .collection('users')
        .doc(userId)
        .collection('learned_words')
        .where('nextReviewDate', isLessThanOrEqualTo: now.toIso8601String())
        .get();

    return snapshot.docs
        .map((doc) => SpacedRepetitionData.fromMap(doc.data()))
        .toList();
  }

  Future<void> processReview(
      String wordId,
      String courseId,
      String userId,
      int quality,
      ) async {
    final docRef = _db
        .collection('users')
        .doc(userId)
        .collection('learned_words')
        .doc(wordId);

    final doc = await docRef.get();
    SpacedRepetitionData data;

    if (doc.exists) {
      data = SpacedRepetitionData.fromMap(doc.data()!);
    } else {
      data = SpacedRepetitionData.initial(wordId, courseId);
    }

    final updated = data.update(quality);
    await docRef.set(updated.toMap());
  }
}