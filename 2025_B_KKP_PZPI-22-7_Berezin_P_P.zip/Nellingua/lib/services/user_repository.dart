import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/user_model.dart';

class UserRepository {
  static final FirebaseFirestore _db = FirebaseFirestore.instance;
  static final FirebaseAuth _auth = FirebaseAuth.instance;

  static Future<void> initialize() async {
    // Ініціалізація, якщо потрібно
  }

  static Future<AppUser?> getCurrentUser() async {
    final user = _auth.currentUser;
    if (user == null) {
      //print('[DEBUG] UserRepository.getCurrentUser: firebaseUser is null');
      return null;
    }

    //print('[DEBUG] Firebase user: ${user.uid} (${user.email})');

    try {
      final doc = await _db.collection('users').doc(user.uid).get();
      //print('[DEBUG] UserRepository.getCurrentUser: doc exists = ${doc.exists}, data = ${doc.data()}');

      if (!doc.exists) {
        //print('[DEBUG] No Firestore document found for user ${user.uid}');
        return null;
      }

      return AppUser.fromFirestore(doc.data()!, user.uid);
    } catch (e, stackTrace) {
      //print('[DEBUG] UserRepository.getCurrentUser error: $e');
      //print('[DEBUG] Stack trace: $stackTrace');
      return null;
    }
  }

  static Future<void> saveUser(AppUser user) async {
    try {
      //print('[DEBUG] UserRepository.saveUser: saving user = ${user.toMap()}');
      await _db.collection('users').doc(user.uid).set(user.toMap(), SetOptions(merge: true));
      //print('[DEBUG] UserRepository.saveUser: user saved successfully');
    } catch (e, stackTrace) {
      //print('[DEBUG] UserRepository.saveUser error: $e');
      //print('[DEBUG] Stack trace: $stackTrace');
      rethrow;
    }
  }

  static Future<void> updateCurrentCourse(String userId, String courseId) async {
    try {
      //print('[DEBUG] UserRepository.updateCurrentCourse: userId = $userId, courseId = $courseId');
      await _db.collection('users').doc(userId).update({
        'currentCourseId': courseId,
      });
      //print('[DEBUG] UserRepository.updateCurrentCourse: course updated successfully');
    } catch (e, stackTrace) {
      //print('[DEBUG] UserRepository.updateCurrentCourse error: $e');
      //print('[DEBUG] Stack trace: $stackTrace');
      rethrow;
    }
  }

  static Future<void> enrollInCourse(String userId, String courseId) async {
    try {
      //print('[DEBUG] UserRepository.enrollInCourse: userId = $userId, courseId = $courseId');
      await _db.collection('users').doc(userId).update({
        'enrolledCourses': FieldValue.arrayUnion([courseId]),
        'currentCourseId': courseId,
      });
      //print('[DEBUG] UserRepository.enrollInCourse: course enrolled successfully');
    } catch (e, stackTrace) {
      //print('[DEBUG] UserRepository.enrollInCourse error: $e');
      //print('[DEBUG] Stack trace: $stackTrace');
      rethrow;
    }
  }

  static Future<void> addGems(String uid, int amount) async {
    await _db.collection('users').doc(uid).update({
      'gems': FieldValue.increment(amount),
    });
  }

  static Future<int> getGems(String uid) async {
    final doc = await _db.collection('users').doc(uid).get();
    return (doc.data()?['gems'] as int?) ?? 0;
  }

  static Future<void> deleteAccount(String userId) async {
    try {
      //print('[DEBUG] UserRepository.deleteAccount: userId = $userId');
      await _db.collection('users').doc(userId).delete();
      await _auth.currentUser?.delete();
      //print('[DEBUG] UserRepository.deleteAccount: account deleted successfully');
    } catch (e, stackTrace) {
      //print('[DEBUG] UserRepository.deleteAccount error: $e');
      //print('[DEBUG] Stack trace: $stackTrace');
      rethrow;
    }
  }
}