import 'package:flutter/material.dart';
import '../models/assemble_character_model.dart';
import 'draggable_component.dart';
import 'tianzige_painter.dart';

class AssembleCharacterSlide extends StatefulWidget {
  final List<AssembleCharacter> characters;
  final VoidCallback onTaskCompleted;

  const AssembleCharacterSlide({
    super.key,
    required this.characters,
    required this.onTaskCompleted,
  });

  @override
  State<AssembleCharacterSlide> createState() => _AssembleCharacterSlideState();
}

class _AssembleCharacterSlideState extends State<AssembleCharacterSlide> {
  int currentIndex = 0;
  final Map<String, Rect> placedComponents = {};
  final List<String> availableComponents = [];
  final GlobalKey _dropFieldKey = GlobalKey();
  final GlobalKey _stackKey = GlobalKey(); // 🔹 Додали ключ для Stack

  @override
  void initState() {
    super.initState();
    _loadAvailableComponents();
  }

  void _loadAvailableComponents() {
    availableComponents.clear();
    availableComponents.addAll(
        widget.characters[currentIndex].components.map((e) => e.graph));
  }

  bool get isCurrentCharacterComplete {
    const scale = 300.0;
    const tolerance = 25.0;

    final current = widget.characters[currentIndex];
    final RenderBox? tianzigeBox = _dropFieldKey.currentContext
        ?.findRenderObject() as RenderBox?;
    final RenderBox? stackBox = _stackKey.currentContext
        ?.findRenderObject() as RenderBox?;
    if (tianzigeBox == null || stackBox == null) return false;

    // 🔹 Знаходимо позицію тяньцзиґе відносно Stack
    final Offset tianzigeInStack = stackBox.globalToLocal(
        tianzigeBox.localToGlobal(Offset.zero));

    return current.components.every((component) {
      final placed = placedComponents[component.graph];
      if (placed == null) return false;

      // 🔹 Обчислюємо позицію placed відносно тяньцзиґе
      final Offset localTopLeft = Offset(
        placed.left - tianzigeInStack.dx,
        placed.top - tianzigeInStack.dy,
      );

      final Rect localPlaced = Rect.fromLTWH(
        localTopLeft.dx,
        localTopLeft.dy,
        placed.width,
        placed.height,
      );

      final Rect target = Rect.fromLTWH(
        component.targetRect.left * scale,
        component.targetRect.top * scale,
        component.targetRect.width * scale,
        component.targetRect.height * scale,
      );

      return (localPlaced.center - target.center).distance < tolerance &&
          (localPlaced.width - target.width).abs() < 20 &&
          (localPlaced.height - target.height).abs() < 20;
    });
  }

  void _checkCompletion() {
    final scaffoldMessenger = ScaffoldMessenger.maybeOf(context);
    if (isCurrentCharacterComplete) {
      if (currentIndex < widget.characters.length - 1) {
        setState(() {
          currentIndex++;
          placedComponents.clear();
          _loadAvailableComponents();
        });
      } else {
        widget.onTaskCompleted();
      }
    } else {
      scaffoldMessenger?.showSnackBar(
        const SnackBar(content: Text(
            'Склади ієрогліф точно — перевір розташування графем.')),
      );
    }
  }

  void _handlePlaced(String graph, Rect rect) {
    setState(() {
      placedComponents[graph] = rect;
      availableComponents.remove(graph);
    });
  }

  void _handleReturnedToBank(String graph) {
    setState(() {
      placedComponents.remove(graph);
      if (!availableComponents.contains(graph)) {
        availableComponents.add(graph);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final currentChar = widget.characters[currentIndex];

    return Stack(
      key: _stackKey, // 🔹 Додаємо ключ тут
      alignment: Alignment.topCenter,
      children: [
        // 🔹 DragTarget на всю область як fallback
        Positioned.fill(
          child: DragTarget<String>(
            builder: (context, candidateData, rejectedData) =>
            const SizedBox.expand(),
            onAcceptWithDetails: (details) {
              final RenderBox box = context.findRenderObject() as RenderBox;
              final local = box.globalToLocal(details.offset);

              final screenSize = MediaQuery
                  .of(context)
                  .size;
              final double width = 60,
                  height = 60;

              final dx = local.dx.clamp(0.0, screenSize.width - width);
              final dy = local.dy.clamp(0.0, screenSize.height - height);

              _handlePlaced(
                details.data,
                Rect.fromLTWH(dx, dy, width, height),
              );
            },
          ),
        ),

        // 🔸 Вміст: тяньцзиґе та панель графем
        Align(
          alignment: Alignment.center,
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(vertical: 24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text("Ієрогліф: ${currentChar.character}", style: Theme.of(context).textTheme.headlineSmall),
                const SizedBox(height: 8),

                // Tianzige area
                SizedBox(
                  key: _dropFieldKey,
                  width: 300,
                  height: 300,
                  child: Stack(
                    children: [
                      CustomPaint(
                        size: const Size(300, 300),
                        painter: TianzigePainter(
                          componentRects: currentChar.components.map((e) => e.targetRect).toList(),
                        ),
                      ),
                      Positioned.fill(
                        child: DragTarget<String>(
                          builder: (context, candidateData, rejectedData) => const SizedBox.expand(),
                          onAcceptWithDetails: (details) {
                            final RenderBox box = context.findRenderObject() as RenderBox;
                            final local = box.globalToLocal(details.offset);

                            final parentBox = context.findAncestorRenderObjectOfType<RenderBox>()!;
                            final offsetInStack = parentBox.globalToLocal(details.offset);

                            final screenSize = MediaQuery.of(context).size;
                            const double width = 60, height = 60;

                            final dx = offsetInStack.dx.clamp(0.0, screenSize.width - width);
                            final dy = offsetInStack.dy.clamp(0.0, screenSize.height - height);

                            _handlePlaced(
                              details.data,
                              Rect.fromLTWH(dx, dy, width, height),
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 20),

                // Component bank
                Container(
                  padding: const EdgeInsets.all(12),
                  margin: const EdgeInsets.symmetric(horizontal: 8),
                  decoration: BoxDecoration(
                    color: Colors.yellow.shade100,
                    border: Border.all(color: Colors.amber, width: 2),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Wrap(
                    spacing: 8,
                    children: availableComponents.map((graph) {
                      return Draggable<String>(
                        data: graph,
                        feedback: Material(
                          color: Colors.transparent,
                          child: Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              border: Border.all(width: 2),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Text(graph, style: const TextStyle(fontSize: 24)),
                          ),
                        ),
                        childWhenDragging: const SizedBox.shrink(),
                        child: Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            border: Border.all(width: 2),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Text(graph, style: const TextStyle(fontSize: 24)),
                        ),
                      );
                    }).toList(),
                  ),
                ),

                const SizedBox(height: 20),

                ElevatedButton(
                  onPressed: _checkCompletion,
                  child: const Text("Перевірити"),
                ),
              ],
            ),
          ),
        ),

        // Розміщені графеми
        ...placedComponents.entries.map((entry) {
          return DraggableComponent(
            graph: entry.key,
            initialRect: entry.value,
            onMoved: (rect) => _handlePlaced(entry.key, rect),
            onReturnedToBank: () => _handleReturnedToBank(entry.key),
          );
        }),
      ],
    );
  }
}