import 'package:flutter/material.dart';
import '../models/sentence_model.dart';

class PromptWithTooltips extends StatefulWidget {
  final Sentence sentence;
  final bool isReverse;

  const PromptWithTooltips({
    Key? key,
    required this.sentence,
    required this.isReverse,
  }) : super(key: key);

  @override
  State<PromptWithTooltips> createState() => _PromptWithTooltipsState();
}

class _PromptWithTooltipsState extends State<PromptWithTooltips> {
  int? _activeIndex;

  @override
  Widget build(BuildContext context) {
    final textStyle = Theme.of(context).textTheme.bodyLarge;

    final sentenceText = widget.isReverse
        ? widget.sentence.native.defaultOptions.first.sentence
        : widget.sentence.foreign.defaultOptions.first.sentence;

    final highlights = widget.isReverse
        ? widget.sentence.native.defaultOptions.first.highlightedWords
        : widget.sentence.foreign.defaultOptions.first.highlightedWords;

    final spans = <InlineSpan>[];
    int lastIndex = 0;

    for (int i = 0; i < highlights.length; i++) {
      final hw = highlights[i];
      if (hw.from > lastIndex) {
        spans.add(TextSpan(
          text: sentenceText.substring(lastIndex, hw.from),
          style: textStyle,
        ));
      }

      final highlightedText = sentenceText.substring(hw.from, hw.to + 1);
      spans.add(WidgetSpan(
        alignment: PlaceholderAlignment.middle,
        child: GestureDetector(
          onTap: () {
            setState(() => _activeIndex = _activeIndex == i ? null : i);
          },
          child: MouseRegion(
            onEnter: (_) => setState(() => _activeIndex = i),
            onExit: (_) => setState(() => _activeIndex = null),
            cursor: SystemMouseCursors.click,
            child: Stack(
              clipBehavior: Clip.none,
              alignment: Alignment.center,
              children: [
                Text(
                  highlightedText,
                  style: textStyle?.copyWith(
                    decoration: TextDecoration.underline,
                    decorationStyle: TextDecorationStyle.dotted,
                  ),
                ),
                if (_activeIndex == i)
                  Positioned(
                    top: 24,
                    child: Material(
                      color: Colors.transparent,
                      child: Container(
                        margin: const EdgeInsets.only(top: 4),
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: Colors.black87,
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: hw.translationOptions
                              .map((t) => Text(
                            t,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 13,
                            ),
                          ))
                              .toList(),
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ));

      lastIndex = hw.to + 1;
    }

    if (lastIndex < sentenceText.length) {
      spans.add(TextSpan(
        text: sentenceText.substring(lastIndex),
        style: textStyle,
      ));
    }

    return RichText(text: TextSpan(children: spans));
  }
}