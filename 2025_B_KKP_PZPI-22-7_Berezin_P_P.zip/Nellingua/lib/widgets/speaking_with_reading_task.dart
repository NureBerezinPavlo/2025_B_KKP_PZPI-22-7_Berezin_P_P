import 'dart:io';
import 'dart:typed_data';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_sound/flutter_sound.dart';
import 'package:nellingua/widgets/prompt_with_tooltips.dart';
import 'package:permission_handler/permission_handler.dart';
import '../models/sentence_model.dart';
import 'audio_prompt_wrapper.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:http/http.dart' as http; // Для fetch на вебі
import '../l10n/app_localizations.dart';

class SpeakingWithReadingTask extends StatefulWidget {
  final Sentence sentence;
  final bool isReverseTranslation;
  final VoidCallback onTaskCompleted;
  final String courseId;

  const SpeakingWithReadingTask({
    Key? key,
    required this.sentence,
    required this.isReverseTranslation,
    required this.onTaskCompleted,
    required this.courseId,
  }) : super(key: key);

  @override
  State<SpeakingWithReadingTask> createState() => _SpeakingWithReadingTaskState();
}

class _SpeakingWithReadingTaskState extends State<SpeakingWithReadingTask> {
  final FlutterSoundRecorder _recorder = FlutterSoundRecorder();
  final FlutterSoundPlayer _player = FlutterSoundPlayer();
  String? _recordedPath;
  bool _isRecording = false;
  String? _feedback;
  bool _isProcessing = false;
  String? _languageCode; // мовний код для перетворення мови в текст

  // Мапа для перетворення target_language у мовний код
  static const Map<String, String> languageCodeMap = {
    'pl': 'pl-PL',
    'zh': 'zh-CN',
    'en': 'en-US',
    'uk': 'uk-UA',
    'fr': 'fr-FR',
    'de': 'de-DE',
    'es': 'es-ES',
  };

  @override
  void initState() {
    super.initState();
    _initRecorder();
    _player.openPlayer();
    _loadTargetLanguage();
  }

  Future<void> _loadTargetLanguage() async {
    try {
      final courseDoc = await FirebaseFirestore.instance
          .collection('courses')
          .doc(widget.courseId)
          .get();
      final targetLanguage = courseDoc.data()?['target_language'] as String? ?? 'en';
      setState(() {
        _languageCode = languageCodeMap[targetLanguage] ?? 'en-US';
      });
      //print('[_loadTargetLanguage] target_language=$targetLanguage, languageCode=$_languageCode');
    } catch (e) {
      //print('[_loadTargetLanguage] Помилка завантаження target_language: $e');
      setState(() {
        _languageCode = 'en-US'; // Запасний варіант
      });
    }
  }

  Future<void> _initRecorder() async {
    await Permission.microphone.request();
    await _recorder.openRecorder();

    if (kIsWeb) {
      await _recorder.setSubscriptionDuration(const Duration(milliseconds: 50));
    }
  }

  Future<void> _startOrStopRecording() async {
    if (_isRecording) {
      final path = await _recorder.stopRecorder();
      setState(() {
        _isRecording = false;
        _recordedPath = path;
        _isProcessing = true;
        _feedback = null;
      });
      if (path != null) {
        await _analyzeRecording(path);
      } else {
        setState(() {
          _feedback = 'Помилка: не отримано запис аудіо'; // TODO
          _isProcessing = false;
        });
      }
    } else {
      Codec codec = kIsWeb ? Codec.opusWebM : Codec.aacADTS;
      String fileExt = kIsWeb ? 'webm' : 'aac';

      await _recorder.startRecorder(
        toFile: 'tmp.$fileExt',
        codec: codec,
      );

      setState(() {
        _isRecording = true;
        _recordedPath = null;
        _feedback = null;
      });
    }
  }

  Future<void> _playRecording() async {
    if (_recordedPath != null) {
      await _player.startPlayer(fromURI: _recordedPath);
    }
  }

  Future<void> _analyzeRecording(String audioPathOrUri) async {
    final l10n = AppLocalizations.of(context)!; // локалізовані строки

    //print('[_analyzeRecording] Почали обробляти запис, path = $audioPathOrUri');
    try {
      Uint8List audioBytes;

      if (kIsWeb) {
        //print('[_analyzeRecording] Платформа = Web, робимо HTTP GET');
        final response = await http.get(Uri.parse(audioPathOrUri));
        //print('[_analyzeRecording] HTTP GET статус: ${response.statusCode}');
        if (response.statusCode == 200) {
          audioBytes = response.bodyBytes;
          //print('[_analyzeRecording] Отримали audioBytes, length=${audioBytes.length}');
        } else {
          throw Exception('Не вдалося завантажити аудіо з blob URI');
        }
      } else {
        //print('[_analyzeRecording] Платформа = Mobile, робимо File.readAsBytes');
        final audioFile = File(audioPathOrUri);
        audioBytes = await audioFile.readAsBytes();
        //print('[_analyzeRecording] Прочитали bytes з файлу, length=${audioBytes.length}');
      }

      //print('[_analyzeRecording] Викликаємо _recognizeSpeech');
      final recognizedText = await _recognizeSpeech(audioBytes);
      //print('[_analyzeRecording] Отримали результат від _recognizeSpeech: `$recognizedText`');

      final referenceText = widget.sentence.foreign.defaultOptions.first.sentence;
      //print('[_analyzeRecording] referenceText = "$referenceText"');
      final similarity = _calculateSimilarity(recognizedText, referenceText);
      //print('[_analyzeRecording] similarity = $similarity');

      setState(() {
        _feedback = similarity >= 0.7
            ? l10n.correctAnswer
            : l10n.tryAgainSpeakingTask((similarity * 100).toStringAsFixed(0));
        _isProcessing = false;
      });
      //print('[_analyzeRecording] Встановили _feedback="${_feedback!}" і _isProcessing=false');

      if (similarity >= 0.7) widget.onTaskCompleted();
    } catch (e) {
      //print('[_analyzeRecording] Ловимо помилку: $e');
      setState(() {
        _feedback = 'Помилка: ${e.toString()}';
        _isProcessing = false;
      });
      //print('[_analyzeRecording] Встановили _feedback (помилка) і _isProcessing=false');
    }
  }

  Future<String> _recognizeSpeech(Uint8List audioBytes) async {
    //print('[_recognizeSpeech] Починаємо завантажувати в Storage');
    try {
      final userId = FirebaseAuth.instance.currentUser?.uid;
      if (userId == null) {
        throw Exception('Користувач не автентифікований');
      }

      // Змінюємо шлях до user_audio/{userId}/{timestamp}.webm
      final ref = FirebaseStorage.instance
          .ref()
          .child('user_audio/$userId/${DateTime
          .now()
          .millisecondsSinceEpoch}.webm');
      //print('[_recognizeSpeech] Storage ref створено: ${ref.fullPath}');

      final uploadTask = ref.putData(audioBytes);
      //print('[_recognizeSpeech] Виклик ref.putData. Очікуємо завершення...');
      await uploadTask;
      //print('[_recognizeSpeech] Дані записані в Storage');

      final audioUrl = await ref.getDownloadURL();
      //print('[_recognizeSpeech] Отримали audioUrl=$audioUrl');

      final functions = FirebaseFunctions.instance;
      //print('[_recognizeSpeech] Викликаємо Cloud Function recognizeSpeech...');
      final result = await functions
          .httpsCallable('recognizeSpeech')
          .call({
            'audioUrl': audioUrl,
            'language': _languageCode ?? 'en-US',
          }
      );
      //print('[_recognizeSpeech] Функція повернула data=${result.data}');

      return result.data['transcript'] ?? '';
    } on FirebaseFunctionsException catch (e) {
      //print('[_recognizeSpeech] FirebaseFunctionsException: code=${e
      //    .code}, message=${e.message}');
      throw Exception('Speech recognition failed (Firebase): ${e.message}');
    } catch (e) {
      //print('[_recognizeSpeech] Інша помилка: $e');
      throw Exception('Speech recognition failed: $e');
    }
  }

  double _calculateSimilarity(String text1, String text2) {
    final words1 = _normalize(text1).split(' ');
    final words2 = _normalize(text2).split(' ');
    final matches = words1.where((w) => words2.contains(w)).length;
    return words2.isEmpty ? 0 : matches / words2.length;
  }

  String _normalize(String s) =>
      s.toLowerCase().replaceAll(RegExp(r'[^\w\s]'), '').trim();

  @override
  void dispose() {
    _recorder.closeRecorder();
    _player.closePlayer();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final chipBg = Theme.of(context).brightness == Brightness.dark
        ? Colors.grey[800]
        : Colors.grey[200];

    final l10n = AppLocalizations.of(context)!; // локалізовані строки

    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            l10n.repeatSentenceAloud,
            style: Theme.of(context).textTheme.titleMedium,
          ),
          const SizedBox(height: 12),

          Container(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
            decoration: BoxDecoration(
              color: chipBg,
              borderRadius: BorderRadius.circular(16),
            ),
            child: widget.isReverseTranslation
                ? PromptWithTooltips(
              sentence: widget.sentence,
              isReverse: widget.isReverseTranslation,
            )
                : AudioPromptWrapper(
              sentence: widget.sentence,
              isForeign: true,
              child: PromptWithTooltips(
                sentence: widget.sentence,
                isReverse: widget.isReverseTranslation,
              ),
            ),
          ),

          const SizedBox(height: 24),

          if (_isRecording)
            StreamBuilder<RecordingDisposition>(
              stream: _recorder.onProgress,
              builder: (context, snapshot) {
                if (!snapshot.hasData) {
                  return Container(height: 10, color: Colors.grey);
                }
                final decibels = snapshot.data!.decibels ?? 0.0;
                final barHeight = (decibels + 60).clamp(0, 100) / 100;

                return Container(
                  height: 10,
                  decoration: BoxDecoration(
                    color: Colors.greenAccent.withOpacity(0.5),
                  ),
                  child: FractionallySizedBox(
                    widthFactor: barHeight,
                    child: Container(color: Colors.green),
                  ),
                );
              },
            ),

          Row(
            children: [
              ElevatedButton.icon(
                onPressed: _isProcessing ? null : _startOrStopRecording,
                icon: Icon(_isRecording ? Icons.stop : Icons.mic, size: 28),
                label: Text(_isRecording ? l10n.stop : l10n.turnOnMicrophone),
                style: ElevatedButton.styleFrom(padding: const EdgeInsets.all(16)),
              ),
              const SizedBox(width: 12),
              IconButton(
                onPressed: _playRecording,
                icon: const Icon(Icons.play_arrow_rounded, size: 28),
                tooltip: 'Прослухати себе',
              ),
              const Spacer(),
              TextButton(
                onPressed: widget.onTaskCompleted,
                child: Text(l10n.skip),
              ),
            ],
          ),

          const SizedBox(height: 16),

          if (_feedback != null)
            Text(
              _feedback!,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: _feedback!.startsWith(l10n.correctAnswer) ? Colors.green : Colors.orange,
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
        ],
      ),
    );
  }
}