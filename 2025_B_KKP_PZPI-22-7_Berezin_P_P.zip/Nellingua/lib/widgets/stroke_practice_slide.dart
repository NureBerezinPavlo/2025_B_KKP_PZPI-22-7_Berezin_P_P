import 'dart:math';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:path_drawing/path_drawing.dart';
import '../utils/graphics_repository.dart';
import 'package:vector_math/vector_math_64.dart' as vec;
import '../models/stroke_practice_data.dart';
import 'package:provider/provider.dart';
import '../models/user_progress_model.dart';
import '../l10n/app_localizations.dart';

class StrokePracticeSlide extends StatefulWidget {
  final String character;
  final VoidCallback onTaskCompleted;
  final VoidCallback onReset; // Колбек для скидання taskCompleted
  final StrokePracticeData strokeData;

  const StrokePracticeSlide({
    Key? key,
    required this.character,
    required this.onTaskCompleted,
    required this.onReset,
    required this.strokeData,
  }) : super(key: key);

  @override
  State<StrokePracticeSlide> createState() => _StrokePracticeSlideState();
}

class _StrokePracticeSlideState extends State<StrokePracticeSlide>
    with TickerProviderStateMixin {
  List<List<String>> allStrokes = [];
  List<List<List<List<num>>>> allMedians = [];
  List<Offset> userPoints = [];
  int currentCharIndex = 0;
  int currentStrokeIndex = 0;
  bool _showFinalResult = false;
  bool _isAnimating = false;
  List<bool> completedCharacters = [];
  int _currentShowMode = 1;
  OverlayEntry? _modeSelectionOverlay;
  late AnimationController _charCompleteController;
  late Animation<double> _charCompleteAnimation;
  late AnimationController _charTransitionController;
  late Animation<double> _charTransitionAnimation;
  int _attemptsLeft = 4;
  List<Set<int>> skippedStrokesPerChar = [];
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  @override
  void initState() {
    super.initState();
    _currentShowMode = widget.strokeData.showMode;
    skippedStrokesPerChar = List.generate(widget.character.runes.length, (_) => {});
    _charCompleteController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );
    _charTransitionController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
    _loadStrokes();
    _loadShowMode();
  }

  Future<void> _loadStrokes() async {
    final characters = widget.character.runes.map((rune) => String.fromCharCode(rune)).toList();
    completedCharacters = List.filled(characters.length, false);
    for (final char in characters) {
      final strokes = await GraphicsRepository.getStrokes(char);
      final medians = await GraphicsRepository.getMedians(char);
      allStrokes.add(strokes);
      allMedians.add(medians);
    }
    if (mounted) setState(() {});
  }

  Future<void> _loadShowMode() async {
    try {
      final userId = Provider.of<UserProgressModel>(context, listen: false).userId;
      if (userId.isEmpty) return;
      final doc = await _db.collection('user_progress').doc(userId).get();
      final settings = doc.data()?['settings'] as Map<String, dynamic>?;
      final savedMode = settings?['strokePracticeShowMode'] as int?;
      if (savedMode != null && mounted) {
        setState(() {
          _currentShowMode = savedMode;
        });
      }
    } catch (e) {
      //print('[DEBUG] Error loading showMode: $e');
    }
  }

  Future<void> _saveShowMode(int mode) async {
    try {
      final userId = Provider.of<UserProgressModel>(context, listen: false).userId;
      if (userId.isEmpty) return;
      await _db.collection('user_progress').doc(userId).set({
        'settings': {
          'strokePracticeShowMode': mode,
        },
      }, SetOptions(merge: true));
      //print('[DEBUG] Saved showMode: $mode for userId=$userId');
    } catch (e) {
      //print('[DEBUG] Error saving showMode: $e');
    }
  }

  void _onPanStart(DragStartDetails details, Size size) {
    if (_isAnimating) return;
    final localPosition = details.localPosition;
    setState(() {
      userPoints = [localPosition];
    });
  }

  void _onPanUpdate(DragUpdateDetails details, Size size) {
    if (_isAnimating) return;
    final localPosition = details.localPosition;
    setState(() {
      userPoints.add(localPosition);
    });
  }

  void _onPanEnd(Size size) async {
    if (_isAnimating) return;
    if (currentCharIndex >= allStrokes.length) {
      _showFinalResults();
      return;
    }
    if (currentStrokeIndex >= allStrokes[currentCharIndex].length) {
      await _charCompleteController.forward(from: 0);
      await _completeCurrentCharacter();
      return;
    }
    final mappedStroke = _mapUserStrokeToOriginal(userPoints, size);
    final isCorrect = _validateStroke(mappedStroke, allMedians[currentCharIndex][currentStrokeIndex]);
    if (isCorrect) {
      setState(() {
        currentStrokeIndex++;
        userPoints.clear();
        _attemptsLeft = 4;
      });
    } else {
      setState(() {
        userPoints.clear();
        _attemptsLeft--;
        if (_attemptsLeft <= 0) {
          skippedStrokesPerChar[currentCharIndex].add(currentStrokeIndex);
          currentStrokeIndex++;
          _attemptsLeft = 4;
        }
      });
    }
  }

  List<Offset> _mapUserStrokeToOriginal(List<Offset> stroke, Size size) {
    return stroke.map((p) => _transformBack(p, size)).toList();
  }

  Offset _transformBack(Offset point, Size size) {
    final double scale = size.width / 1024;
    final Matrix4 matrix = Matrix4.identity()
      ..translate(0.0, size.height)
      ..scale(scale, -scale);
    final Matrix4 inverse = Matrix4.inverted(matrix);
    final vec.Vector3 result = inverse.transform3(vec.Vector3(point.dx, point.dy, 0));
    return Offset(result.x, result.y);
  }

  bool _validateStroke(List<Offset> userStroke, List<List<num>> median) {
    if (userStroke.length < 2 || median.length < 2) return false;
    final userVector = userStroke.last - userStroke.first;
    final medianVector = Offset(
      median.last[0].toDouble() - median.first[0].toDouble(),
      median.last[1].toDouble() - median.first[1].toDouble(),
    );
    final userDir = userVector.direction;
    final medianDir = medianVector.direction;
    const maxAngleDiff = 0.52;
    if ((userDir - medianDir).abs() > maxAngleDiff) {
      //print("Напрямок не співпадає: user=$userDir, median=$medianDir");
      return false;
    }
    final medianPoints = median.map((p) => Offset(p[0].toDouble(), p[1].toDouble())).toList();
    double maxDistance = 0;
    for (final point in userStroke) {
      final nearest = _findNearestPoint(point, medianPoints);
      final distance = (point - nearest).distance;
      maxDistance = max(maxDistance, distance);
      if (distance > 100) return false;
    }
    final medianLength = _calculatePathLength(medianPoints);
    final userLength = _calculatePathLength(userStroke);
    if (userLength < medianLength * 0.5) {
      //print("Довжина занадто мала: $userLength < ${medianLength * 0.5}");
      return false;
    }
    return true;
  }

  double _calculatePathLength(List<Offset> points) {
    double length = 0;
    for (int i = 1; i < points.length; i++) {
      length += (points[i] - points[i - 1]).distance;
    }
    return length;
  }

  Offset _findNearestPoint(Offset point, List<Offset> medianPoints) {
    double minDist = double.infinity;
    Offset nearest = medianPoints.first;
    for (int i = 1; i < medianPoints.length; i++) {
      final segmentStart = medianPoints[i - 1];
      final segmentEnd = medianPoints[i];
      final closest = _closestPointOnSegment(point, segmentStart, segmentEnd);
      final dist = (point - closest).distance;
      if (dist < minDist) {
        minDist = dist;
        nearest = closest;
      }
    }
    return nearest;
  }

  Offset _closestPointOnSegment(Offset p, Offset a, Offset b) {
    final ap = p - a;
    final ab = b - a;
    final t = (ap.dx * ab.dx + ap.dy * ab.dy) / (ab.dx * ab.dx + ab.dy * ab.dy);
    if (t <= 0) return a;
    if (t >= 1) return b;
    return a + ab * t;
  }

  @override
  Widget build(BuildContext context) {
    return _buildPracticeContent();
  }

  Widget _buildPracticeContent() {
    final colorScheme = Theme.of(context).colorScheme;
    if (allStrokes.isEmpty) {
      return Center(child: CircularProgressIndicator(color: colorScheme.primary));
    }
    if (_showFinalResult) {
      return _buildFinalResultsScreen();
    }
    return SingleChildScrollView(
      child: Column(
        children: [
          if (widget.strokeData.allowModeSwitch)
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Align(
                alignment: Alignment.topRight,
                child: IconButton(
                  icon: Icon(Icons.settings, color: colorScheme.onSurface),
                  onPressed: _showModeSelectionMenu,
                ),
              ),
            ),
          _buildProgressIndicator(),
          const SizedBox(height: 20),
          _buildDrawingArea(),
        ],
      ),
    );
  }

  Widget _buildDrawingArea() {
    return ConstrainedBox(
      constraints: BoxConstraints(
        maxWidth: MediaQuery.of(context).size.width * 0.9,
        maxHeight: MediaQuery.of(context).size.height * 0.6,
      ),
      child: AspectRatio(
        aspectRatio: 1,
        child: LayoutBuilder(
          builder: (context, constraints) {
            final size = Size(constraints.maxWidth, constraints.maxWidth);
            return GestureDetector(
              onPanStart: (d) => _onPanStart(d, size),
              onPanUpdate: (d) => _onPanUpdate(d, size),
              onPanEnd: (_) => _onPanEnd(size),
              child: AnimatedBuilder(
                animation: _charCompleteController,
                builder: (context, child) {
                  final jumpOffset = -10 * sin(_charCompleteController.value * pi);
                  return Transform.translate(
                    offset: Offset(0, jumpOffset),
                    child: child,
                  );
                },
                child: CustomPaint(
                  painter: StrokePainter(
                    strokes: allStrokes[currentCharIndex],
                    userStroke: userPoints,
                    currentStroke: currentStrokeIndex,
                    showMode: _currentShowMode,
                    skippedStrokes: skippedStrokesPerChar[currentCharIndex],
                    colorScheme: Theme.of(context).colorScheme,
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  void _showModeSelectionMenu() {
    final l10n = AppLocalizations.of(context)!; // локалізовані строки

    final colorScheme = Theme.of(context).colorScheme;
    final overlay = OverlayEntry(
      builder: (context) => Positioned(
        right: 16,
        top: 16,
        child: Material(
          elevation: 4,
          color: colorScheme.surface,
          borderRadius: BorderRadius.circular(8),
          child: Column(
            children: [
              _buildModeButton(l10n.strokePracticeMode1, 0, colorScheme),
              _buildModeButton(l10n.strokePracticeMode2, 1, colorScheme),
              _buildModeButton(l10n.strokePracticeMode3, 2, colorScheme),
            ],
          ),
        ),
      ),
    );
    _modeSelectionOverlay?.remove();
    _modeSelectionOverlay = overlay;
    Overlay.of(context).insert(overlay);
  }

  Widget _buildModeButton(String text, int mode, ColorScheme colorScheme) {
    return InkWell(
      onTap: () {
        setState(() => _currentShowMode = mode);
        _saveShowMode(mode);
        _modeSelectionOverlay?.remove();
        _modeSelectionOverlay = null;
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        color: _currentShowMode == mode ? colorScheme.primaryContainer : null,
        child: Row(
          children: [
            Icon(
              _currentShowMode == mode
                  ? Icons.radio_button_checked
                  : Icons.radio_button_off,
              size: 20,
              color: colorScheme.onSurface,
            ),
            const SizedBox(width: 8),
            Text(
              text,
              style: TextStyle(color: colorScheme.onSurface),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildProgressIndicator() {
    final chars = widget.character.runes.map((r) => String.fromCharCode(r)).toList();
    final colorScheme = Theme.of(context).colorScheme;
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(chars.length, (index) {
        final isCompleted = completedCharacters[index];
        final isCurrent = index == currentCharIndex;
        if (isCompleted) {
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 6.0),
            child: Text(
              chars[index],
              style: TextStyle(
                fontSize: 36,
                color: colorScheme.primary,
              ),
            ),
          );
        } else {
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 6.0),
            child: Container(
              width: 32,
              height: 40,
              alignment: Alignment.bottomCenter,
              decoration: BoxDecoration(
                border: Border(
                  bottom: BorderSide(
                    width: 3,
                    color: isCurrent ? colorScheme.primary : colorScheme.outline,
                  ),
                ),
              ),
              child: isCurrent
                  ? Icon(
                Icons.edit,
                size: 20,
                color: colorScheme.primary,
              )
                  : null,
            ),
          );
        }
      }),
    );
  }

  Future<void> _completeCurrentCharacter() async {
    setState(() {
      _attemptsLeft = 4;
      _isAnimating = true;
      completedCharacters[currentCharIndex] = true;
    });
    await _charCompleteController.forward(from: 0);
    await _charTransitionController.forward(from: 0);
    setState(() {
      currentCharIndex++;
      currentStrokeIndex = 0;
      _isAnimating = false;
    });
    _charCompleteController.reset();
    _charTransitionController.reset();
    if (currentCharIndex >= allStrokes.length) {
      _showFinalResults();
    }
  }

  void _showFinalResults() {
    if (mounted) {
      setState(() {
        _showFinalResult = true;
      });
    }
    widget.onTaskCompleted();
  }

  Widget _buildFinalResultsScreen() {
    final l10n = AppLocalizations.of(context)!; // локалізовані строки

    final colorScheme = Theme.of(context).colorScheme;
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            l10n.strokePracticeCompleted,
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
              color: colorScheme.onSurface,
            ),
          ),
          const SizedBox(height: 30),
          Container(
            height: 200,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(widget.character.runes.length, (index) {
                  final strokes = allStrokes[index];
                  final skipped = skippedStrokesPerChar[index];
                  return Container(
                    width: 150,
                    margin: const EdgeInsets.symmetric(horizontal: 10),
                    child: CustomPaint(
                      painter: CharacterPreviewPainter(
                        strokes: strokes,
                        allStrokes: true,
                        skippedStrokes: skipped,
                      ),
                    ),
                  );
                }),
              ),
            ),
          ),
          const SizedBox(height: 40),
          ElevatedButton(
            onPressed: _resetPractice,
            child: Text(l10n.restart, style: TextStyle(fontSize: 18)),
            style: ElevatedButton.styleFrom(
              padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 15),
              backgroundColor: colorScheme.secondary,
              foregroundColor: colorScheme.onSecondary,
            ),
          ),
        ],
      ),
    );
  }

  void _resetPractice() {
    setState(() {
      _attemptsLeft = 4;
      skippedStrokesPerChar = List.generate(widget.character.runes.length, (_) => {});
      currentCharIndex = 0;
      currentStrokeIndex = 0;
      _showFinalResult = false;
      completedCharacters = List.filled(widget.character.runes.length, false);
      userPoints.clear();
    });
    widget.onReset();
  }

  @override
  void dispose() {
    _charCompleteController.dispose();
    _charTransitionController.dispose();
    _modeSelectionOverlay?.remove();
    super.dispose();
  }
}

class StrokePainter extends CustomPainter {
  final List<String> strokes;
  final List<Offset> userStroke;
  final int currentStroke;
  final int showMode;
  final Set<int> skippedStrokes;
  final ColorScheme colorScheme;

  StrokePainter({
    required this.strokes,
    required this.userStroke,
    required this.currentStroke,
    required this.showMode,
    required this.skippedStrokes,
    required this.colorScheme,
  });

  @override
  void paint(Canvas canvas, Size size) {
    _drawTianzigeGrid(canvas, size);
    final strokePaint = Paint()
      ..strokeWidth = 4
      ..style = PaintingStyle.stroke;
    final fillPaint = Paint()
      ..style = PaintingStyle.fill;
    final double scale = size.width / 1024;
    final Matrix4 transformMatrix = Matrix4.identity()
      ..translate(0.0, size.height)
      ..scale(scale, -scale);

    for (int i = 0; i < strokes.length; i++) {
      final isCurrent = (i == currentStroke);
      final isPast = (i < currentStroke);
      final isSkipped = skippedStrokes.contains(i);
      bool shouldDraw = false;
      switch (showMode) {
        case 0:
          shouldDraw = true;
          break;
        case 1:
          shouldDraw = isCurrent || isPast;
          break;
        case 2:
          shouldDraw = isPast;
          break;
      }
      if (shouldDraw) {
        final path = parseSvgPathData(strokes[i]);
        final transformedPath = path.transform(transformMatrix.storage);
        if (isSkipped) {
          fillPaint.color = colorScheme.error.withOpacity(0.8);
          strokePaint.color = colorScheme.outline;
        } else if (isPast) {
          fillPaint.color = colorScheme.primary.withOpacity(0.4);
          strokePaint.color = colorScheme.primary;
        } else if (isCurrent) {
          fillPaint.color = colorScheme.onSurface.withOpacity(0.7);
          strokePaint.color = colorScheme.onSurface.withOpacity(0.7);
        } else {
          fillPaint.color = colorScheme.onSurface.withOpacity(0.1);
          strokePaint.color = colorScheme.onSurface.withOpacity(0.24);
        }
        canvas.drawPath(transformedPath, fillPaint);
        canvas.drawPath(transformedPath, strokePaint);
      }
    }

    if (userStroke.length > 1) {
      final paintUser = Paint()
        ..color = colorScheme.secondary
        ..strokeWidth = 12
        ..style = PaintingStyle.stroke;
      final path = Path()..moveTo(userStroke.first.dx, userStroke.first.dy);
      for (int i = 1; i < userStroke.length; i++) {
        path.lineTo(userStroke[i].dx, userStroke[i].dy);
      }
      canvas.drawPath(path, paintUser);
    }
  }

  void _drawTianzigeGrid(Canvas canvas, Size size) {
    final gridPaint = Paint()
      ..color = Colors.grey.withOpacity(0.2)
      ..strokeWidth = 1
      ..style = PaintingStyle.stroke;
    final mainGridPaint = Paint()
      ..color = Colors.grey.withOpacity(0.4)
      ..strokeWidth = 1.5
      ..style = PaintingStyle.stroke;
    canvas.drawLine(
      Offset(size.width / 2, 0),
      Offset(size.width / 2, size.height),
      gridPaint,
    );
    canvas.drawLine(
      Offset(0, size.height / 2),
      Offset(size.width, size.height / 2),
      gridPaint,
    );
    canvas.drawLine(
      Offset(0, 0),
      Offset(size.width, size.height),
      gridPaint,
    );
    canvas.drawLine(
      Offset(size.width, 0),
      Offset(0, size.height),
      gridPaint,
    );
  }

  @override
  bool shouldRepaint(covariant StrokePainter oldDelegate) {
    return oldDelegate.userStroke != userStroke ||
        oldDelegate.currentStroke != currentStroke ||
        oldDelegate.showMode != showMode;
  }
}

class CharacterPreviewPainter extends CustomPainter {
  final List<String> strokes;
  final bool allStrokes;
  final Set<int> skippedStrokes;

  CharacterPreviewPainter({
    required this.strokes,
    required this.allStrokes,
    required this.skippedStrokes,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final strokePaint = Paint()
      ..color = Colors.green
      ..strokeWidth = 3
      ..style = PaintingStyle.stroke;
    final fillPaint = Paint()
      ..color = Colors.green.withOpacity(0.2)
      ..style = PaintingStyle.fill;
    final double scale = size.width / 1024;
    final Matrix4 transformMatrix = Matrix4.identity()
      ..translate(0.0, size.height)
      ..scale(scale, -scale);
    for (int i = 0; i < strokes.length; i++) {
      final path = parseSvgPathData(strokes[i]);
      final transformedPath = path.transform(transformMatrix.storage);
      if (skippedStrokes.contains(i)) {
        fillPaint.color = Colors.deepOrangeAccent.withOpacity(0.8);
        strokePaint.color = Colors.red;
      } else {
        fillPaint.color = Colors.green.withOpacity(0.2);
        strokePaint.color = Colors.green;
      }
      canvas.drawPath(transformedPath, fillPaint);
      canvas.drawPath(transformedPath, strokePaint);
    }
  }

  @override
  bool shouldRepaint(covariant CharacterPreviewPainter oldDelegate) {
    return oldDelegate.strokes != strokes;
  }
}