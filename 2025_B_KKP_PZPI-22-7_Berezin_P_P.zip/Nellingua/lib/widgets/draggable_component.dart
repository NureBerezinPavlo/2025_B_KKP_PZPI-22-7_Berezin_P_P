import 'package:flutter/material.dart';
import 'package:path_drawing/path_drawing.dart';
import '../utils/graphics_repository.dart';

class DraggableComponent extends StatefulWidget {
  final String graph;
  final Rect initialRect;
  final void Function(Rect) onMoved;
  final VoidCallback onReturnedToBank;

  const DraggableComponent({
    super.key,
    required this.graph,
    required this.initialRect,
    required this.onMoved,
    required this.onReturnedToBank,
  });

  @override
  State<DraggableComponent> createState() => _DraggableComponentState();
}

class _DraggableComponentState extends State<DraggableComponent> {
  late Offset position;
  late Size size;
  bool resizing = false;

  @override
  void initState() {
    super.initState();
    position = Offset(widget.initialRect.left, widget.initialRect.top);
    size = Size(widget.initialRect.width, widget.initialRect.height);
  }

  void _updateParent() {
    widget.onMoved(Rect.fromLTWH(position.dx, position.dy, size.width, size.height));
  }

  @override
  Widget build(BuildContext context) {
    final screenSize = MediaQuery.of(context).size;

    return Positioned(
      left: position.dx,
      top: position.dy,
      child: GestureDetector(
        onPanUpdate: (details) {
          setState(() {
            if (resizing) {
              size = Size(
                (size.width + details.delta.dx).clamp(30, 300),
                (size.height + details.delta.dy).clamp(30, 300),
              );
            } else {
              final newPos = position + details.delta;

              // Обмеження по екрану
              final maxX = screenSize.width - size.width;
              final maxY = screenSize.height - size.height;

              position = Offset(
                newPos.dx.clamp(0.0, maxX),
                newPos.dy.clamp(0.0, maxY),
              );
            }
          });

          final isOutside = position.dy > 320;
          if (isOutside) {
            widget.onReturnedToBank();
          } else {
            _updateParent();
          }
        },
        onPanEnd: (_) {
          resizing = false;
        },
        onDoubleTap: () {
          setState(() => resizing = !resizing);
        },
        child: Container(
          width: size.width,
          height: size.height,
          decoration: BoxDecoration(
            border: Border.all(color: resizing ? Colors.blue : Colors.black, width: 2),
            borderRadius: BorderRadius.circular(8),
          ),
          alignment: Alignment.center,
          child: FutureBuilder<List<String>>(
            future: GraphicsRepository.getStrokes(widget.graph),
            builder: (context, snapshot) {
              if (!snapshot.hasData || snapshot.data!.isEmpty) {
                return Text(widget.graph, style: const TextStyle(fontSize: 48));
              }

              final allPaths = snapshot.data!;
              return CustomPaint(
                painter: GraphCharacterPainter(svgPathDataList: allPaths),
                size: Size.infinite,
              );
            },
          ),
        ),
      ),
    );
  }
}

class GraphCharacterPainter extends CustomPainter {
  final List<String> svgPathDataList;

  GraphCharacterPainter({required this.svgPathDataList});

  @override
  void paint(Canvas canvas, Size size) {
    final Paint strokePaint = Paint()
      ..color = Colors.white
      ..strokeWidth = 2
      ..style = PaintingStyle.stroke;

    final fillPaint = Paint()
      ..color = Colors.white
      ..style = PaintingStyle.fill;

    // Визначаємо bounding box для всіх шляхів
    Rect? totalBounds;
    final paths = <Path>[];

    for (final svgPathData in svgPathDataList) {
      final path = parseSvgPathData(svgPathData);
      paths.add(path);

      final bounds = path.getBounds();
      totalBounds = totalBounds == null
          ? bounds
          : totalBounds.expandToInclude(bounds);
    }

    if (totalBounds == null || totalBounds.isEmpty) return;

    // Обчислюємо масштаб для заповнення простору
    final scaleX = size.width / totalBounds.width;
    final scaleY = size.height / totalBounds.height;

    // Коригуємо позицію для точного центрування
    final offset = Offset(
      -totalBounds.left * scaleX,
      -totalBounds.top * scaleY,
    );

    final Matrix4 transform = Matrix4.identity()
      ..translate(offset.dx, size.height - offset.dy)  // Виправлено для коректного відображення
      ..scale(scaleX, -scaleY);  // Мінус перед scaleY для корекції відзеркалення

    for (final path in paths) {
      final transformed = path.transform(transform.storage);
      canvas.drawPath(transformed, fillPaint);
      canvas.drawPath(transformed, strokePaint);
    }
  }

  @override
  bool shouldRepaint(covariant GraphCharacterPainter oldDelegate) {
    return oldDelegate.svgPathDataList != svgPathDataList;
  }
}