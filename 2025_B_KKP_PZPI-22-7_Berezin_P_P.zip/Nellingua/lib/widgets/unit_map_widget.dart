import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:path_drawing/path_drawing.dart';

class UnitMapWidget extends StatelessWidget {
  final Map<String, dynamic> unitData;
  final Function(Map<String, dynamic>) onLevelTap;
  final int currentLevelIndex;
  final int currentUnitIndex;
  final int selectedUnitIndex;

  const UnitMapWidget({
    super.key,
    required this.unitData,
    required this.onLevelTap,
    required this.currentLevelIndex,
    required this.currentUnitIndex,
    required this.selectedUnitIndex,
  });

  @override
  Widget build(BuildContext context) {
    final levels = List<Map<String, dynamic>>.from(unitData['levels'] ?? []);
    final linePoints = List<Map<String, dynamic>>.from(unitData['linePoints'] ?? []);
    final lineColor = Color(unitData['lineColor'] ?? Colors.blue.value);

    return InteractiveViewer(
      boundaryMargin: const EdgeInsets.all(100),
      minScale: 0.5,
      maxScale: 2.0,
      child: Stack(
        children: [
          CustomPaint(
            size: Size.infinite,
            painter: _UnitMapPainter(
              levels: levels,
              linePoints: linePoints,
              lineColor: lineColor,
              currentLevelIndex: currentLevelIndex,
              currentUnitIndex: currentUnitIndex,
              selectedUnitIndex: selectedUnitIndex,
            ),
          ),
          ...levels.asMap().entries.map((entry) {
            final index = entry.key;
            final level = entry.value;
            final x = level['x'] ?? 0.0;
            final y = level['y'] ?? 0.0;
            final isLocked = selectedUnitIndex > currentUnitIndex || (selectedUnitIndex == currentUnitIndex && index > currentLevelIndex);

            return Positioned(
              left: x - 30,
              top: y - 30,
              child: GestureDetector(
                onTap: isLocked ? null : () => onLevelTap(level), // Блокуємо клік для заблокованих
                child: Container(
                  width: 60,
                  height: 60,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.transparent,
                  ),
                ),
              ),
            );
          }),
        ],
      ),
    );
  }
}

class _UnitMapPainter extends CustomPainter {
  final List<Map<String, dynamic>> levels;
  final List<Map<String, dynamic>> linePoints;
  final Color lineColor;
  final int currentLevelIndex;
  final int currentUnitIndex;
  final int selectedUnitIndex;

  _UnitMapPainter({
    required this.levels,
    required this.linePoints,
    required this.lineColor,
    required this.currentLevelIndex,
    required this.currentUnitIndex,
    required this.selectedUnitIndex,
  });

  @override
  void paint(Canvas canvas, Size size) {
    // Малюємо лінію з'єднання
    if (linePoints.length >= 2) {
      final path = Path();
      path.moveTo(linePoints[0]['x'], linePoints[0]['y']);

      for (int i = 1; i < linePoints.length; i++) {
        path.lineTo(linePoints[i]['x'], linePoints[i]['y']);
      }

      final paint = Paint()
        ..color = lineColor
        ..strokeWidth = 4
        ..style = PaintingStyle.stroke;

      canvas.drawPath(
        dashPath(
          path,
          dashArray: CircularIntervalList<double>([10.0, 5.0]),
        ),
        paint,
      );
    }

    for (var i = 0; i < levels.length; i++) {
      final level = levels[i];
      final type = level['type'] ?? 'theory';
      final x = level['x'] ?? 0.0;
      final y = level['y'] ?? 0.0;
      final isLocked = selectedUnitIndex > currentUnitIndex || (selectedUnitIndex == currentUnitIndex && i > currentLevelIndex);

      LevelColors colors;
      if (isLocked) {
        // Колір для заблокованих рівнів
        colors = LevelColors(
          backgroundColor: Colors.grey.shade300,
          borderColor: Colors.grey.shade500,
          textColor: Colors.grey.shade700,
        );
      } else {
        colors = _getLevelColors(type);
      }

      // Коло рівня
      final circlePaint = Paint()
        ..color = colors.backgroundColor
        ..style = PaintingStyle.fill;

      final borderPaint = Paint()
        ..color = colors.borderColor
        ..strokeWidth = 2
        ..style = PaintingStyle.stroke;

      canvas.drawCircle(Offset(x, y), 30, circlePaint);
      canvas.drawCircle(Offset(x, y), 30, borderPaint);

      // Іконка рівня або замок
      final icon = isLocked ? Icons.lock : _getLevelIcon(type);
      final textPainter = TextPainter(
        text: TextSpan(
          text: String.fromCharCode(icon.codePoint), // Використаємо іконку
          style: TextStyle(
            color: colors.textColor,
            fontSize: 24,
            fontFamily: 'MaterialIcons',
          ),
        ),
        textDirection: TextDirection.ltr,
      );
      textPainter.layout();
      textPainter.paint(
        canvas,
        Offset(x - textPainter.width / 2, y - textPainter.height / 2),
      );
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;

  LevelColors _getLevelColors(String type) {
    switch (type) {
      case 'practice':
        return LevelColors(
          backgroundColor: Colors.blue.shade50,
          borderColor: Colors.blue,
          textColor: Colors.blue.shade800,
        );
      case 'revision':
        return LevelColors(
          backgroundColor: Colors.orange.shade50,
          borderColor: Colors.orange,
          textColor: Colors.orange.shade800,
        );
      case 'final':
        return LevelColors(
          backgroundColor: Colors.purple.shade50,
          borderColor: Colors.purple,
          textColor: Colors.purple.shade800,
        );
      default: // theory
        return LevelColors(
          backgroundColor: Colors.green.shade50,
          borderColor: Colors.green,
          textColor: Colors.green.shade800,
        );
    }
  }

  IconData _getLevelIcon(String type) {
    switch (type) {
      case 'practice': return Icons.assignment;
      case 'revision': return Icons.repeat;
      case 'final': return Icons.star;
      default: return Icons.book;
    }
  }
}

class LevelColors {
  final Color backgroundColor;
  final Color borderColor;
  final Color textColor;

  LevelColors({
    required this.backgroundColor,
    required this.borderColor,
    required this.textColor,
  });
}