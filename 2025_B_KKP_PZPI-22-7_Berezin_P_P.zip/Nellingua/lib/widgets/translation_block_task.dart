import 'package:flutter/material.dart';
import '../models/sentence_model.dart';
import 'prompt_with_tooltips.dart';
import '../widgets/audio_prompt_wrapper.dart';
import '../l10n/app_localizations.dart';

class TranslationBlockTask extends StatefulWidget {
  final Sentence sentence;
  final bool isReverseTranslation;
  final VoidCallback onTaskCompleted;

  const TranslationBlockTask({
    Key? key,
    required this.sentence,
    required this.isReverseTranslation,
    required this.onTaskCompleted,
  }) : super(key: key);

  @override
  _TranslationBlockTaskState createState() => _TranslationBlockTaskState();
}

class _TranslationBlockTaskState extends State<TranslationBlockTask> {
  final GlobalKey _bankKey = GlobalKey();
  final GlobalKey _answerKey = GlobalKey();

  final Map<String, GlobalKey> _bankChipKeys = {};
  final Map<String, GlobalKey> _selectedChipKeys = {};

  List<String> _bankWords = [];
  List<String> _selectedWords = [];
  String? _flyingWord;
  String? _feedback; // тут зберігаємо результат перевірки

  @override
  void initState() {
    super.initState();
    _initializeWords();
  }

  void _initializeWords() {
    // Get TARGET sentence (opposite of prompt)
    final targetSentence = widget.isReverseTranslation
        ? widget.sentence.foreign.defaultOptions.first.sentence
        : widget.sentence.native.defaultOptions.first.sentence;

    // Розбиваємо на слова, видаляємо небажану пунктуацію, приводимо до нижнього регістру
    _bankWords = targetSentence
        .split(RegExp(r'\s+'))
        .map((w) => w
        .replaceAll(
        RegExp(r'''[!"#\$%&'()*+,\-–—./:;<=>?@[\\\]^_`{|}~«»…。，、”：„“”]'''),
        '')
        .toLowerCase())
        .where((w) => w.isNotEmpty)
        .toList()
      ..shuffle();
  }

  Future<void> _flyChip({
    required Offset from,
    required Offset to,
    required String word,
  }) async {
    final overlay = Overlay.of(context)!;

    final entry = OverlayEntry(builder: (_) {
      return _FlyingChip(
        word: word,
        start: from,
        end: to,
        color: Theme
            .of(context)
            .colorScheme
            .primary
            .withOpacity(0.8),
      );
    });

    overlay.insert(entry);
    await Future.delayed(const Duration(milliseconds: 500));
    entry.remove();
  }

  BuildContext? _findChipContext(String word, {required bool inSelected}) {
    final keyList = inSelected
        ? _selectedWords
        : _bankWords;

    // Reverse order ensures we find the last match if word appears multiple times
    for (final element in keyList.reversed) {
      if (element == word) {
        final index = keyList.lastIndexOf(word);
        final context = (inSelected
            ? (_answerKey.currentContext as Element?)
            : (_bankKey.currentContext as Element?));
        if (context == null) return null;

        final renderObject = context.renderObject;
        if (renderObject is RenderBox) {
          final box = renderObject;
          return box.attached ? context : null;
        }
      }
    }
    return null;
  }

  void _onTapWord(GlobalKey originKey, String word) async {
    if (_feedback != null) return;

    final isSelected = _selectedWords.contains(word);

    final fromBox = originKey.currentContext!.findRenderObject() as RenderBox;
    final originCoords = fromBox.localToGlobal(Offset.zero);

    setState(() {
      _flyingWord = word; // Hide the word temporarily
      if (isSelected) {
        _selectedWords.remove(word);
        _bankWords.add(word);
      } else {
        _bankWords.remove(word);
        _selectedWords.add(word);
      }
    });

    await WidgetsBinding.instance.endOfFrame;

    GlobalKey targetKey = isSelected
        ? _bankChipKeys[word]!
        : _selectedChipKeys[word]!;

    final toBox = targetKey.currentContext?.findRenderObject() as RenderBox?;
    final destinationCoords = toBox?.localToGlobal(Offset.zero) ?? originCoords;

    await _flyChip(
      from: originCoords,
      to: destinationCoords,
      word: word,
    );

    setState(() {
      _flyingWord = null; // Reveal the word again
    });
  }

  void _checkAnswer() {
    final l10n = AppLocalizations.of(context)!; // локалізовані строки

    final built = _selectedWords.join(' ').trim();
    // вибираємо правильні варіанти для порівняння
    final correct = widget.isReverseTranslation
        ? widget.sentence.foreign.defaultOptions.map((s) => s.sentence).toList()
        : widget.sentence.native.defaultOptions.map((s) => s.sentence).toList();
    final alts = widget.isReverseTranslation
        ? widget.sentence.foreign.alternativeOptions
        : widget.sentence.native.alternativeOptions;

    final norm = (String s) => s
        .replaceAll(RegExp(r'[^\p{L}\p{N}\s]', unicode: true), '') // зберігаємо лише літери та цифри
        .toLowerCase()
        .trim();

    final builtNorm = norm(built);
    final correctNorm = correct.map(norm);
    final altsNorm = alts.map(norm);

    final isOk = correctNorm.contains(builtNorm) ||
        altsNorm.contains(builtNorm);

    setState(() {
      if (isOk) {
        _feedback = l10n.correctAnswer;
      } else {
        _feedback = 'Неправильно. Правильний переклад: "$correct"'; // TODO
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final promptSentence = widget.isReverseTranslation
        ? widget.sentence.foreign.defaultOptions.first.sentence
        : widget.sentence.native.defaultOptions.first.sentence;

    final chipBg = Theme
        .of(context)
        .brightness == Brightness.dark
        ? Colors.grey[800]
        : Colors.grey[200];

    final l10n = AppLocalizations.of(context)!; // локалізовані строки

    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // 1) Заголовок
          Text(
            l10n.translateSentence,
            style: Theme
                .of(context)
                .textTheme
                .titleMedium,
          ),
          const SizedBox(height: 12),

          // 2) Хмара з промптом (з аудіо, якщо іноземна мова)
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
            decoration: BoxDecoration(
              color: chipBg,
              borderRadius: BorderRadius.circular(16),
            ),
            child: widget.isReverseTranslation
                ? PromptWithTooltips(
              sentence: widget.sentence,
              isReverse: widget.isReverseTranslation,
            ) : AudioPromptWrapper(
              sentence: widget.sentence,
              isForeign: true,
              child: PromptWithTooltips(
                sentence: widget.sentence,
                isReverse: widget.isReverseTranslation,
              ),
            ),
          ),
          const SizedBox(height: 24),

          // 3) Бланк із суцільними лініями
          SizedBox(
            height: 100,
            child: Stack(
              children: [
                Positioned.fill(child: _GridLines()),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                  child: Wrap(
                    key: _answerKey,
                    spacing: 8,
                    runSpacing: 12,
                    alignment: WrapAlignment.start,
                    children: _selectedWords.map((w) {
                      _selectedChipKeys[w] = GlobalKey();
                      return GestureDetector(
                        key: _selectedChipKeys[w],
                        onTap: () => _onTapWord(_selectedChipKeys[w]!, w),
                        child: _buildChip(w, chipBg, true),
                      );
                    }).toList(),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),

          // 4) Банк словоблоків
          Expanded(
            child: SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                child: Wrap(
                  key: _bankKey,
                  spacing: 8,
                  runSpacing: 12,
                  children: _bankWords.map((w) {
                    _bankChipKeys[w] = GlobalKey();
                    return GestureDetector(
                      key: _bankChipKeys[w],
                      onTap: () => _onTapWord(_bankChipKeys[w]!, w),
                      child: _buildChip(w, chipBg, false),
                    );
                  }).toList(),
                ),
              ),
            ),
          ),

          // 5) Зона зворотного зв’язку
          if (_feedback != null) ...[
            Text(
              _feedback!,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: _feedback == l10n.correctAnswer
                    ? Colors.greenAccent
                    : Colors.redAccent,
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 12),
          ],

          // 6) Кнопка
          if (_feedback == null)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
              child: ElevatedButton(
                onPressed: _selectedWords.isEmpty
                    ? null
                    : () {
                  _checkAnswer();
                  widget.onTaskCompleted();
                },
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 14),
                ),
                child: Text(l10n.check),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildChip(String word, Color? bg, bool isSelected) {
    final isFlying = _flyingWord == word;

    return AnimatedOpacity(
      duration: const Duration(milliseconds: 200),
      opacity: isFlying ? 0 : 1,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: isSelected
              ? Theme.of(context).colorScheme.primary.withOpacity(0.7)
              : bg,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Text(
          word,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 14,
          ),
        ),
      ),
    );
  }
}

/// Малює суцільні горизонтальні лінії під блоком відповіді
class _GridLines extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return CustomPaint(painter: _GridPainter());
  }
}

class _GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.grey.shade600
      ..strokeWidth = 1;
    const lineSpacing = 28.0;

    for (double y = size.height - 8; y > 0; y -= lineSpacing) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

/// Відповідальний за анімацію “польоту” чіпика
class _FlyingChip extends StatefulWidget {
  final String word;
  final Offset start;
  final Offset end;
  final Color color;

  const _FlyingChip({
    Key? key,
    required this.word,
    required this.start,
    required this.end,
    required this.color,
  }) : super(key: key);

  @override
  __FlyingChipState createState() => __FlyingChipState();
}

class __FlyingChipState extends State<_FlyingChip>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final Animation<Offset> _anim;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 400));
    _anim = Tween<Offset>(
      begin: widget.start,
      end: widget.end,
    ).animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut));

    _ctrl.forward().then((_) => _ctrl.dispose());
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _ctrl,
      builder: (_, __) {
        return Positioned(
          left: _anim.value.dx,
          top: _anim.value.dy,
          child: Material(
            color: Colors.transparent,
            child: Container(
              padding:
              const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              decoration: BoxDecoration(
                color: widget.color,
                borderRadius: BorderRadius.circular(20),
              ),
              child:
              Text(widget.word, style: const TextStyle(color: Colors.white)),
            ),
          ),
        );
      },
    );
  }
}
