import 'package:flutter/material.dart';

import '../l10n/app_localizations.dart';

class SelectCardsTask extends StatefulWidget {
  final List<String> options;
  final List<String> correctAnswers;
  final VoidCallback onTaskCompleted;

  const SelectCardsTask({
    Key? key,
    required this.options,
    required this.correctAnswers,
    required this.onTaskCompleted,
  }) : super(key: key);

  @override
  State<SelectCardsTask> createState() => _SelectCardsTaskState();
}

class _SelectCardsTaskState extends State<SelectCardsTask> {
  Set<String> selected = {};
  Set<String> incorrectSelections = {};
  Set<String> missedCorrect = {};
  bool validated = false;

  void _validate() {
    final incorrect = selected.difference(widget.correctAnswers.toSet());
    final missed = widget.correctAnswers.toSet().difference(selected);

    setState(() {
      validated = true;
      incorrectSelections = incorrect;
      missedCorrect = missed;
    });

    // після валідації одразу дозволяємо кнопку «Далі»
    widget.onTaskCompleted();
  }

  bool get isAllCorrect =>
      incorrectSelections.isEmpty && missedCorrect.isEmpty;

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!; // локалізовані строки

    final colorScheme = Theme.of(context).colorScheme;
    return Column(
      children: [
        const SizedBox(height: 20),
        Text(
          "(TEST!) Вибери всі ієрогліфи, що містять у собі графему «вогонь»:", // TODO
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
            color: colorScheme.onSurface,
          ),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 20),
        Center(
          child: Wrap(
            alignment: WrapAlignment.center,
            spacing: 12,
            runSpacing: 12,
            children: widget.options.map((char) {
              bool isCorrectMissed = validated && missedCorrect.contains(char);
              bool isIncorrectSelected = validated && incorrectSelections.contains(char);
              bool isSelected = selected.contains(char);

              Color color;
              if (isCorrectMissed || isIncorrectSelected) {
                color = colorScheme.error;
              } else if (isSelected) {
                color = colorScheme.primary;
              } else {
                color = colorScheme.surfaceContainerHigh;
              }

              return GestureDetector(
                onTap: validated
                    ? null
                    : () {
                  setState(() {
                    if (selected.contains(char)) {
                      selected.remove(char);
                    } else {
                      selected.add(char);
                    }
                  });
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                  decoration: BoxDecoration(
                    color: color,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: colorScheme.outline),
                  ),
                  child: Text(
                    char,
                    style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                      color: colorScheme.onSurface,
                      fontSize: 24,
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
        ),
        const SizedBox(height: 20),
        if (!validated)
          ElevatedButton(
            onPressed: _validate,
            style: ElevatedButton.styleFrom(
              backgroundColor: colorScheme.primary,
              foregroundColor: colorScheme.onPrimary,
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            ),
            child: Text(l10n.check),
          ),
        if (validated)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
            child: Text(
              isAllCorrect
                  ? l10n.correctAnswer
                  : "Неправильно. Правильні відповіді: ${widget.correctAnswers.join(', ')}", // TODO
              style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                color: isAllCorrect ? colorScheme.primary : colorScheme.error,
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.center,
            ),
          ),
      ],
    );
  }
}