import 'package:flutter/material.dart';
import 'package:flutter/animation.dart';

class MatchingCard extends StatefulWidget {
  final String text;
  final VoidCallback onTap;
  final bool isSelected;
  final bool isError;
  final bool isMatched;

  const MatchingCard({
    Key? key,
    required this.text,
    required this.onTap,
    required this.isSelected,
    required this.isError,
    required this.isMatched,
  }) : super(key: key);

  @override
  _MatchingCardState createState() => _MatchingCardState();
}

class _MatchingCardState extends State<MatchingCard> with TickerProviderStateMixin {
  late AnimationController _errorController;
  late Animation<double> _rotationAnimation;
  late Animation<Color?> _errorColorAnimation;

  late AnimationController _matchController;
  late Animation<Color?> _matchedColorAnimation;
  late Animation<double> _matchedOpacityAnimation;

  bool wasMatched = false;

  @override
  void initState() {
    super.initState();

    // Контролер для помилки (вібрація та червоний)
    _errorController = AnimationController(
      duration: const Duration(milliseconds: 600),
      vsync: this,
    );

    _rotationAnimation = TweenSequence<double>([
      TweenSequenceItem(tween: Tween(begin: 0, end: 0.1), weight: 1),
      TweenSequenceItem(tween: Tween(begin: 0.1, end: -0.1), weight: 1),
      TweenSequenceItem(tween: Tween(begin: -0.1, end: 0.05), weight: 1),
      TweenSequenceItem(tween: Tween(begin: 0.05, end: -0.05), weight: 1),
      TweenSequenceItem(tween: Tween(begin: -0.05, end: 0), weight: 1),
    ]).animate(CurvedAnimation(parent: _errorController, curve: Curves.easeOut));

    _errorColorAnimation = ColorTween(
      begin: Colors.red.withOpacity(0.5),
      end: Colors.grey[900],
    ).animate(CurvedAnimation(parent: _errorController, curve: Curves.easeInOut));

    // Контролер для matched-анімації
    _matchController = AnimationController(
      duration: const Duration(milliseconds: 400),
      vsync: this,
    );

    _matchedColorAnimation = ColorTween(
      begin: Colors.green.withOpacity(0.6),
      end: Colors.grey[400],
    ).animate(CurvedAnimation(parent: _matchController, curve: Curves.easeInOut));

    _matchedOpacityAnimation = Tween<double>(
      begin: 1.0,
      end: 0.6,
    ).animate(CurvedAnimation(parent: _matchController, curve: Curves.easeInOut));

    _errorController.addListener(() {
      setState(() {});
    });

    _matchController.addListener(() {
      setState(() {});
    });
  }

  @override
  void didUpdateWidget(MatchingCard oldWidget) {
    super.didUpdateWidget(oldWidget);

    if (widget.isError && !oldWidget.isError) {
      _errorController.forward(from: 0);
    }

    if (widget.isMatched && !wasMatched) {
      wasMatched = true;
      _matchController.forward();
    }
  }

  @override
  void dispose() {
    _errorController.dispose();
    _matchController.dispose();
    super.dispose();
  }

  Color _getCardColor() {
    if (widget.isError) {
      return _errorColorAnimation.value ?? Colors.redAccent;
    } else if (widget.isMatched) {
      return _matchedColorAnimation.value ?? Colors.grey[400]!;
    } else if (widget.isSelected) {
      return Colors.green.withOpacity(0.6);
    } else {
      return Colors.grey[900]!;
    }
  }

  TextStyle _getTextStyle() {
    if (widget.isMatched) {
      return const TextStyle(fontSize: 22, color: Colors.black54);
    } else {
      return const TextStyle(fontSize: 24, color: Colors.white, fontWeight: FontWeight.bold);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Transform.rotate(
      angle: _rotationAnimation.value,
      child: Opacity(
        opacity: widget.isMatched ? _matchedOpacityAnimation.value : 1.0,
        child: GestureDetector(
          onTap: widget.onTap,
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 8),
            decoration: BoxDecoration(
              color: _getCardColor(),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.white, width: 2),
            ),
            child: Center(
              child: Text(widget.text, style: _getTextStyle()),
            ),
          ),
        ),
      ),
    );
  }
}