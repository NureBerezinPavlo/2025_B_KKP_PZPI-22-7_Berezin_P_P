import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:nellingua/models/user_progress_model.dart';
import '../l10n/app_localizations.dart';

class LessonSelectionDialog extends StatelessWidget {
  final List<Map<String, dynamic>> lessons;
  final int currentLessonIndex;
  final int levelIndex;
  final int unitIndex;
  final String courseId;
  final Function(int) onLessonSelected;

  const LessonSelectionDialog({
    super.key,
    required this.lessons,
    required this.currentLessonIndex,
    required this.levelIndex,
    required this.unitIndex,
    required this.courseId,
    required this.onLessonSelected,
  });

  @override
  Widget build(BuildContext context) {
    final progress = Provider.of<UserProgressModel>(context, listen: false);
    final userUnit = progress.getCurrentUnitIndex(courseId);
    final userLevel = progress.getCurrentLevelIndex(courseId);
    final userLesson = progress.getCurrentLessonIndex(courseId);

    final l10n = AppLocalizations.of(context)!; // локалізовані строки

    print("lesson_selection_dialog.dart: courseId = $courseId");

    print('\Unit: ${userUnit}, level: ${userLevel}, lesson: ${userLesson}');

    return Dialog(
      insetPadding: const EdgeInsets.all(20),
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 400),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(l10n.selectLesson, style: TextStyle(fontSize: 20)),
              const SizedBox(height: 16),
              ...lessons.asMap().entries.map((entry) {
                final idx = entry.key;
                final lesson = entry.value;
                // блокуємо, якщо юніт, або рівень, або урок вище за поточний
                final bool isLocked =
                    unitIndex > userUnit ||
                        (unitIndex == userUnit && levelIndex > userLevel) ||
                        (unitIndex == userUnit && levelIndex == userLevel && idx > userLesson);

                return Card(
                  color: isLocked ? Colors.grey[200] : null,
                  child: ListTile(
                    title: Text(lesson['title'] ?? 'Урок ${idx+1}',
                        style: TextStyle(color: isLocked ? Colors.grey : null)),
                    trailing: isLocked
                        ? const Icon(Icons.lock, color: Colors.grey)
                        : const Icon(Icons.arrow_forward),
                    onTap: isLocked
                        ? null
                        : () {
                      Navigator.of(context).pop();
                      onLessonSelected(idx);
                    },
                  ),
                );
              }).toList(),
              const SizedBox(height: 16),
              TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: Text(l10n.cancel),
              ),
            ],
          ),
        ),
      ),
    );
  }

  String _getLessonType(String? type) {
    switch (type) {
      case 'practice': return 'Практика';
      case 'revision': return 'Повторення';
      case 'final': return 'Підсумковий';
      default: return 'Теорія';
    }
  }
}