import 'package:flutter/material.dart';
import '../models/sentence_model.dart';
import 'prompt_with_tooltips.dart';
import '../l10n/app_localizations.dart';

class KeyboardInputTask extends StatefulWidget {
  final Sentence sentence;
  final VoidCallback onTaskCompleted;

  const KeyboardInputTask({
    Key? key,
    required this.sentence,
    required this.onTaskCompleted,
  }) : super(key: key);

  @override
  _KeyboardInputTaskState createState() => _KeyboardInputTaskState();
}

class _KeyboardInputTaskState extends State<KeyboardInputTask> {
  final TextEditingController _controller = TextEditingController();
  String? _feedback;
  bool _isCompleted = false;

  void _checkAnswer() {
    final userInput = _controller.text;
    final correctAnswers = [
      ...widget.sentence.foreign.defaultOptions.map((o) => o.sentence),
      ...widget.sentence.foreign.alternativeOptions
    ];

    final l10n = AppLocalizations.of(context)!; // локалізовані строки

    final normalizedInput = _normalize(userInput);
    final isCorrect = correctAnswers.any((correct) =>
    _normalize(correct) == normalizedInput);

    setState(() {
      _feedback = isCorrect
          ? l10n.correctAnswer
          : 'Неправильно. Правильна відповідь: "${correctAnswers.first}"'; // TODO

      _isCompleted = true;
      widget.onTaskCompleted();
    });
  }

  String _normalize(String text) => text
      .replaceAll(RegExp(r'''[!"#\$%&'()*+,\-–—./:;<=>?@[\\\]^_`{|}~«»…。，、”：„“”\s]'''), '')
      .toLowerCase();

  @override
  Widget build(BuildContext context) {
    final prompt = widget.sentence.native.defaultOptions.first.sentence;
    final chipBg = Theme.of(context).brightness == Brightness.dark
        ? Colors.grey[800]
        : Colors.grey[200];

    final l10n = AppLocalizations.of(context)!; // локалізовані строки

    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            l10n.translateSentence,
            style: Theme.of(context).textTheme.titleMedium,
          ),
          const SizedBox(height: 12),

          Container(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
            decoration: BoxDecoration(
              color: chipBg,
              borderRadius: BorderRadius.circular(16),
            ),
            child: PromptWithTooltips(
              sentence: widget.sentence,
              isReverse: true,
            ),
          ),
          const SizedBox(height: 30),

          TextField(
            controller: _controller,
            minLines: 4,
            maxLines: null,
            decoration: InputDecoration(
              hintText: l10n.enterTranslationPlaceholder,
              border: const OutlineInputBorder(),
            ),
          ),

          if (_feedback != null) ...[
            const SizedBox(height: 20),
            Text(
              _feedback!,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: _feedback == l10n.correctAnswer
                    ? Colors.greenAccent
                    : Colors.redAccent,
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],

          if (!_isCompleted) ...[
            const SizedBox(height: 20),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: ElevatedButton(
                onPressed: _checkAnswer,
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 14),
                ),
                child: Text(l10n.check),
              ),
            ),
          ],
        ],
      ),
    );
  }
}