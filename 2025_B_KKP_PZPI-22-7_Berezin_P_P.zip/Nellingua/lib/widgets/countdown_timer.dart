import 'dart:async';
import 'package:flutter/material.dart';
import 'package:nellingua/l10n/app_localizations.dart';

class CountdownTimer extends StatefulWidget {
  const CountdownTimer({super.key});

  @override
  _CountdownTimerState createState() => _CountdownTimerState();
}

class _CountdownTimerState extends State<CountdownTimer> {
  late Timer _timer;
  Duration _timeUntilMidnight = Duration.zero;

  @override
  void initState() {
    super.initState();
    _updateTimeUntilMidnight();
    // Запускаємо таймер для оновлення кожну секунду
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      _updateTimeUntilMidnight();
    });
  }

  void _updateTimeUntilMidnight() {
    final now = DateTime.now();
    // Визначаємо наступну північ
    final nextMidnight = DateTime(now.year, now.month, now.day + 1);
    // Розраховуємо залишок часу
    setState(() {
      _timeUntilMidnight = nextMidnight.difference(now);
    });
  }

  @override
  void dispose() {
    _timer.cancel(); // Очищаємо таймер при видаленні віджета
    super.dispose();
  }

  String _formatDuration(Duration duration) {
    final hours = duration.inHours.toString().padLeft(2, '0');
    final minutes = (duration.inMinutes % 60).toString().padLeft(2, '0');
    final seconds = (duration.inSeconds % 60).toString().padLeft(2, '0');
    return '$hours:$minutes:$seconds';
  }

  @override
  Widget build(BuildContext context) {
    final localizations = AppLocalizations.of(context)!;
    return Text(
      '${localizations.remainingTime}: ${_formatDuration(_timeUntilMidnight)}',
      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
        fontWeight: FontWeight.bold,
        color: Theme.of(context).colorScheme.primary,
      ),
    );
  }
}