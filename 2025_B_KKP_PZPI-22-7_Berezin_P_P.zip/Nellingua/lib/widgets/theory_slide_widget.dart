import 'package:flutter/material.dart';
import 'package:flutter_markdown/flutter_markdown.dart';
import 'package:audioplayers/audioplayers.dart';
import 'select_cards_task.dart'; // додай імпорт

import '../models/theory_slide.dart';

class TheorySlideWidget extends StatelessWidget {
  final TheorySlide slide;

  const TheorySlideWidget({super.key, required this.slide});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16.0),
      children: slide.content.map((content) {
        switch (content.type) {
          case 'heading':
            return Padding(
              padding: const EdgeInsets.only(bottom: 16.0),
              child: Text(
                content.value,
                style: Theme.of(context).textTheme.headlineSmall,
              ),
            );
          case 'text':
            return MarkdownBody(data: content.value);
          case 'table':
            return _buildTable(content.value);
          case 'image':
            return _buildImage(content.value);
          case 'audio':
            return _buildAudio(content.value);
          default:
            return const SizedBox.shrink();
        }
      }).toList(),
    );
  }

  Widget _buildTable(List<dynamic> rows) {
    return Table(
      border: TableBorder.all(),
      children: rows.map((row) {
        // Перевіряємо, чи рядок є списком
        if (row is! List) return TableRow(children: [Container()]);

        return TableRow(
          children: row.map<Widget>((cell) {
            return Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(cell.toString(), textAlign: TextAlign.center),
            );
          }).toList(),
        );
      }).toList(),
    );
  }

  Widget _buildImage(Map<String, dynamic> imageData) {
    return Column(
      children: [
        Image.asset(imageData["src"]),
        if (imageData.containsKey("caption"))
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Text(imageData["caption"], style: const TextStyle(fontStyle: FontStyle.italic)),
          ),
      ],
    );
  }

  Widget _buildAudio(String audioFile) {
    final player = AudioPlayer();
    return IconButton(
      icon: const Icon(Icons.play_arrow),
      onPressed: () {
        player.play(AssetSource('audio/$audioFile'));
      },
    );
  }
}