// lib/widgets/audio_prompt_wrapper.dart
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import '../models/sentence_model.dart';

class AudioPromptWrapper extends StatefulWidget {
  final Sentence sentence;
  final bool isForeign;
  final Widget child;

  const AudioPromptWrapper({
    super.key,
    required this.sentence,
    required this.isForeign,
    required this.child,
  });

  @override
  State<AudioPromptWrapper> createState() => _AudioPromptWrapperState();
}

class _AudioPromptWrapperState extends State<AudioPromptWrapper> {
  final AudioPlayer _player = AudioPlayer();
  String _selectedSpeed = 'normal';
  final List<String> _speedKeys = [
    'super_slowly',
    'much_more_slowly',
    'more_slowly',
    'a_little_bit_more_slowly',
    'normal'
  ];
  final Map<String, String> _speedLabels = {
    'super_slowly': '0.35×',
    'much_more_slowly': '0.5×',
    'more_slowly': '0.75×',
    'a_little_bit_more_slowly': '0.85×',
    'normal': '1×'
  };

  Map<String, String>? _audioSources;

  @override
  void initState() {
    super.initState();
    _pickAudio();
  }

  void _pickAudio() {
    if (!widget.isForeign) return;
    final options = widget.sentence.foreign.defaultOptions;
    if (options.isEmpty) return;
    final audios = options[0].nativeSpeakersAudio;
    if (audios.isEmpty) return;
    final picked = audios[Random().nextInt(audios.length)];
    setState(() {
      _audioSources = {
        'normal': picked.normal,
        'a_little_bit_more_slowly': picked.aLittleBitMoreSlowly,
        'more_slowly': picked.moreSlowly,
        'much_more_slowly': picked.muchMoreSlowly,
        'super_slowly': picked.superSlowly,
      };
    });
  }

  Future<void> _play() async {
    final url = _audioSources?[_selectedSpeed];
    if (url == null) return;
    try {
      await _player.setUrl(url);
      await _player.play();
    } catch (_) {
      // handle error or fallback here
    }
  }

  @override
  void dispose() {
    _player.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!widget.isForeign || _audioSources == null) return widget.child;

    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Column(
          children: [
            IconButton(
              onPressed: _play,
              icon: const Icon(Icons.volume_up_rounded),
              tooltip: 'Play audio',
            ),
            DropdownButton<String>(
              value: _selectedSpeed,
              onChanged: (newVal) {
                if (newVal != null) {
                  setState(() => _selectedSpeed = newVal);
                }
              },
              iconSize: 16,
              isDense: true,
              items: _speedKeys.map((s) {
                return DropdownMenuItem(
                  value: s,
                  child: Text(_speedLabels[s]!),
                );
              }).toList(),
            ),
          ],
        ),
        const SizedBox(width: 12),
        Expanded(child: widget.child),
      ],
    );
  }
}