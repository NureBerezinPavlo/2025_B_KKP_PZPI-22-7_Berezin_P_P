import 'package:flutter/material.dart';
import '../models/sentence_model.dart';
import 'package:just_audio/just_audio.dart';
import 'dart:math';
import '../l10n/app_localizations.dart';


class KeyboardInputListeningTask extends StatefulWidget {
  final Sentence sentence;
  final VoidCallback onTaskCompleted;

  const KeyboardInputListeningTask({
    Key? key,
    required this.sentence,
    required this.onTaskCompleted,
  }) : super(key: key);

  @override
  _KeyboardInputListeningTaskState createState() => _KeyboardInputListeningTaskState();
}

class _KeyboardInputListeningTaskState extends State<KeyboardInputListeningTask> {
  final AudioPlayer _player = AudioPlayer();
  String _selectedSpeed = 'normal';
  Map<String, String>? _audioSources;

  final List<String> _speedKeys = [
    'super_slowly',
    'much_more_slowly',
    'more_slowly',
    'a_little_bit_more_slowly',
    'normal'
  ];
  final Map<String, String> _speedLabels = {
    'super_slowly': '0.35×',
    'much_more_slowly': '0.5×',
    'more_slowly': '0.75×',
    'a_little_bit_more_slowly': '0.85×',
    'normal': '1×'
  };
  final TextEditingController _controller = TextEditingController();
  String? _feedback;
  bool _isCompleted = false;

  void _checkAnswer() {
    final userInput = _controller.text;
    final correctAnswers = [
      ...widget.sentence.foreign.defaultOptions.map((o) => o.sentence),
      ...widget.sentence.foreign.alternativeOptions
    ];

    final l10n = AppLocalizations.of(context)!; // локалізовані строки

    final normalizedInput = _normalize(userInput);
    final isCorrect = correctAnswers.any((correct) =>
    _normalize(correct) == normalizedInput);

    setState(() {
      _feedback = isCorrect
          ? l10n.correctAnswer
          : 'Неправильно. Правильна відповідь: "${correctAnswers.first}"'; // TODO

      _isCompleted = true;
      widget.onTaskCompleted();
    });
  }

  @override
  void initState() {
      super.initState();
      _pickAudio();
    }

void _pickAudio() {
  final options = widget.sentence.foreign.defaultOptions;
  if (options.isEmpty) return;
  final audios = options[0].nativeSpeakersAudio;
  if (audios.isEmpty) return;
  final picked = audios[Random().nextInt(audios.length)];
  setState(() {
    _audioSources = {
      'normal': picked.normal,
      'a_little_bit_more_slowly': picked.aLittleBitMoreSlowly,
      'more_slowly': picked.moreSlowly,
      'much_more_slowly': picked.muchMoreSlowly,
      'super_slowly': picked.superSlowly,
    };
  });
}

Future<void> _play() async {
  final url = _audioSources?[_selectedSpeed];
  if (url == null) return;
  try {
    await _player.setUrl(url);
    await _player.play();
  } catch (_) {}
}

@override
void dispose() {
  _player.dispose();
  super.dispose();
}

  String _normalize(String text) => text
      .replaceAll(RegExp(r'''[!"#\$%&'()*+,\-–—./:;<=>?@[\\\]^_`{|}~«»…。，、”：„“”\s]'''), '')
      .toLowerCase();

  @override
  Widget build(BuildContext context) {
    final prompt = widget.sentence.native.defaultOptions.first.sentence;
    final chipBg = Theme.of(context).brightness == Brightness.dark
        ? Colors.grey[800]
        : Colors.grey[200];

    final l10n = AppLocalizations.of(context)!; // локалізовані строки

    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            'Прослухайте речення і напишіть його.', // TODO
            style: Theme.of(context).textTheme.titleMedium,
          ),
          const SizedBox(height: 30),

          // 2. Аудіо
          Row(
            children: [
              IconButton(
                onPressed: _play,
                icon: const Icon(Icons.volume_up_rounded, size: 32),
              ),
              const SizedBox(width: 12),
              DropdownButton<String>(
                value: _selectedSpeed,
                onChanged: (val) {
                  if (val != null) setState(() => _selectedSpeed = val);
                },
                items: _speedKeys
                    .map((key) =>
                    DropdownMenuItem(
                      value: key,
                      child: Text(_speedLabels[key]!),
                    ))
                    .toList(),
              )
            ],
          ),
          const SizedBox(height: 24),

          TextField(
            controller: _controller,
            minLines: 4,
            maxLines: null,
            decoration: InputDecoration(
              hintText: 'Введіть прослухане тут...', // TODO
              border: const OutlineInputBorder(),
            ),
          ),

          if (_feedback != null) ...[
            const SizedBox(height: 20),
            Text(
              _feedback!,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: _feedback == l10n.correctAnswer
                    ? Colors.greenAccent
                    : Colors.redAccent,
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],

          if (!_isCompleted) ...[
            const SizedBox(height: 20),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: ElevatedButton(
                onPressed: _checkAnswer,
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 14),
                ),
                child: Text(l10n.check),
              ),
            ),
          ],
        ],
      ),
    );
  }
}