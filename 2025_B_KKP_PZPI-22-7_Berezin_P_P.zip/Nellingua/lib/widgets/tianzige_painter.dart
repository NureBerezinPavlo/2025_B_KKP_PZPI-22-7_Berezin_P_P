/*import 'package:flutter/material.dart';

class TianzigePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.black12
      ..strokeWidth = 1;

    final double third = size.width / 3;

    // Рамка
    canvas.drawRect(Offset.zero & size, paint);

    // Вертикальні та горизонтальні лінії
    canvas.drawLine(Offset(third, 0), Offset(third, size.height), paint);
    canvas.drawLine(Offset(2 * third, 0), Offset(2 * third, size.height), paint);
    canvas.drawLine(Offset(0, third), Offset(size.width, third), paint);
    canvas.drawLine(Offset(0, 2 * third), Offset(size.width, 2 * third), paint);

    // Діагоналі
    canvas.drawLine(Offset(0, 0), Offset(size.width, size.height), paint);
    canvas.drawLine(Offset(size.width, 0), Offset(0, size.height), paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}*/

import 'package:flutter/material.dart';

class TianzigePainter extends CustomPainter {
  final List<Rect> componentRects;

  TianzigePainter({required this.componentRects});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.black38
      ..strokeWidth = 1
      ..style = PaintingStyle.stroke;

    // Основні лінії тяньцзиґе
    canvas.drawLine(Offset(0, 0), Offset(size.width, size.height), paint);
    canvas.drawLine(Offset(size.width, 0), Offset(0, size.height), paint);
    canvas.drawLine(Offset(size.width / 2, 0), Offset(size.width / 2, size.height), paint);
    canvas.drawLine(Offset(0, size.height / 2), Offset(size.width, size.height / 2), paint);
    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height), paint);

    final targetPaint = Paint()
      ..color = Colors.green.withOpacity(0.25)
      ..style = PaintingStyle.fill;

    for (final rect in componentRects) {
      final scaled = Rect.fromLTWH(
        rect.left * size.width,
        rect.top * size.height,
        rect.width * size.width,
        rect.height * size.height,
      );
      canvas.drawRect(scaled, targetPaint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}