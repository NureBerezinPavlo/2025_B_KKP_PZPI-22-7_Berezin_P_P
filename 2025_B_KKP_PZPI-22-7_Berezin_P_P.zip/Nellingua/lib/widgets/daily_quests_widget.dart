import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../l10n/app_localizations.dart';
import '../models/user_progress_model.dart';
import '../models/daily_quest.dart';
import 'countdown_timer.dart';

class DailyQuestsWidget extends StatelessWidget {
  const DailyQuestsWidget({super.key});

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;

    final userProgress = Provider.of<UserProgressModel>(context);

    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  l10n.dailyQuests,
                  style: Theme.of(context).textTheme.headlineSmall,
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16.0),
                  child: CountdownTimer(),
                ),
              ],
            ),
            const SizedBox(height: 16),
            ...userProgress.dailyQuests.map((quest) => _buildQuest(context, quest)),
          ],
        ),
      ),
    );
  }

  Widget _buildQuest(BuildContext context, DailyQuest quest) {
    final progress = quest.progress.clamp(0, quest.target);
    final isCompleted = quest.isCompleted;

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        children: [
          Icon(
            isCompleted ? Icons.check_circle : Icons.circle_outlined,
            color: isCompleted ? Colors.green : Colors.grey,
            size: 24,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  quest.description(context),
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    fontWeight:
                    isCompleted ? FontWeight.bold : FontWeight.normal,
                  ),
                ),
                const SizedBox(height: 4),
                LinearProgressIndicator(
                  value: progress / quest.target,
                  backgroundColor: Colors.grey[200],
                  color: Theme.of(context).colorScheme.primary,
                  minHeight: 6,
                ),
                const SizedBox(height: 4),
                Text(
                  '$progress / ${quest.target}',
                  style: Theme.of(context).textTheme.bodySmall,
                ),
              ],
            ),
          ),
          const SizedBox(width: 12),
          Row(
            children: [
              const Icon(Icons.diamond, color: Colors.yellow, size: 16),
              const SizedBox(width: 4),
              Text(
                '${quest.reward}',
                style: Theme.of(context).textTheme.bodyMedium,
              ),
            ],
          ),
        ],
      ),
    );
  }
}