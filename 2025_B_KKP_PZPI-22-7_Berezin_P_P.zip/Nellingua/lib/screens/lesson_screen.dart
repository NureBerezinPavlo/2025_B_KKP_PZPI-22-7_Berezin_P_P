import 'dart:math';
import 'package:flutter/material.dart';
import 'package:nellingua/widgets/keyboard_input_listening_task.dart';
import '../models/daily_quest.dart';
import '../models/lesson.dart';
import '../models/sentence_model.dart';
import '../services/sentence_repository.dart';
import '../services/spaced_repetition_data.dart';
import '../widgets/theory_slide_widget.dart';
import 'matching_game_screen.dart';
import '../widgets/select_cards_task.dart';
import '../widgets/assemble_character_slide.dart';
import '../widgets/stroke_practice_slide.dart';
import '../widgets/translation_block_task.dart';
import '../widgets/keyboard_input_task.dart';
import '../widgets/listening_word_chips_task.dart';
import '../widgets/speaking_with_reading_task.dart';
import 'package:provider/provider.dart';
import 'package:nellingua/services/lesson_loader.dart';
import 'package:nellingua/models/user_progress_model.dart';
import 'package:nellingua/models/course_model.dart';
import '../l10n/app_localizations.dart';
import '../xp_provider.dart';

class LessonScreen extends StatefulWidget {
  final Lesson lesson;
  final String courseId;
  final int unitIndex;
  final int levelIndex;
  final int lessonIndex;

  const LessonScreen({
    Key? key,
    required this.lesson,
    required this.courseId,
    required this.unitIndex,
    required this.levelIndex,
    required this.lessonIndex,
  }) : super(key: key);

  @override
  _LessonScreenState createState() => _LessonScreenState();
}

class _LessonScreenState extends State<LessonScreen> {
  int currentSlideIndex = 0;
  bool taskCompleted = false;
  DateTime? _startTime;
  Map<String, Sentence> _sentencesMap = {};
  bool _sentencesLoaded = false;

  @override
  void initState() {
    super.initState();
    _startTime = DateTime.now();

    // Перевіряємо, чи потрібні речення для цього уроку
    if (_lessonRequiresSentences(widget.lesson)) {
      _loadSentences();
    } else {
      _sentencesLoaded = true; // Позначаємо, що завантаження не потрібне
    }
  }

  // Перевіряємо, чи є в уроці слайди, які вимагають речень
  bool _lessonRequiresSentences(Lesson lesson) {
    return lesson.slides.any((slide) {
      return [
        "reading_and_wordchips",
        "reading_and_keyboard_input",
        "listening_and_wordchips",
        "listening_and_keyboard_input",
        "reading_and_speaking",
      ].contains(slide.type);
    });
  }

  Future<void> _loadSentences() async {
    final repo = SentenceRepository();
    final allSentences = await repo.fetchSentencesForCourse(widget.courseId);

    setState(() {
      _sentencesMap = {for (var s in allSentences) s.sentenceId: s};
      _sentencesLoaded = true; // Позначаємо завершення завантаження
    });
  }

  void _goToNextSlide() {
    if (currentSlideIndex < widget.lesson.slides.length - 1) {
      setState(() {
        currentSlideIndex++;
        taskCompleted = false;
      });
    } else {
      _showCompletionDialog();
    }
  }

  void _showCompletionDialog() {
    final timeSpent = DateTime.now().difference(_startTime!);
    final l10n = AppLocalizations.of(context)!;
    final xpProvider = Provider.of<XpProvider>(context, listen: false);
    final userProgress = Provider.of<UserProgressModel>(context, listen: false);
    final course = Provider.of<CourseModel>(context, listen: false);

    // Отримуємо тип уроку та статус повтору
    String lessonType = 'theory_lesson';
    bool isNewLesson = widget.unitIndex == userProgress.getCurrentUnitIndex(course.id) &&
        widget.levelIndex == userProgress.getCurrentLevelIndex(course.id) &&
        widget.lessonIndex == userProgress.getCurrentLessonIndex(course.id);
    String? levelType;
    if (isNewLesson) {
      final units = List<Map<String, dynamic>>.from(course.data['units'] ?? []);
      if (units.isNotEmpty && widget.unitIndex < units.length) {
        final levels = List<Map<String, dynamic>>.from(units[widget.unitIndex]['levels'] ?? []);
        if (levels.isNotEmpty && widget.levelIndex < levels.length) {
          levelType = levels[widget.levelIndex]['type']?.toString().toLowerCase();
          lessonType = levelType == 'practice' ? 'practice_lesson' : 'theory_lesson';
        }
      }
    }

    // Обчислюємо нараховані XP
    int baseXp = lessonType == 'practice_lesson' ? 10 : 5;
    bool isRepeat = false;
    if (isNewLesson) {
      // Викликаємо moveToNextLesson для отримання isRepeat
      userProgress.moveToNextLesson(course.id, course.data).then((repeat) {
        isRepeat = repeat;
        int awardedXp = (isRepeat ? 1 : baseXp * xpProvider.xpMultiplier).round();
        showDialog(
          context: context,
          builder: (context) => AlertDialog(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            title: Text(
              l10n.lessonCompleted,
              style: Theme.of(context).textTheme.headlineSmall,
            ),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  l10n.timeSpent(_formatDuration(timeSpent)),
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
                const SizedBox(height: 8),
                Text(
                  l10n.xpEarned(awardedXp),
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
                Text(
                  l10n.totalXp(xpProvider.xp),
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
                if (xpProvider.hasActiveMultiplier)
                  Text(
                    l10n.xpMultiplierActive(xpProvider.xpMultiplier),
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Colors.green),
                  ),
                const SizedBox(height: 20),
                ElevatedButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                    _completeAndReturnToMap();
                  },
                  child: Text(l10n.continueButton),
                  style: ElevatedButton.styleFrom(
                    minimumSize: const Size(double.infinity, 56),
                  ),
                ),
              ],
            ),
          ),
        );
      });
    } else {
      isRepeat = true;
      int awardedXp = (isRepeat ? 1 : baseXp * xpProvider.xpMultiplier).round();
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          title: Text(
            l10n.lessonCompleted,
            style: Theme.of(context).textTheme.headlineSmall,
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                l10n.timeSpent(_formatDuration(timeSpent)),
                style: Theme.of(context).textTheme.bodyMedium,
              ),
              const SizedBox(height: 8),
              Text(
                l10n.xpEarned(awardedXp),
                style: Theme.of(context).textTheme.bodyMedium,
              ),
              Text(
                l10n.totalXp(xpProvider.xp),
                style: Theme.of(context).textTheme.bodyMedium,
              ),
              if (xpProvider.hasActiveMultiplier)
                Text(
                  l10n.xpMultiplierActive(xpProvider.xpMultiplier),
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Colors.green),
                ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  Navigator.of(context).pop();
                  _completeAndReturnToMap();
                },
                child: Text(l10n.continueButton),
                style: ElevatedButton.styleFrom(
                  minimumSize: const Size(double.infinity, 56),
                ),
              ),
            ],
          ),
        ),
      );
    }
  }

  String _formatDuration(Duration duration) {
    String twoDigits(int n) => n.toString().padLeft(2, '0');
    final minutes = twoDigits(duration.inMinutes.remainder(60));
    final seconds = twoDigits(duration.inSeconds.remainder(60));
    return "$minutes:$seconds";
  }

  void _completeAndReturnToMap() async {
    final userProgress = Provider.of<UserProgressModel>(context, listen: false);
    final course = Provider.of<CourseModel>(context, listen: false);
    final xpProvider = Provider.of<XpProvider>(context, listen: false);

    // Отримуємо поточні індекси прогресу
    final currentUnitIndex = userProgress.getCurrentUnitIndex(course.id);
    final currentLevelIndex = userProgress.getCurrentLevelIndex(course.id);
    final currentLessonIndex = userProgress.getCurrentLessonIndex(course.id);

    // Перевіряємо, чи є урок "новим"
    final isNewLesson = widget.unitIndex == currentUnitIndex &&
        widget.levelIndex == currentLevelIndex &&
        widget.lessonIndex == currentLessonIndex;

    // Зберігаємо нові слова для інтервального повторення
    await _saveLearnedWords();

    // Визначаємо тип рівня (theory або practice)
    String lessonType = 'theory_lesson';
    bool isLevelCompleted = false;
    String? levelType;
    if (isNewLesson) {
      final units = List<Map<String, dynamic>>.from(course.data['units'] ?? []);
      if (units.isNotEmpty && widget.unitIndex < units.length) {
        final levels = List<Map<String, dynamic>>.from(units[widget.unitIndex]['levels'] ?? []);
        if (levels.isNotEmpty && widget.levelIndex < levels.length) {
          final lessons = List<Map<String, dynamic>>.from(levels[widget.levelIndex]['lessons'] ?? []);
          levelType = levels[widget.levelIndex]['type']?.toString().toLowerCase();
          lessonType = levelType == 'practice' ? 'practice_lesson' : 'theory_lesson';
          if (widget.lessonIndex == lessons.length - 1) {
            isLevelCompleted = true;
            print('[DEBUG] Level completed: unitIndex=${widget.unitIndex}, levelIndex=${widget.levelIndex}, type=$levelType');
          }
        }
      }
    }

    // Нараховуємо XP за урок
    final isRepeat = isNewLesson ? await userProgress.moveToNextLesson(course.id, course.data) : true;
    await xpProvider.awardXp(lessonType, isRepeat: isRepeat);
    print('[DEBUG] Awarded XP for lesson: type=$lessonType, isRepeat=$isRepeat');

    // Оновлюємо прогрес квестів
    for (var quest in userProgress.dailyQuests) {
      if (quest.isCompleted) continue;
      bool shouldUpdate = false;
      switch (quest.type) {
        case QuestType.completeLessons:
          shouldUpdate = true; // Завершення уроку
          break;
        case QuestType.completeLevels:
          shouldUpdate = isLevelCompleted; // Завершення рівня
          break;
        case QuestType.completeTheoryLevel:
          shouldUpdate = isLevelCompleted && levelType == 'theory';
          break;
        case QuestType.completePracticeLevel:
          shouldUpdate = isLevelCompleted && levelType == 'practice';
          break;
        case QuestType.completeSpeakingTasks:
        case QuestType.completeListeningTasks:
          break; // Обробляються в _updateQuestProgress
      }
      if (shouldUpdate) {
        await userProgress.updateQuestProgress(quest);
        if (quest.isCompleted) {
          await xpProvider.awardGems(quest.reward);
          print('[DEBUG] Quest completed: ${quest.id}, rewarded ${quest.reward} gems');
        }
      }
    }

    Navigator.of(context).pop();
  }

  Future<void> _saveLearnedWords() async {
    final userProgress = Provider.of<UserProgressModel>(context, listen: false);
    final courseId = widget.courseId;
    final userId = userProgress.userId;
    final spacedRepetition = SpacedRepetitionSystem();

    // Збираємо всі sentence_ids з усіх слайдів
    final sentenceIds = widget.lesson.slides
        .where((slide) => slide.translationBlockData != null)
        .expand((slide) => slide.translationBlockData!['sentence_ids'] as List)
        .toList();

    print('[DEBUG] _saveLearnedWords: sentenceIds = $sentenceIds');

    // Отримуємо речення
    final sentences = _sentencesMap.values
        .where((s) => sentenceIds.contains(s.sentenceId))
        .toList();

    print('[DEBUG] _saveLearnedWords: found ${sentences.length} sentences');

    // Збираємо унікальні wordIDs
    final wordIds = <String>{};
    for (final sentence in sentences) {
      if (sentence.foreign.defaultOptions != null) {
        wordIds.addAll(
          sentence.foreign.defaultOptions
              .expand((option) => option.highlightedWords.map((word) => word.wordID))
              .where((wordId) => wordId.isNotEmpty),
        );
      }
      if (sentence.native.defaultOptions != null) {
        wordIds.addAll(
          sentence.native.defaultOptions
              .expand((option) => option.highlightedWords.map((word) => word.wordID))
              .where((wordId) => wordId.isNotEmpty),
        );
      }
    }

    print('[DEBUG] _saveLearnedWords: wordIds = $wordIds');

    // Зберігаємо слова для інтервального повторення
    for (final wordId in wordIds) {
      try {
        final data = SpacedRepetitionData.initial(wordId, courseId);
        await spacedRepetition.saveRepetitionData(data, userId);
        print('[DEBUG] Saved learned word: wordId=$wordId, userId=$userId, courseId=$courseId');
      } catch (e, stackTrace) {
        print('[ERROR] Failed to save learned word: wordId=$wordId, error=$e');
        print('[ERROR] Stack trace: $stackTrace');
      }
    }

    if (wordIds.isEmpty) {
      print('[DEBUG] _saveLearnedWords: No words to save');
    }
  }

  void _resetStrokePractice() {
    setState(() {
      taskCompleted = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (!_sentencesLoaded) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    final l10n = AppLocalizations.of(context)!;

    if (widget.lesson.slides.isEmpty) {
      return Scaffold(
        appBar: AppBar(
          title: Text(l10n.lessonTitle(widget.lesson.title)),
        ),
        body: Center(
          child: Text(
            "This lesson has no slides",
            style: Theme.of(context).textTheme.bodyMedium,
          ),
        ),
      );
    }

    final slide = widget.lesson.slides[currentSlideIndex];
    Widget slideWidget;

    if (slide.type == "theory") {
      slideWidget = TheorySlideWidget(slide: slide);
    } else if (slide.type == "matching_pairs") {
      slideWidget = MatchingGameScreen(
        pairs: slide.matchingPairs ?? [],
        selectCount: slide.selectCount ?? (slide.matchingPairs?.length ?? 0),
        onTaskCompleted: () {
          setState(() => taskCompleted = true);
          _updateQuestProgress(slide.type);
        },
      );
    } else if (slide.type == "select_cards") {
      slideWidget = SelectCardsTask(
        options: slide.content
            .firstWhere((c) => c.type == 'cards')
            .value['options']
            .cast<String>(),
        correctAnswers: slide.content
            .firstWhere((c) => c.type == 'cards')
            .value['correct']
            .cast<String>(),
        onTaskCompleted: () {
          setState(() => taskCompleted = true);
          _updateQuestProgress(slide.type);
        },
      );
    } else if (slide.type == "assemble_character") {
      slideWidget = AssembleCharacterSlide(
        characters: slide.assembleCharacters ?? [],
        onTaskCompleted: () {
          setState(() {
            taskCompleted = true;
            _updateQuestProgress(slide.type);
          });
        },
      );
    } else if (slide.type == "stroke_practice" && slide.strokeData != null) {
      slideWidget = StrokePracticeSlide(
        key: ValueKey(slide.id),
        character: slide.strokeData!.characters,
        onTaskCompleted: () => setState(() => taskCompleted = true),
        onReset: _resetStrokePractice,
        strokeData: slide.strokeData!,
      );
    } else if (slide.type == "reading_and_wordchips") {
      final isReverse = slide.translationBlockData?['direction'] == "foreign_to_native";
      final sentencesCount = slide.translationBlockData!['sentence_ids'].length;
      final randomId = Random().nextInt(sentencesCount);
      final sentenceId = slide.translationBlockData!['sentence_ids'][randomId];

      slideWidget = TranslationBlockTask(
        key: ValueKey(slide.id),
        sentence: _sentencesMap[sentenceId]!,
        isReverseTranslation: isReverse,
        onTaskCompleted: () {
          setState(() => taskCompleted = true);
          _updateQuestProgress(slide.type);
        },
      );
    } else if (slide.type == "reading_and_keyboard_input") {
      final sentencesCount = slide.translationBlockData!['sentence_ids'].length;
      final randomId = Random().nextInt(sentencesCount);
      final sentenceId = slide.translationBlockData!['sentence_ids'][randomId];
      slideWidget = KeyboardInputTask(
        key: ValueKey(slide.id),
        sentence: _sentencesMap[sentenceId]!,
        onTaskCompleted: () {
          setState(() => taskCompleted = true);
          _updateQuestProgress(slide.type);
        },
      );
    } else if (slide.type == "listening_and_wordchips") {
      final sentencesCount = slide.translationBlockData!['sentence_ids'].length;
      final randomId = Random().nextInt(sentencesCount);
      final sentenceId = slide.translationBlockData!['sentence_ids'][randomId];
      final isReverse = slide.translationBlockData?['direction'] == "foreign_to_native";
      slideWidget = ListeningWordchipsTask(
        key: ValueKey(slide.id),
        sentence: _sentencesMap[sentenceId]!,
        isReverseTranslation: isReverse,
        onTaskCompleted: () {
          setState(() => taskCompleted = true);
          _updateQuestProgress(slide.type);
        },
      );
    } else if (slide.type == "listening_and_keyboard_input") {
      final sentencesCount = slide.translationBlockData!['sentence_ids'].length;
      final randomId = Random().nextInt(sentencesCount);
      final sentenceId = slide.translationBlockData!['sentence_ids'][randomId];
      slideWidget = KeyboardInputListeningTask(
        key: ValueKey(slide.id),
        sentence: _sentencesMap[sentenceId]!,
        onTaskCompleted: () {
          setState(() => taskCompleted = true);
          _updateQuestProgress(slide.type);
        },
      );
    } else if (slide.type == "reading_and_speaking") {
      final sentencesCount = slide.translationBlockData!['sentence_ids'].length;
      final randomId = Random().nextInt(sentencesCount);
      final sentenceId = slide.translationBlockData!['sentence_ids'][randomId];
      final isReverse = slide.translationBlockData?['direction'] == "foreign_to_native";
      slideWidget = SpeakingWithReadingTask(
        key: ValueKey(slide.id),
        sentence: _sentencesMap[sentenceId]!,
        isReverseTranslation: isReverse,
        onTaskCompleted: () {
          setState(() => taskCompleted = true);
          _updateQuestProgress(slide.type);
        },
        courseId: widget.courseId,
      );
    } else {
      slideWidget = const Center(child: Text("Невідомий тип слайду"));
    }

    return Scaffold(
      appBar: AppBar(
        title: Column(
          children: [
            Text(l10n.lessonTitle(widget.lesson.title)),
            const SizedBox(height: 4),
            LinearProgressIndicator(
              value: (currentSlideIndex + 1) / widget.lesson.slides.length,
              backgroundColor: Colors.grey[300],
              valueColor: AlwaysStoppedAnimation<Color>(
                Theme.of(context).primaryColor,
              ),
              minHeight: 6,
            ),
            Text(
              '${currentSlideIndex + 1} з ${widget.lesson.slides.length}',
              style: const TextStyle(fontSize: 12),
            ),
          ],
        ),
      ),
      body: Column(
        children: [
          Expanded(child: slideWidget),
          const SizedBox(height: 10),
          if (slide.type == "theory" || taskCompleted)
            Center(
              child: ElevatedButton(
                onPressed: _goToNextSlide,
                child: Text(l10n.nextTask),
              ),
            ),
          const SizedBox(height: 20),
        ],
      ),
    );
  }

  void _updateQuestProgress(String slideType) {
    final userProgress = Provider.of<UserProgressModel>(context, listen: false);
    for (var quest in userProgress.dailyQuests) {
      if (quest.isCompleted) continue;

      bool shouldUpdate = false;
      switch (quest.type) {
        case QuestType.completeLessons:
          break;
        case QuestType.completeLevels:
          break;
        case QuestType.completeTheoryLevel:
          if (slideType == 'theory') shouldUpdate = true;
          break;
        case QuestType.completePracticeLevel:
          if (slideType == 'practice') shouldUpdate = true;
          break;
        case QuestType.completeSpeakingTasks:
          if (slideType == 'reading_and_speaking') shouldUpdate = true;
          break;
        case QuestType.completeListeningTasks:
          if (['listening_and_wordchips', 'listening_and_keyboard_input'].contains(slideType)) {
            shouldUpdate = true;
          }
          break;
      }

      if (shouldUpdate) {
        userProgress.updateQuestProgress(quest);
      }
    }
  }
}