import 'package:flutter/material.dart';
import '../models/matching_pair.dart';
import '../widgets/matching_card.dart';
import 'dart:math';
import '../l10n/app_localizations.dart';

class MatchingGameScreen extends StatefulWidget {
  final List<MatchingPair> pairs;
  final int selectCount; // Додаємо selectCount
  final VoidCallback onTaskCompleted;

  const MatchingGameScreen({
    Key? key,
    required this.pairs,
    required this.selectCount, // Додаємо до конструктора
    required this.onTaskCompleted,
  }) : super(key: key);

  @override
  _MatchingGameScreenState createState() => _MatchingGameScreenState();
}

class _MatchingGameScreenState extends State<MatchingGameScreen> {
  List<String> shuffledCards = [];
  String? firstSelection;
  List<String> matchedPairs = [];
  String? errorSelection1;
  String? errorSelection2;

  @override
  void initState() {
    super.initState();
    _shufflePairs();
  }

  void _shufflePairs() {
    // Створюємо копію пар і перемішуємо
    final pairs = List<MatchingPair>.from(widget.pairs)..shuffle(Random());
    // Вибираємо перші selectCount пар, але не більше, ніж є пар
    final selectedPairs = pairs.take(widget.selectCount.clamp(0, pairs.length)).toList();

    // Формуємо shuffledCards із вибраних пар
    shuffledCards = selectedPairs.expand((pair) => [pair.first, pair.second]).toList();
    shuffledCards.shuffle(Random());

    matchedPairs.clear();
    firstSelection = null;
    errorSelection1 = null;
    errorSelection2 = null;
    setState(() {});
  }

  void _handleSelection(String text) {
    if (firstSelection == text) {
      setState(() {
        firstSelection = null;
      });
      return;
    }

    if (firstSelection == null) {
      setState(() {
        firstSelection = text;
      });
    } else {
      MatchingPair? selectedPair = widget.pairs.firstWhere(
            (pair) =>
        (pair.first == firstSelection && pair.second == text) ||
            (pair.second == firstSelection && pair.first == text),
        orElse: () => MatchingPair(first: "", second: ""),
      );

      if (selectedPair.first.isNotEmpty) {
        setState(() {
          matchedPairs.addAll([firstSelection!, text]);
          firstSelection = null;
        });

        // Якщо всі пари знайдено, викликаємо onTaskCompleted
        if (matchedPairs.length == shuffledCards.length) {
          Future.delayed(const Duration(milliseconds: 300), widget.onTaskCompleted);
        }
      } else {
        String error1 = firstSelection!;
        String error2 = text;

        setState(() {
          firstSelection = null;
          errorSelection1 = error1;
          errorSelection2 = error2;
        });

        Future.delayed(const Duration(milliseconds: 600), () {
          if (errorSelection1 == error1 && errorSelection2 == error2) {
            setState(() {
              errorSelection1 = null;
              errorSelection2 = null;
            });
          }
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!; // локалізовані строки

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 16.0),
          child: Text(
            l10n.collectMatchingPairs,
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
              color: Theme.of(context).colorScheme.onSurface,
            ),
          ),
        ),
        Expanded(
          child: LayoutBuilder(
            builder: (context, constraints) {
              int columns = constraints.maxWidth > 800 ? 4 : 2;
              double maxWidth = constraints.maxWidth * 0.6;
              return Center(
                child: Container(
                  width: maxWidth,
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: GridView.builder(
                    padding: const EdgeInsets.all(16),
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: columns,
                      crossAxisSpacing: 12,
                      mainAxisSpacing: 12,
                      childAspectRatio: 1.5,
                    ),
                    itemCount: shuffledCards.length,
                    itemBuilder: (context, index) {
                      String text = shuffledCards[index];
                      return MatchingCard(
                        text: text,
                        onTap: matchedPairs.contains(text)
                            ? () {}
                            : () => _handleSelection(text),
                        isSelected: matchedPairs.contains(text) || firstSelection == text,
                        isError: errorSelection1 == text || errorSelection2 == text,
                        isMatched: matchedPairs.contains(text),
                      );
                    },
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}