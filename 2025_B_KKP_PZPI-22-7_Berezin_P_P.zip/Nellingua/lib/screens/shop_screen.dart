import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../l10n/app_localizations.dart';
import '../xp_provider.dart';

class ShopScreen extends StatelessWidget {
  const ShopScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    final xpProvider = Provider.of<XpProvider>(context);
    final colorScheme = Theme
        .of(context)
        .colorScheme;

    return Scaffold(
      appBar: AppBar(
        title: Text(l10n.shop),
        centerTitle: true,
        actions: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8.0),
            child: Row(
              children: [
                const Icon(Icons.diamond, color: Colors.yellow, size: 20),
                const SizedBox(width: 4),
                Text(
                  '${xpProvider.gems}',
                  style: const TextStyle(fontSize: 16),
                ),
              ],
            ),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              l10n.xpMultipliers,
              style: Theme
                  .of(context)
                  .textTheme
                  .headlineSmall,
            ),
            const SizedBox(height: 16),
            Expanded(
              child: ListView(
                children: [
                  _buildMultiplierSection(context, l10n, 'x2 Multiplier', [
                    _MultiplierOption(2.0, 15, 35),
                    _MultiplierOption(2.0, 30, 60),
                    _MultiplierOption(2.0, 45, 85),
                  ]),
                  _buildMultiplierSection(context, l10n, 'x3 Multiplier', [
                    _MultiplierOption(3.0, 15, 65),
                    _MultiplierOption(3.0, 30, 120),
                    _MultiplierOption(3.0, 45, 175),
                  ]),
                  _buildMultiplierSection(context, l10n, 'x5 Multiplier', [
                    _MultiplierOption(5.0, 10, 85),
                    _MultiplierOption(5.0, 20, 155),
                    _MultiplierOption(5.0, 30, 225),
                  ]),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMultiplierSection(BuildContext context, AppLocalizations l10n,
      String title, List<_MultiplierOption> options) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: Theme
                  .of(context)
                  .textTheme
                  .titleMedium,
            ),
            const SizedBox(height: 8),
            ...options.map((option) =>
                _buildMultiplierOption(context, l10n, option)),
          ],
        ),
      ),
    );
  }

  Widget _buildMultiplierOption(BuildContext context, AppLocalizations l10n, _MultiplierOption option) {
    final xpProvider = Provider.of<XpProvider>(context);
    final canAfford = xpProvider.gems >= option.gemCost;
    return ListTile(
      title: Text('x${option.multiplier} XP (${option.durationMinutes} min)'),
      trailing: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 120), // Обмеження ширини
        child: ElevatedButton(
          onPressed: canAfford
              ? () async {
            final success = await xpProvider.purchaseMultiplier(
              option.multiplier,
              option.durationMinutes,
              option.gemCost,
            );
            if (!success) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text(l10n.insufficientGems)),
              );
            } else {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(
                    '${l10n.purchased} x${option.multiplier} XP (${option.durationMinutes} min)',
                  ),
                ),
              );
            }
          }
              : null,
          child: Row(
            mainAxisSize: MainAxisSize.min, // Зменшення розміру Row
            children: [
              Text(option.gemCost.toString()),
              const SizedBox(width: 4),
              const Icon(Icons.diamond, color: Colors.yellow, size: 20),
            ],
          ),
        ),
      ),
    );
  }
}

class _MultiplierOption {
  final double multiplier;
  final int durationMinutes;
  final int gemCost;

  _MultiplierOption(this.multiplier, this.durationMinutes, this.gemCost);
}

extension ShopLocalizations on AppLocalizations {
  String get shop => 'Shop';
  String get xpMultipliers => 'XP Multipliers';
  String get gems => 'Gems';
  String get buy => 'Buy';
  String get insufficientGems => 'Not enough gems';
  String get purchased => 'Purchased';
}