import 'dart:math';

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:provider/provider.dart';
import '../l10n/app_localizations.dart';
import '../models/user_model.dart';
import '../models/user_progress_model.dart';
import '../services/user_repository.dart';
import '../locale_provider.dart';

class CourseSelectionScreen extends StatefulWidget {
  const CourseSelectionScreen({super.key});

  @override
  State<CourseSelectionScreen> createState() => _CourseSelectionScreenState();
}

class _CourseSelectionScreenState extends State<CourseSelectionScreen> {
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  List<Map<String, dynamic>> _allCourses = [];
  List<Map<String, dynamic>> _userCourses = [];
  AppUser? _currentUser;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    final user = await UserRepository.getCurrentUser();
    if (user == null) return;

    final allCoursesSnapshot = await _db.collection('courses').get();

    List<Map<String, dynamic>> userCourses = [];
    if (user.enrolledCourses.isNotEmpty) {
      final userCoursesSnapshot = await _db
          .collection('courses')
          .where(FieldPath.documentId, whereIn: user.enrolledCourses)
          .get();
      userCourses = userCoursesSnapshot.docs.map((doc) {
        final data = doc.data();
        data['id'] = doc.id;
        return data;
      }).toList();
    }

    if (!mounted) return;

    setState(() {
      _currentUser = user;
      _allCourses = allCoursesSnapshot.docs.map((doc) {
        final data = doc.data();
        data['id'] = doc.id;
        return data;
      }).toList();
      _userCourses = userCourses;
    });
  }

  Future<void> _enrollInCourse(String courseId) async {
    if (_currentUser == null) return;

    await UserRepository.enrollInCourse(_currentUser!.uid, courseId);
    await UserRepository.updateCurrentCourse(_currentUser!.uid, courseId);

    if (mounted) {
      final userProgress = Provider.of<UserProgressModel>(context, listen: false);
      userProgress.userId = _currentUser!.uid;
      userProgress.courseId = courseId;
      await userProgress.loadProgress(); // чекаємо завершення завантаження прогресу

      // оновлюємо локалізацію
      final localeProvider = Provider.of<LocaleProvider>(context, listen: false);
      await localeProvider.updateLocale(_currentUser!.uid, courseId);

      //print('[DEBUG] CourseSelectionScreen: Updated UserProgressModel: userId = ${userProgress.userId}, courseId = ${userProgress.courseId}, progressData = ${userProgress.progressData}');
      Navigator.pushReplacementNamed(context, '/unit');
    }
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;

    return Scaffold(
      appBar: AppBar(
        title: Text(l10n.chooseCourse),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pushReplacementNamed(
              context,
              '/home',
              arguments: {'skipRedirect': true},
            );
          },
        ),
      ),
      body: _currentUser == null
          ? const Center(child: CircularProgressIndicator())
          : DefaultTabController(
        length: 2,
        child: Column(
          children: [
            TabBar(
              labelColor: Theme.of(context).colorScheme.primary,
              unselectedLabelColor: Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
              indicatorColor: Theme.of(context).colorScheme.primary,
              tabs: [
                Tab(text: l10n.myCourses),
                Tab(text: l10n.allCourses),
              ],
            ),
            Expanded(
              child: TabBarView(
                children: [
                  _buildUserCoursesList(),
                  _buildAllCoursesList(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildUserCoursesList() {
    final l10n = AppLocalizations.of(context)!;

    //print('\n[DEBUG] LANGUAGE: ${AppLocalizations.}');

    if (_userCourses.isEmpty) {
      return Center(
        child: Text(
          l10n.noCoursesEnrolled,
          style: Theme.of(context).textTheme.bodyMedium,
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _userCourses.length,
      itemBuilder: (context, index) {
        final course = _userCourses[index];
        return Card(
          child: ListTile(
            contentPadding: const EdgeInsets.all(16),
            title: Text(
              course['name'] ?? l10n.unnamedCourse,
              style: Theme.of(context).textTheme.headlineSmall,
            ),
            subtitle: Text(
              '${course['base_language']} → ${course['target_language']}',
              style: Theme.of(context).textTheme.bodySmall,
            ),
            trailing: _currentUser?.currentCourseId == course['id']
                ? Icon(Icons.check_circle, color: Theme.of(context).colorScheme.primary)
                : null,
            onTap: () async {
              await UserRepository.updateCurrentCourse(
                _currentUser!.uid,
                course['id'],
              );
              if (mounted) {
                Navigator.pushReplacementNamed(context, '/unit');
              }
            },
          ),
        );
      },
    );
  }

  Widget _buildAllCoursesList() {
    final l10n = AppLocalizations.of(context)!;

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _allCourses.length,
      itemBuilder: (context, index) {
        final course = _allCourses[index];
        final isEnrolled = _currentUser?.enrolledCourses.contains(course['id']) ?? false;

        return Card(
          child: ListTile(
            contentPadding: const EdgeInsets.all(16),
            title: Text(
              course['name'] ?? l10n.unnamedCourse,
              style: Theme.of(context).textTheme.headlineSmall,
            ),
            subtitle: Text(
              '${course['base_language']} → ${course['target_language']}',
              style: Theme.of(context).textTheme.bodySmall,
            ),
            trailing: isEnrolled
                ? Icon(Icons.check_circle, color: Theme.of(context).colorScheme.primary)
                : ElevatedButton(
              onPressed: () => _enrollInCourse(course['id']),
              child: Text(l10n.enroll),
              style: ElevatedButton.styleFrom(
                backgroundColor: Theme.of(context).colorScheme.secondary,
                foregroundColor: Colors.white,
              ),
            ),
          ),
        );
      },
    );
  }
}