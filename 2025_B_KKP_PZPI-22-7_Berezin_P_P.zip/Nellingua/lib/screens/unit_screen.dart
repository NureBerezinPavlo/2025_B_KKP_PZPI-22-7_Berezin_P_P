import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:provider/provider.dart';
import '../models/course_model.dart';
import '../models/user_model.dart';
import '../models/user_progress_model.dart';
import '../services/lesson_loader.dart';
import '../services/user_repository.dart';
import '../widgets/lesson_selection_dialog.dart';
import '../widgets/unit_map_widget.dart';
import 'lesson_screen.dart';
import '../l10n/app_localizations.dart';
import '../xp_provider.dart';

class UnitScreen extends StatefulWidget {
  const UnitScreen({super.key});

  @override
  State<UnitScreen> createState() => _UnitScreenState();
}

class _UnitScreenState extends State<UnitScreen> {
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  AppUser? _currentUser;
  Map<String, dynamic>? _currentCourse;
  List<Map<String, dynamic>> _units = [];
  int _selectedUnitIndex = 0;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    final user = await UserRepository.getCurrentUser();
    if (user == null || user.currentCourseId == null) {
      if (mounted) Navigator.pushReplacementNamed(context, '/home');
      return;
    }

    final courseDoc = await _db.collection('courses').doc(user.currentCourseId).get();
    final unitIds = List<String>.from(courseDoc['units'] ?? []);
    final unitsSnapshot = await _db
        .collection('units')
        .where(FieldPath.documentId, whereIn: unitIds)
        .get();

    if (!mounted) return;

    final userProgress = Provider.of<UserProgressModel>(context, listen: false);
    if (userProgress.courseId != user.currentCourseId) {
      userProgress.courseId = user.currentCourseId!;
    }

    setState(() {
      _currentUser = user;
      _currentCourse = courseDoc.data()!..['id'] = courseDoc.id;
      _units = unitsSnapshot.docs.map((doc) => doc.data()).toList();
    });
  }

  void _navigateToUnit(int index) {
    if (index < 0 || index >= _units.length) return;
    setState(() => _selectedUnitIndex = index);
  }

  void _handleLevelTap(Map<String, dynamic> level, int levelIndex) {
    _showLessonSelectionDialog(level, levelIndex);
  }

  void _showLessonSelectionDialog(Map<String, dynamic> level, int levelIndex) {
    final lessons = List<Map<String, dynamic>>.from(level['lessons'] ?? []);
    final progress = Provider.of<UserProgressModel>(context, listen: false);
    final courseId = _currentCourse!['id'];

    showDialog(
      context: context,
      builder: (context) => LessonSelectionDialog(
        lessons: lessons,
        currentLessonIndex: progress.getCurrentLessonIndex(courseId),
        levelIndex: levelIndex,
        unitIndex: _selectedUnitIndex,
        courseId: courseId,
        onLessonSelected: (lessonIndex) {
          _startLesson(level, levelIndex, lessonIndex);
        },
      ),
    );
  }

  void _startLesson(Map<String, dynamic> level, int levelIndex, int lessonIndex) async {
    final course = _currentCourse!;
    final user = _currentUser!;

    if (level['lessons'] == null || level['lessons'].isEmpty) {
      showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Помилка'),
          content: const Text('Уроки для цього рівня не знайдені'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('OK'))
          ],
        ),
      );
      return;
    }

    final lesson = await LessonLoader().fetchLesson(
      courseId: course['id'],
      unitIndex: _selectedUnitIndex,
      levelIndex: levelIndex,
      lessonIndex: lessonIndex,
      userId: user.uid,
    );

    if (mounted) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => ChangeNotifierProvider<CourseModel>(
            create: (_) => CourseModel(
              id: course['id'],
              data: {
                ...course,
                'units': _units,
              },
            ),
            child: LessonScreen(
              lesson: lesson,
              courseId: course['id'],
              unitIndex: _selectedUnitIndex,
              levelIndex: levelIndex,
              lessonIndex: lessonIndex,
            ),
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_currentUser == null || _currentCourse == null) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    return _buildMainUnitScreen();
  }

  Widget _buildMainUnitScreen() {
    final progress = Provider.of<UserProgressModel>(context);
    final xpProvider = Provider.of<XpProvider>(context);
    final currentLevelIndex = progress.getCurrentLevelIndex(_currentCourse!['id']);
    final currentUnitIndex = progress.getCurrentUnitIndex(_currentCourse!['id']);
    final l10n = AppLocalizations.of(context)!;

    String? multiplierText;
    if (xpProvider.hasActiveMultiplier) {
      final remainingTime = Duration(
        milliseconds: xpProvider.multiplierEndTimestamp! - DateTime.now().millisecondsSinceEpoch,
      );
      final minutes = remainingTime.inMinutes;
      final seconds = remainingTime.inSeconds % 60;
      multiplierText = l10n.xpMultiplierActiveWithTime(
        xpProvider.xpMultiplier,
        minutes,
        seconds,
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: Text(_currentCourse!['name']),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pushReplacementNamed(
              context,
              '/home',
              arguments: {'skipRedirect': true},
            );
          },
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8.0),
            child: Row(
              children: [
                const Icon(Icons.diamond, color: Colors.yellow, size: 20),
                const SizedBox(width: 4),
                Text(
                  '${_currentUser!.gems}',
                  style: const TextStyle(fontSize: 16),
                ),
                const SizedBox(width: 8),
                const Icon(Icons.star, color: Colors.amber, size: 20),
                const SizedBox(width: 4),
                Text(
                  xpProvider.xp.toString(),
                  style: const TextStyle(fontSize: 16),
                ),
                if (multiplierText != null) ...[
                  const SizedBox(width: 8),
                  Text(
                    multiplierText,
                    style: const TextStyle(fontSize: 14, color: Colors.green),
                  ),
                ],
              ],
            ),
          ),
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: () {
              Navigator.pushNamed(context, '/settings');
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: _units.isEmpty
                ? const Center(child: Text('Немає доступних юнітів'))
                : UnitMapWidget(
              unitData: _units[_selectedUnitIndex],
              onLevelTap: (level) {
                final levelIndex = _units[_selectedUnitIndex]['levels']
                    .indexWhere((l) => l['id'] == level['id']);
                if (levelIndex != -1) {
                  _handleLevelTap(level, levelIndex);
                }
              },
              currentLevelIndex: currentLevelIndex,
              currentUnitIndex: currentUnitIndex,
              selectedUnitIndex: _selectedUnitIndex,
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                IconButton(
                  icon: const Icon(Icons.arrow_back),
                  onPressed: () => _navigateToUnit(_selectedUnitIndex - 1),
                  color: _selectedUnitIndex == 0 ? Colors.grey : null,
                ),
                Text(
                  l10n.unitAOfB(_selectedUnitIndex + 1, _units.length),
                  style: const TextStyle(fontSize: 16),
                ),
                IconButton(
                  icon: const Icon(Icons.arrow_forward),
                  onPressed: () => _navigateToUnit(_selectedUnitIndex + 1),
                  color: _selectedUnitIndex == _units.length - 1 ? Colors.grey : null,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}