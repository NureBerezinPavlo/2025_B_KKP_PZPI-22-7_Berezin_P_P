import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../l10n/app_localizations.dart';
import '../models/user_progress_model.dart';
import '../services/user_repository.dart';
import '../models/user_model.dart';
import '../widgets/daily_quests_widget.dart';
import '../xp_provider.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;

    return FutureBuilder<AppUser?>(
      future: UserRepository.getCurrentUser(),
      builder: (context, snapshot) {
        print('[DEBUG] HomeScreen FutureBuilder: connectionState = ${snapshot.connectionState}, hasData = ${snapshot.hasData}, data = ${snapshot.data}');

        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }

        if (snapshot.hasError) {
          print('[DEBUG] HomeScreen FutureBuilder error: ${snapshot.error}');
          return Scaffold(
            body: Center(child: Text('Error: ${snapshot.error}')),
          );
        }

        final currentUser = snapshot.data;
        if (currentUser == null) {
          print('[DEBUG] HomeScreen: No currentUser, navigating to AuthScreen');
          WidgetsBinding.instance.addPostFrameCallback((_) {
            Navigator.pushReplacementNamed(context, '/auth');
          });
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }

        final userProgress = Provider.of<UserProgressModel>(context, listen: false);
        userProgress.userId = currentUser.uid;
        userProgress.courseId = currentUser.currentCourseId ?? '';

        return Consumer<XpProvider>(
          builder: (context, xpProvider, child) {
            String? multiplierText;
            if (xpProvider.hasActiveMultiplier) {
              final remainingTime = Duration(
                milliseconds: xpProvider.multiplierEndTimestamp! - DateTime.now().millisecondsSinceEpoch,
              );
              final minutes = remainingTime.inMinutes;
              final seconds = remainingTime.inSeconds % 60;
              multiplierText = l10n.xpMultiplierActiveWithTime(
                xpProvider.xpMultiplier,
                minutes,
                seconds,
              );
            }

            return Scaffold(
              appBar: AppBar(
                title: const Text('Nellingua'),
                actions: [
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 8.0),
                    child: Row(
                      children: [
                        const Icon(Icons.diamond, color: Colors.yellow, size: 20),
                        const SizedBox(width: 4),
                        Text(
                          '${currentUser.gems}',
                          style: const TextStyle(fontSize: 16),
                        ),
                        const SizedBox(width: 8),
                        const Icon(Icons.star, color: Colors.amber, size: 20),
                        const SizedBox(width: 4),
                        Text(
                          xpProvider.xp.toString(),
                          style: const TextStyle(fontSize: 16),
                        ),
                        if (multiplierText != null) ...[
                          const SizedBox(width: 8),
                          Text(
                            multiplierText,
                            style: const TextStyle(fontSize: 14, color: Colors.green),
                          ),
                        ],
                      ],
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.settings),
                    onPressed: () {
                      Navigator.pushNamed(context, '/settings');
                    },
                  ),
                  IconButton(
                    icon: const Icon(Icons.shopping_cart),
                    onPressed: () {
                      Navigator.pushNamed(context, '/shop');
                    },
                  ),
                  IconButton(
                    icon: const Icon(Icons.logout),
                    onPressed: () async {
                      await FirebaseAuth.instance.signOut();
                      Navigator.pushReplacementNamed(context, '/auth');
                    },
                  ),
                ],
              ),
              body: Padding(
                padding: const EdgeInsets.all(24.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      l10n.welcomeUsername(currentUser.displayName ?? 'User'),
                      style: Theme.of(context).textTheme.headlineMedium,
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 16),
                    const DailyQuestsWidget(),
                    const SizedBox(height: 32),
                    ElevatedButton(
                      onPressed: () {
                        Navigator.pushNamed(context, '/courses');
                      },
                      style: ElevatedButton.styleFrom(
                        minimumSize: const Size(double.infinity, 56),
                      ),
                      child: Text(l10n.startLearning),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }
}