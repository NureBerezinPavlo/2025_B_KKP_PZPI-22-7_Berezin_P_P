class StrokePracticeData {
  final String characters;
  final int showMode;
  final bool allowModeSwitch;
  final Map<String, List<String>>? strokesByChar;
  final Map<String, List<List<List<num>>>>? mediansByChar;

  StrokePracticeData({
    required this.characters,
    required this.showMode,
    required this.allowModeSwitch,
    this.strokesByChar,
    this.mediansByChar,
  });

  factory StrokePracticeData.fromJson(Map<String, dynamic> json) {
    return StrokePracticeData(
      characters: json['characters'],
      showMode: json['showMode'],
      allowModeSwitch: json['allowModeSwitch'],
    );
  }
}