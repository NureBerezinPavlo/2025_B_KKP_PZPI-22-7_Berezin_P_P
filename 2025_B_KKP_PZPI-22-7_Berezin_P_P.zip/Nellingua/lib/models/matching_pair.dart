class MatchingPair {
  final String first;
  final String second;

  MatchingPair({required this.first, required this.second});

  factory MatchingPair.fromJson(Map<String, dynamic> json) {
    return MatchingPair(
      first: json['first'],
      second: json['second'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'first': first,
      'second': second,
    };
  }
}