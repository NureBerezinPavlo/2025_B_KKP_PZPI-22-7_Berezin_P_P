class AppUser {
  final String uid;
  final String? email;
  final String? displayName;
  final String? photoUrl;
  final List<String> enrolledCourses;
  final String? currentCourseId;
  final int gems;

  AppUser({
    required this.uid,
    this.email,
    this.displayName,
    this.photoUrl,
    this.enrolledCourses = const [],
    this.currentCourseId,
    this.gems = 100,
  });

  factory AppUser.fromMap(Map<String, dynamic> map) {
    //print('[DEBUG] AppUser.fromMap: map = $map');
    try {
      return AppUser(
        uid: map['uid'] as String? ?? '',
        email: map['email'] as String?,
        displayName: map['displayName'] as String?,
        photoUrl: map['photoUrl'] as String?,
        enrolledCourses: List<String>.from(map['enrolledCourses'] ?? []),
        currentCourseId: map['currentCourseId'] as String?,
        gems: map['gems'] as int? ?? 0,
      );
    } catch (e, stackTrace) {
      //print('[DEBUG] AppUser.fromMap error: $e');
      //print('[DEBUG] Stack trace: $stackTrace');
      rethrow;
    }
  }

  factory AppUser.fromFirestore(Map<String, dynamic> data, String uid) {
    //print('[DEBUG] AppUser.fromFirestore: data = $data, uid = $uid');
    return AppUser.fromMap({...data, 'uid': uid});
  }

  Map<String, dynamic> toMap() {
    return {
      'uid': uid,
      'email': email,
      'displayName': displayName,
      'photoUrl': photoUrl,
      'enrolledCourses': enrolledCourses,
      'currentCourseId': currentCourseId,
      'gems': gems,
    };
  }
}