import 'package:flutter/foundation.dart';
import 'matching_pair.dart';
import 'assemble_character_model.dart';
import 'stroke_practice_data.dart';

class TheorySlide {
  final String id;
  final String type;
  final List<SlideContent> content;
  final List<MatchingPair>? matchingPairs;
  final int? selectCount;
  final List<AssembleCharacter>? assembleCharacters;
  final StrokePracticeData? strokeData;
  final Map<String, dynamic>? translationBlockData;
  final Map<String, dynamic>? keyboardInputData;

  TheorySlide({
    required this.id,
    required this.type,
    required this.content,
    this.matchingPairs,
    this.selectCount,
    this.assembleCharacters,
    this.strokeData,
    this.translationBlockData,
    this.keyboardInputData,
  });

  factory TheorySlide.fromJson(Map<String, dynamic> json) {
    final String type = json['type'];
    Map<String, dynamic>? translationBlockData;
    Map<String, dynamic>? keyboardInputData;

    if (type == 'translation_block') {
      translationBlockData = {
        'direction': json['content']['direction'],
        'sentence_ids': List<String>.from(json['content']['sentence_ids']),
      };
    } else if (type == 'keyboard_input') {
      keyboardInputData = {
        'direction': json['content']['direction'],
        'sentence_ids': List<String>.from(json['content']['sentence_ids']),
      };
    }

    return TheorySlide(
      id: json['id'],
      type: type,
      content: (json['content'] is List)
          ? (json['content'] as List<dynamic>)
          .map((c) => SlideContent.fromJson(c))
          .toList()
          : [],
      matchingPairs: json['matchingPairs'] != null
          ? (json['matchingPairs'] as List<dynamic>)
          .map((p) => MatchingPair.fromJson(p))
          .toList()
          : null,
      selectCount: json['selectCount'] as int?, // Додаємо парсинг selectCount
      assembleCharacters: type == 'assemble_character'
          ? ((json['content']?['characters'] ?? []) as List<dynamic>)
          .map((e) => AssembleCharacter.fromJson(e))
          .toList()
          : null,
      strokeData: type == 'stroke_practice'
          ? StrokePracticeData.fromJson({
        'characters': json['characters'],
        'showMode': json['showMode'],
        'allowModeSwitch': json['allowModeSwitch'],
      })
          : null,
      translationBlockData: translationBlockData,
      keyboardInputData: keyboardInputData,
    );
  }
}

class SlideContent {
  final String type;
  final dynamic value;

  SlideContent({required this.type, required this.value});

  factory SlideContent.fromJson(Map<String, dynamic> json) {
    return SlideContent(
      type: json['type'],
      value: json['value'],
    );
  }
}