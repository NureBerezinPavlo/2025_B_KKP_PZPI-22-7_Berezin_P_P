import 'dart:math';

import '../l10n/app_localizations.dart';
import 'package:flutter/material.dart';

enum QuestType {
  completeLessons, // Пройти {0} уроків
  completeLevels, // Пройти {0} рівнів будь-якого типу
  completeTheoryLevel, // Пройти рівень типу «Теорія»
  completePracticeLevel, // Пройти рівень типу «Практика»
  completeSpeakingTasks, // Виконати {0} вправ на говоріння
  completeListeningTasks, // Виконати {0} вправ на слухання
}

class DailyQuest {
  final String id; // Унікальний ID квесту
  final QuestType type;
  final int target; // Ціль (наприклад, кількість уроків)
  final int progress; // Поточний прогрес
  final int reward; // Нагорода в Gems
  final bool isCompleted; // Чи завершено квест

  DailyQuest({
    required this.id,
    required this.type,
    required this.target,
    this.progress = 0,
    required this.reward,
    this.isCompleted = false,
  });

  factory DailyQuest.generateRandom(String seed) {
    final random = Random(seed.hashCode);
    final type = QuestType.values[random.nextInt(QuestType.values.length)];
    int target;
    int reward;

    switch (type) {
      case QuestType.completeLessons:
        target = random.nextInt(3) + 1; // 1-3 уроки
        reward = target * 10; // 10 Gems за урок
        break;
      case QuestType.completeLevels:
        target = random.nextInt(2) + 1; // 1-2 рівні
        reward = target * 15; // 15 Gems за рівень
        break;
      case QuestType.completeTheoryLevel:
      case QuestType.completePracticeLevel:
        target = 1; // 1 рівень
        reward = 20; // 20 Gems за специфічний рівень
        break;
      case QuestType.completeSpeakingTasks:
      case QuestType.completeListeningTasks:
        target = random.nextInt(3) + 2; // 2-4 завдання
        reward = target * 5; // 5 Gems за завдання
        break;
    }

    return DailyQuest(
      id: 'quest_${seed}_${type.toString().split('.').last}',
      type: type,
      target: target,
      reward: reward,
    );
  }

  DailyQuest copyWith({
    int? progress,
    bool? isCompleted,
  }) {
    return DailyQuest(
      id: id,
      type: type,
      target: target,
      progress: progress ?? this.progress,
      reward: reward,
      isCompleted: isCompleted ?? this.isCompleted,
    );
  }

  factory DailyQuest.fromMap(Map<String, dynamic> map) {
    return DailyQuest(
      id: map['id'],
      type: QuestType.values
          .firstWhere((e) => e.toString() == 'QuestType.${map['type']}'),
      target: map['target'],
      progress: map['progress'] ?? 0,
      reward: map['reward'],
      isCompleted: map['isCompleted'] ?? false,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'type': type.toString().split('.').last,
      'target': target,
      'progress': progress,
      'reward': reward,
      'isCompleted': isCompleted,
    };
  }

  String description(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    if (l10n == null) {
      return 'Error: Localization not available';
    }
    switch (type) {
      case QuestType.completeLessons:
        return l10n.questCompleteLessons(target);
      case QuestType.completeLevels:
        return l10n.questCompleteLevels(target);
      case QuestType.completeTheoryLevel:
        return l10n.questCompleteTheoryLevel;
      case QuestType.completePracticeLevel:
        return l10n.questCompletePracticeLevel;
      case QuestType.completeSpeakingTasks:
        return l10n.questCompleteSpeakingTasks(target);
      case QuestType.completeListeningTasks:
        return l10n.questCompleteListeningTasks(target);
    }
  }
}