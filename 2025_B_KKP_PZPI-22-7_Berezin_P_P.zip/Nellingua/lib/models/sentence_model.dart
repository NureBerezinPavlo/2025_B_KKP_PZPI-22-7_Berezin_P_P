class Sentence {
  final String sentenceId;
  final ForeignData foreign;
  final NativeData native;
  final List<String> exerciseTypes;

  Sentence({
    required this.sentenceId,
    required this.foreign,
    required this.native,
    required this.exerciseTypes,
  });

  factory Sentence.fromJson(Map<String, dynamic> json) {
    return Sentence(
      sentenceId: json['sentence_id']?.toString() ?? 'no_id',
      foreign: ForeignData.fromJson(json['foreign'] ?? {}),
      native: NativeData.fromJson(json['native'] ?? {}),
      exerciseTypes: List<String>.from(json['exercise_types'] ?? []),
    );
  }
}

class ForeignData {
  final List<ForeignOption> defaultOptions;
  final List<String> alternativeOptions;

  ForeignData({
    required this.defaultOptions,
    required this.alternativeOptions,
  });

  factory ForeignData.fromJson(Map<String, dynamic> json) {
    return ForeignData(
      defaultOptions: (json['default_options'] as List<dynamic>?)
          ?.map((e) => ForeignOption.fromJson(e))
          .toList() ?? [],
      alternativeOptions: List<String>.from(json['alternative_options'] ?? []),
    );
  }
}

class NativeData {
  final List<NativeOption> defaultOptions;
  final List<String> alternativeOptions;

  NativeData({
    required this.defaultOptions,
    required this.alternativeOptions,
  });

  factory NativeData.fromJson(Map<String, dynamic> json) {
    return NativeData(
      defaultOptions: (json['default_options'] as List<dynamic>?)
          ?.map((e) => NativeOption.fromJson(e))
          .toList() ?? [],
      alternativeOptions: List<String>.from(json['alternative_options'] ?? []),
    );
  }
}

class ForeignOption {
  final String sentence;
  final List<HighlightedWord> highlightedWords;
  final List<NativeSpeakerAudio> nativeSpeakersAudio;

  ForeignOption({
    required this.sentence,
    required this.highlightedWords,
    required this.nativeSpeakersAudio,
  });

  factory ForeignOption.fromJson(Map<String, dynamic> json) {
    return ForeignOption(
      sentence: json['sentence']?.toString() ?? '',
      highlightedWords: (json['highlighted_words'] as List<dynamic>?)
          ?.map((e) => HighlightedWord.fromJson(e))
          .toList() ??
          [],
      nativeSpeakersAudio: (json['native_speakers_audio'] as List<dynamic>?)
          ?.map((e) => NativeSpeakerAudio.fromJson(e))
          .toList() ??
          [],
    );
  }
}

class NativeOption {
  final String sentence;
  final List<HighlightedWord> highlightedWords;

  NativeOption({
    required this.sentence,
    required this.highlightedWords,
  });

  factory NativeOption.fromJson(Map<String, dynamic> json) {
    return NativeOption(
      sentence: json['sentence']?.toString() ?? '',
      highlightedWords: (json['highlighted_words'] as List<dynamic>?)
          ?.map((e) => HighlightedWord.fromJson(e))
          .toList() ?? [],
    );
  }
}

class HighlightedWord {
  final int from;
  final int to;
  final String wordID;
  final List<String> translationOptions;

  HighlightedWord({
    required this.from,
    required this.to,
    required this.wordID,
    required this.translationOptions,
  });

  factory HighlightedWord.fromJson(Map<String, dynamic> json) {
    return HighlightedWord(
      from: json['from'] as int? ?? 0,
      to: json['to'] as int? ?? 0,
      wordID: json['wordID']?.toString() ?? '',
      translationOptions: List<String>.from(json['translation_options'] ?? []),
    );
  }
}

class NativeSpeakerAudio {
  final String author;
  final String normal;
  final String aLittleBitMoreSlowly;
  final String moreSlowly;
  final String muchMoreSlowly;
  final String superSlowly;

  NativeSpeakerAudio({
    required this.author,
    required this.normal,
    required this.aLittleBitMoreSlowly,
    required this.moreSlowly,
    required this.muchMoreSlowly,
    required this.superSlowly,
  });

  factory NativeSpeakerAudio.fromJson(Map<String, dynamic> json) {
    return NativeSpeakerAudio(
      author: json['author'] ?? '',
      normal: json['normal'] ?? '',
      aLittleBitMoreSlowly: json['a_little_bit_more_slowly'] ?? '',
      moreSlowly: json['more_slowly'] ?? '',
      muchMoreSlowly: json['much_more_slowly'] ?? '',
      superSlowly: json['super_slowly'] ?? '',
    );
  }
}