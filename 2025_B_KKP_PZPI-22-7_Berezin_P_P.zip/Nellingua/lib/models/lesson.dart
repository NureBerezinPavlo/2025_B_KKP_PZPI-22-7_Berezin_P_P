import 'theory_slide.dart';
import 'matching_pair.dart';

class Lesson {
  final String title;
  final List<TheorySlide> slides;

  Lesson({required this.title, required this.slides});

  factory Lesson.fromJson(Map<String, dynamic> json) {
    // 1) беремо заголовок із "title", якщо його немає — із "name", або даємо дефолт
    final title = (json['title'] as String?)
        ?? (json['name'] as String?)
        ?? 'Без назви уроку';

    // 2) беремо список слайдів або з ключа "slides", або з "lessons"
    final rawSlides = (json['slides'] as List<dynamic>?)
        ?? (json['lessons'] as List<dynamic>?)
        ?? [];

    final slides = rawSlides
        .map((slide) => TheorySlide.fromJson(Map<String, dynamic>.from(slide)))
        .toList();

    return Lesson(
      title: title,
      slides: slides,
    );
  }
}