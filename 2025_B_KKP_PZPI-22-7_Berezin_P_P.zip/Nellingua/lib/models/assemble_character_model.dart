import 'dart:ui';

class CharacterComponent {
  final String graph;
  final Rect targetRect;

  CharacterComponent({required this.graph, required this.targetRect});

  factory CharacterComponent.fromJson(Map<String, dynamic> json) {
    return CharacterComponent(
      graph: json['graph'],
      targetRect: Rect.fromLTWH(
        (json['rect'][0] as num).toDouble(),
        (json['rect'][1] as num).toDouble(),
        (json['rect'][2] as num).toDouble(),
        (json['rect'][3] as num).toDouble(),
      ),
    );
  }
}

class AssembleCharacter {
  final String character;
  final List<CharacterComponent> components;

  AssembleCharacter({required this.character, required this.components});

  factory AssembleCharacter.fromJson(Map<String, dynamic> json) {
    return AssembleCharacter(
      character: json['character'],
      components: (json['components'] as List)
          .map((c) => CharacterComponent.fromJson(c))
          .toList(),
    );
  }
}