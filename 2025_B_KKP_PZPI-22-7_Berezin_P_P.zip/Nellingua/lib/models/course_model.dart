import 'package:flutter/material.dart';

class CourseModel extends ChangeNotifier {
  final String id;
  final Map<String, dynamic> data;

  CourseModel({required this.id, required this.data});

  String get name => data['name'] ?? 'Без назви';
  List<Map<String, dynamic>> get units => List<Map<String, dynamic>>.from(data['units'] ?? []);
}