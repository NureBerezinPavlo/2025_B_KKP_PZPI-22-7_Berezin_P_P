import 'dart:ui';

class GraphComponent {
  final String graph; // Наприклад, "立"
  final Rect targetRect; // Відносні координати в межах тяньцзиґе (0..1)

  GraphComponent({required this.graph, required this.targetRect});
}

class CharacterBuildTask {
  final String character; // Ієрогліф
  final List<GraphComponent> components;

  CharacterBuildTask({required this.character, required this.components});
}