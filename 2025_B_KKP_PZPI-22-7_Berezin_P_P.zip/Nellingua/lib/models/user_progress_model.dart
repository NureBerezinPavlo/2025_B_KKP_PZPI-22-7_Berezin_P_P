import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../locale_provider.dart';
import '../services/user_repository.dart';
import 'daily_quest.dart';
import 'dart:math';

class UserProgressModel extends ChangeNotifier {
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  String _userId;
  String _courseId;
  Map<String, dynamic> progressData = {};
  List<DailyQuest> dailyQuests = [];
  DateTime? lastQuestReset;

  // Глобальний ключ для доступу до контексту
  static final navigatorKey = GlobalKey<NavigatorState>();

  UserProgressModel(this._userId, this._courseId) {
    print('[DEBUG] UserProgressModel constructor: userId = $_userId, courseId = $_courseId');
    if (_userId.isNotEmpty && _courseId.isNotEmpty) {
      loadProgress();
    } else {
      loadDailyQuests();
      print('[DEBUG] userId or courseId empty — skipping progress load');
    }
  }

  set userId(String value) {
    if (_userId != value && value.isNotEmpty) {
      _userId = value;
      print('[DEBUG] Updated userId to: $_userId');
      if (_courseId.isNotEmpty) {
        loadProgress();
      }
    }
  }

  set courseId(String value) {
    if (_courseId != value) {
      _courseId = value;
      _updateCourseId();
      notifyListeners();
    }
  }

  Future<void> _updateCourseId() async {
    try {
      await UserRepository.updateCurrentCourse(_userId, _courseId);
      await loadProgress();
      final context = navigatorKey.currentContext;
      if (context != null) {
        final localeProvider = Provider.of<LocaleProvider>(context, listen: false);
        await localeProvider.updateLocale(_userId, _courseId);
      } else {
        print('[DEBUG] UserProgressModel._updateCourseId: Context is null, skipping locale update');
      }
    } catch (e) {
      print('[DEBUG] UserProgressModel._updateCourseId error: $e');
    }
  }

  String get userId => _userId;
  String get courseId => _courseId;

  Future<void> loadProgress() async {
    print('[DEBUG] loadProgress called: userId = $_userId, courseId = $_courseId');
    if (_userId.isEmpty || _courseId.isEmpty) {
      print('[DEBUG] userId or courseId empty in loadProgress — skipping');
      return;
    }

    try {
      final doc = await _db.collection('user_progress').doc(_userId).get();
      final allCourses = (doc.data()?['courses'] as Map<String, dynamic>?) ?? {};
      final progress = allCourses[_courseId] as Map<String, dynamic>?;
      print('[DEBUG] Firestore query result: exists = ${doc.exists}, data = ${doc.data()}');

      if (doc.exists && progress != null) {
        progressData = progress;
        print('[DEBUG] progressData loaded for $_courseId: $progressData');
      } else {
        progressData = {
          'currentUnitIndex': 0,
          'currentLevelIndex': 0,
          'currentLesson': 0,
        };
        print('[DEBUG] Document does not exist or no progress for course, initializing default progressData');
      }

      await loadDailyQuests();
      notifyListeners();
    } catch (e, stackTrace) {
      print('[DEBUG] Error loading progress: $e');
      print('[DEBUG] Stack trace: $stackTrace');
    }
  }

  int getCurrentUnitIndex(String courseId) {
    final index = progressData['currentUnitIndex'] ?? 0;
    print('[DEBUG] getCurrentUnitIndex: courseId = $courseId, index = $index');
    return index;
  }

  int getCurrentLevelIndex(String courseId) {
    final index = progressData['currentLevelIndex'] ?? 0;
    print('[DEBUG] getCurrentLevelIndex: courseId = $courseId, index = $index');
    return index;
  }

  int getCurrentLessonIndex(String courseId) {
    final index = progressData['currentLesson'] ?? 0;
    print('[DEBUG] getCurrentLessonIndex: courseId = $courseId, index = $index');
    return index;
  }

  Future<bool> moveToNextLesson(String courseId, Map<String, dynamic> course) async {
    print('[DEBUG] moveToNextLesson called: userId = $_userId, courseId = $courseId');
    if (_userId.isEmpty || courseId.isEmpty) {
      print('[DEBUG] Error: userId or courseId empty, cannot save progress');
      return false;
    }

    final units = List<Map<String, dynamic>>.from(course['units'] ?? []);
    if (units.isEmpty) return false;

    final currentUnitIndex = getCurrentUnitIndex(courseId);
    final currentLevelIndex = getCurrentLevelIndex(courseId);
    final currentLessonIndex = getCurrentLessonIndex(courseId);

    int newUnitIndex = currentUnitIndex;
    int newLevelIndex = currentLevelIndex;
    int newLessonIndex = currentLessonIndex + 1;

    final unit = units[currentUnitIndex];
    final levels = List<Map<String, dynamic>>.from(unit['levels'] ?? []);
    final level = levels[currentLevelIndex];
    final lessons = List<Map<String, dynamic>>.from(level['lessons'] ?? []);

    bool isRepeat = true;

    if (newLessonIndex >= lessons.length) {
      newLessonIndex = 0;
      newLevelIndex++;
      if (newLevelIndex >= levels.length) {
        newLevelIndex = 0;
        newUnitIndex++;
        if (newUnitIndex >= units.length) {
          newUnitIndex = units.length - 1;
          newLevelIndex = levels.length - 1;
          newLessonIndex = lessons.length - 1;
        } else {
          isRepeat = false; // Новий юніт
        }
      } else {
        isRepeat = false; // Новий рівень
      }
    } else {
      isRepeat = false; // Новий урок
    }

    print('[DEBUG] Saving progress: newUnitIndex = $newUnitIndex, newLevelIndex = $newLevelIndex, newLessonIndex = $newLessonIndex, isRepeat = $isRepeat');

    final updates = {
      'courses.$courseId.currentUnitIndex': newUnitIndex,
      'courses.$courseId.currentLevelIndex': newLevelIndex,
      'courses.$courseId.currentLesson': newLessonIndex,
    };

    try {
      await _db.collection('user_progress').doc(_userId).update(updates);
      print('[DEBUG] Progress saved successfully: $updates');
    } catch (e) {
      print('[DEBUG] Error saving progress: $e');
      // Якщо документ не існує, створюємо його
      await _db.collection('user_progress').doc(_userId).set(updates, SetOptions(merge: true));
    }

    progressData = {
      'currentUnitIndex': newUnitIndex,
      'currentLevelIndex': newLevelIndex,
      'currentLesson': newLessonIndex,
    };
    notifyListeners();
    return isRepeat;
  }

  bool hasNextLesson(String courseId, Map<String, dynamic> course) {
    final units = List<Map<String, dynamic>>.from(course['units'] ?? []);
    if (units.isEmpty) return false;

    final currentUnitIndex = getCurrentUnitIndex(courseId);
    final currentLevelIndex = getCurrentLevelIndex(courseId);
    final currentLessonIndex = getCurrentLessonIndex(courseId);

    final unit = units[currentUnitIndex];
    final levels = List<Map<String, dynamic>>.from(unit['levels'] ?? []);
    final level = levels[currentLevelIndex];
    final lessons = List<Map<String, dynamic>>.from(level['lessons'] ?? []);

    return currentLessonIndex < lessons.length - 1 ||
        currentLevelIndex < levels.length - 1 ||
        currentUnitIndex < units.length - 1;
  }

  Future<void> loadDailyQuests() async {
    print('[DEBUG] loadDailyQuests called: userId = $_userId');
    if (_userId.isEmpty) {
      print('[DEBUG] userId empty in loadDailyQuests — skipping');
      return;
    }

    try {
      final doc = await _db.collection('user_progress').doc(_userId).get();
      final questData = doc.data()?['dailyQuests'] as Map<String, dynamic>?;

      final now = DateTime.now();
      final today = DateTime(now.year, now.month, now.day);

      if (!doc.exists || questData == null) {
        print('[DEBUG] No document or dailyQuests field in Firestore, initializing new quests');
        await _resetDailyQuests();
        return;
      }

      final lastResetTimestamp = questData['lastReset'] as Timestamp?;
      final lastReset = lastResetTimestamp?.toDate();
      final quests = (questData['quests'] as List<dynamic>?)
          ?.map((q) => DailyQuest.fromMap(q))
          .toList() ??
          [];

      if (lastReset == null || lastReset.isBefore(today)) {
        print('[DEBUG] Last reset is null or before today, resetting quests');
        await _resetDailyQuests();
      } else {
        dailyQuests = quests;
        lastQuestReset = lastReset;
        print('[DEBUG] Loaded daily quests: $dailyQuests');
      }
      notifyListeners();
    } catch (e, stackTrace) {
      print('[DEBUG] Error loading daily quests: $e');
      print('[DEBUG] Stack trace: $stackTrace');
    }
  }

  Future<void> _resetDailyQuests() async {
    if (_userId.isEmpty) {
      print('[DEBUG] userId empty in _resetDailyQuests — skipping');
      return;
    }

    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final newQuests = _generateUniqueDailyQuests(today);

    dailyQuests = newQuests;
    lastQuestReset = now;

    try {
      await _db.collection('user_progress').doc(_userId).set({
        'dailyQuests': {
          'lastReset': Timestamp.fromDate(now),
          'quests': newQuests.map((q) => q.toMap()).toList(),
        },
      }, SetOptions(merge: true));
      print('[DEBUG] Reset daily quests: $dailyQuests');
    } catch (e, stackTrace) {
      print('[DEBUG] Error resetting daily quests: $e');
      print('[DEBUG] Stack trace: $stackTrace');
    }

    notifyListeners();
  }

  List<DailyQuest> _generateUniqueDailyQuests(DateTime today) {
    final random = Random('${_userId}_\$today_${DateTime.now().millisecondsSinceEpoch}'.hashCode);
    final availableTypes = QuestType.values.toList()..shuffle(random);
    final selectedTypes = availableTypes.take(3).toList();

    final quests = <DailyQuest>[];
    for (var i = 0; i < selectedTypes.length; i++) {
      final type = selectedTypes[i];
      int target;
      int reward;

      switch (type) {
        case QuestType.completeLessons:
          target = random.nextInt(3) + 1; // 1-3 уроки
          reward = target * 10; // 10 Gems за урок
          break;
        case QuestType.completeLevels:
          target = random.nextInt(2) + 1; // 1-2 рівні
          reward = target * 15; // 15 Gems за рівень
          break;
        case QuestType.completeTheoryLevel:
        case QuestType.completePracticeLevel:
          target = 1; // 1 рівень
          reward = 20; // 20 Gems за специфічний рівень
          break;
        case QuestType.completeSpeakingTasks:
        case QuestType.completeListeningTasks:
          target = random.nextInt(3) + 2; // 2-4 завдання
          reward = target * 5; // 5 Gems за завдання
          break;
      }

      quests.add(DailyQuest(
        id: 'quest_${_userId}_${today.toIso8601String()}_${type.toString().split('.').last}',
        type: type,
        target: target,
        reward: reward,
      ));
    }

    print('[DEBUG] Generated unique daily quests: $quests');
    return quests;
  }

  Future<void> updateQuestProgress(DailyQuest quest) async {
    final updatedQuest = quest.copyWith(
      progress: quest.progress + 1,
      isCompleted: quest.progress + 1 >= quest.target,
    );

    dailyQuests = dailyQuests
        .map((q) => q.id == quest.id ? updatedQuest : q)
        .toList();

    await _db.collection('user_progress').doc(_userId).update({
      'dailyQuests.quests': dailyQuests.map((q) => q.toMap()).toList(),
    });

    if (updatedQuest.isCompleted) {
      await UserRepository.addGems(_userId, updatedQuest.reward);
      print('[DEBUG] Quest completed: ${quest.id}, rewarded ${quest.reward} gems');
    }

    notifyListeners();
  }
}