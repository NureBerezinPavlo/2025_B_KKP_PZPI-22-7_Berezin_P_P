package com.example.nellingua

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
