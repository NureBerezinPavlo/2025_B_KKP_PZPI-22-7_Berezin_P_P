package com.example.nellingua_courses_editor

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
