import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'dart:typed_data';

class FirestoreService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  Future<void> _checkAuth() async {
    if (_auth.currentUser == null) {
      throw Exception('Користувач не авторизований');
    }
    if (_auth.currentUser!.uid != "ICbqwng5xlel7jUqH6MgtQp9N7o2") {
      throw Exception('У вас немає прав доступу');
    }
  }

  // === LEVELS ===
  Future<void> saveLevel(Map<String, dynamic> levelData) async {
    await _checkAuth();
    final docRef = _db.collection('levels').doc();
    await docRef.set(levelData);
  }

  Future<List<Map<String, dynamic>>> fetchLevels() async {
    final snapshot = await _db.collection('levels').get();
    return snapshot.docs.map((doc) => doc.data()).toList();
  }

  // === UNITS ===
  Future<void> saveUnit(Map<String, dynamic> unitData) async {
    await _checkAuth();
    final id = unitData["id"];
    await _db.collection("units").doc(id).set(unitData);
  }

  Future<List<Map<String, dynamic>>> fetchUnits() async {
    final snapshot = await _db.collection("units").get();
    return snapshot.docs.map((doc) => doc.data()).toList();
  }

  // === UNIT STRUCTURE ===
  Future<void> saveUnitStructure(Map<String, dynamic> unitStructure) async {
    await _checkAuth();
    final id = unitStructure["id"];
    await _db.collection("unit_structures").doc(id).set(unitStructure);
  }

  Future<Map<String, dynamic>?> fetchUnitStructure(String unitId) async {
    final doc = await _db.collection("unit_structures").doc(unitId).get();
    return doc.data();
  }

  // === COURSES ===
  Future<void> saveCourse(Map<String, dynamic> courseData) async {
    await _checkAuth();
    final id = courseData["id"];
    await _db.collection("courses").doc(id).set(courseData);
  }

  // === VOCABULARY ===
  Future<void> saveVocabularyItem(Map<String, dynamic> itemData) async {
    await _checkAuth();
    final id = itemData["id"];
    await _db.collection("vocabulary").doc(id).set(itemData);
  }

  Future<void> deleteVocabularyItem(String id) async {
    await _checkAuth();
    await _db.collection("vocabulary").doc(id).delete();
  }

  Future<List<Map<String, dynamic>>> fetchVocabularyForCourse(String courseId) async {
    final snapshot = await _db
        .collection("vocabulary")
        .where("course_id", isEqualTo: courseId)
        .get();

    return snapshot.docs.map((doc) => doc.data()).toList();
  }

  Future<List<Map<String, dynamic>>> fetchCourses() async {
    final snapshot = await _db.collection("courses").get();
    return snapshot.docs.map((doc) => doc.data()).toList();
  }

  Future<List<Map<String, dynamic>>> fetchUnitsByIds(List<String> ids) async {
    if (ids.isEmpty) return [];

    final snapshot = await _db
        .collection("units")
        .where(FieldPath.documentId, whereIn: ids)
        .get();

    return snapshot.docs.map((doc) => doc.data()).toList();
  }

  // Додаємо метод для завантаження зображень із Uint8List (для Web/Desctop)
  Future<String> uploadImage(Uint8List imageBytes, String path) async {
    try {
      final ref = FirebaseStorage.instance.ref().child(path);
      await ref.putData(imageBytes);
      return await ref.getDownloadURL();
    } catch (e) {
      throw Exception("Помилка завантаження зображення: $e");
    }
  }

  // === IMAGE LIBRARY ===
  Future<void> saveImageToLibrary(Map<String, dynamic> imageData) async {
    await _checkAuth();
    final id = imageData["id"];
    await _db.collection("image_library").doc(id).set(imageData);
  }

  Future<void> deleteImageFromLibrary(String id) async {
    await _checkAuth();
    await _db.collection("image_library").doc(id).delete();
  }

  Future<List<Map<String, dynamic>>> fetchImageLibrary({List<String>? tags}) async {
    Query query = _db.collection("image_library");

    if (tags != null && tags.isNotEmpty) {
      query = query.where("tags", arrayContainsAny: tags);
    }

    final snapshot = await query.get();
    return snapshot.docs.map((doc) => doc.data() as Map<String, dynamic>).toList();
  }

  Future<String> uploadImageToLibrary(Uint8List imageBytes, String fileName) async {
    await _checkAuth();
    try {
      final path = 'image_library/$fileName';
      final ref = FirebaseStorage.instance.ref().child(path);

      // Визначаємо MIME-тип
      final mimeType = _detectImageMimeType(imageBytes);

      await ref.putData(imageBytes, SettableMetadata(contentType: mimeType));
      return await ref.getDownloadURL();
    } catch (e) {
      throw Exception("Помилка завантаження зображення: $e");
    }
  }

  String _detectImageMimeType(Uint8List bytes) {
    if (bytes.length >= 3 &&
        bytes[0] == 0xFF &&
        bytes[1] == 0xD8 &&
        bytes[2] == 0xFF) {
      return 'image/jpeg';
    } else if (bytes.length >= 8 &&
        bytes[0] == 0x89 &&
        bytes[1] == 0x50 &&
        bytes[2] == 0x4E &&
        bytes[3] == 0x47 &&
        bytes[4] == 0x0D &&
        bytes[5] == 0x0A &&
        bytes[6] == 0x1A &&
        bytes[7] == 0x0A) {
      return 'image/png';
    } else if (bytes.length >= 4 &&
        bytes[0] == 0x47 &&
        bytes[1] == 0x49 &&
        bytes[2] == 0x46 &&
        bytes[3] == 0x38) {
      return 'image/gif';
    }
    return 'image/jpeg'; // fallback
  }

  Future<List<Map<String, dynamic>>> searchVocabulary(
      String courseId,
      String query
      ) async {
    final snapshot = await _db.collection("vocabulary")
        .where("course_id", isEqualTo: courseId)
        .get();

    final allItems = snapshot.docs.map((doc) => doc.data()).toList();

    return allItems.where((item) {
      return (item['word']?.toLowerCase().contains(query.toLowerCase()) ?? false) ||
          (item['short_translation']?.toLowerCase().contains(query.toLowerCase()) ?? false) ||
          (item['long_translation']?.toLowerCase().contains(query.toLowerCase()) ?? false);
    }).toList();
  }

  // === SENTENCES ===
  Future<void> saveSentence(Map<String, dynamic> sentenceData) async {
    await _checkAuth();
    final id = sentenceData["sentence_id"];
    await _db.collection("sentences").doc(id).set(sentenceData);
  }

  Future<void> deleteSentence(String id) async {
    await _checkAuth();
    await _db.collection("sentences").doc(id).delete();
  }

  Future<List<Map<String, dynamic>>> fetchSentencesForCourse(String courseId) async {
    final snapshot = await _db
        .collection("sentences")
        .where("course_id", isEqualTo: courseId)
        .get();

    return snapshot.docs.map((doc) => doc.data()).toList();
  }

  Future<String> uploadAudio(Uint8List audioBytes, String path) async {
    await _checkAuth();
    try {
      final ref = FirebaseStorage.instance.ref().child(path);
      await ref.putData(audioBytes, SettableMetadata(contentType: 'audio/mpeg'));
      return await ref.getDownloadURL();
    } catch (e) {
      throw Exception("Помилка завантаження аудіо: $e");
    }
  }
}