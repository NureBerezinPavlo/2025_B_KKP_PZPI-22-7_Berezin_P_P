import 'package:flutter/material.dart';
import 'lesson_editor_screen.dart';
import 'practice_lesson_editor.dart';
import 'revision_lesson_editor.dart';

class LevelEditorScreen extends StatefulWidget {
  final String? initialTitle;
  final List<Map<String, dynamic>>? initialLessons;
  final String? initialType;
  final String courseId;

  const LevelEditorScreen({
    super.key,
    this.initialTitle,
    this.initialLessons,
    this.initialType = 'theory', // Значение по умолчанию
    required this.courseId,
  });

  @override
  State<LevelEditorScreen> createState() => _LevelEditorScreenState();
}

class _LevelEditorScreenState extends State<LevelEditorScreen> {
  late TextEditingController _titleController;
  late String _levelType; // 'theory' | 'practice' | 'revision' | 'final'
  final List<Map<String, dynamic>> lessons = [];

  @override
  void initState() {
    super.initState();
    _levelType = widget.initialType ?? 'theory';
    _titleController = TextEditingController(text: widget.initialTitle ?? '');
    if (widget.initialLessons != null) {
      lessons.addAll(widget.initialLessons!);
    }
  }

  // Функция смены типа уровня с подтверждением
  Future<void> _changeLevelType(String newType) async {
    if (_levelType != newType && lessons.isNotEmpty) {
      final confirm = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Підтвердження'),
          content: const Text('Зміна типу рівня призведе до втрати даних. Продовжити?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Скасувати'),
            ),
            TextButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Продовжити'),
            ),
          ],
        ),
      );

      if (confirm != true) return;
    }

    setState(() {
      _levelType = newType;
      lessons.clear(); // Очищаем существующие уроки
    });
  }

  // Виджет для отображения текущего типа
  Widget _buildTypeIndicator() {
    Color color;
    String label;

    switch (_levelType) {
      case 'practice':
        color = Colors.blue;
        label = 'Практика';
        break;
      case 'revision':
        color = Colors.orange;
        label = 'Повторення';
        break;
      case 'final':
        color = Colors.purple;
        label = 'Підсумковий';
        break;
      default:
        color = Colors.green;
        label = 'Теорія';
    }

    return GestureDetector(
      onTap: () => _showTypeSelection(),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: color.withOpacity(0.2),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: color, width: 2),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.circle, color: color, size: 16),
            const SizedBox(width: 8),
            Text(label, style: TextStyle(color: color, fontWeight: FontWeight.bold)),
            const SizedBox(width: 8),
            const Icon(Icons.arrow_drop_down, size: 20),
          ],
        ),
      ),
    );
  }

  // Показ выбора типа
  void _showTypeSelection() {
    showModalBottomSheet(
      context: context,
      builder: (ctx) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          ListTile(
            leading: const Icon(Icons.book, color: Colors.green),
            title: const Text('Теорія'),
            onTap: () {
              Navigator.pop(ctx);
              _changeLevelType('theory');
            },
          ),
          ListTile(
            leading: const Icon(Icons.assignment, color: Colors.blue),
            title: const Text('Практика'),
            onTap: () {
              Navigator.pop(ctx);
              _changeLevelType('practice');
            },
          ),
          ListTile(
            leading: const Icon(Icons.repeat, color: Colors.orange),
            title: const Text('Повторення'),
            onTap: () {
              Navigator.pop(ctx);
              _changeLevelType('revision');
            },
          ),
          ListTile(
            leading: const Icon(Icons.star, color: Colors.purple),
            title: const Text('Підсумковий'),
            onTap: () {
              Navigator.pop(ctx);
              _changeLevelType('final');
            },
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _titleController.dispose();
    super.dispose();
  }

  void _addNewLesson() async {
    Widget editor;
    switch (_levelType) {
      case 'practice':
        editor = PracticeLessonEditor(courseId: widget.courseId,);
        break;
      case 'revision':
        editor = RevisionLessonEditor();
        break;
      case 'final':
      // Для итоговых уровней не добавляем уроки
        return;
      default:
        editor = const LessonEditorScreen();
    }

    final result = await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => editor),
    );

    if (result != null) {
      setState(() => lessons.add(result));
    }
  }

  void _editLesson(int index) async {
    final currentLesson = lessons[index];
    Widget editor;

    switch (_levelType) {
      case 'practice':
        editor = PracticeLessonEditor(initialData: currentLesson, courseId: widget.courseId);
        break;
      case 'revision':
        editor = RevisionLessonEditor(initialData: currentLesson);
        break;
      case 'theory':
      default:
        editor = LessonEditorScreen(
          initialTitle: currentLesson['title'],
          initialSlides: List<Map<String, dynamic>>.from(currentLesson['slides'] ?? []),
        );
    }
    final result = await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => editor),
    );

    if (result != null && result is Map<String, dynamic>) {
      setState(() => lessons[index] = result);
    }
  }

  void _removeLesson(int index) {
    setState(() => lessons.removeAt(index));
  }

  void _finishLevel() {
    final title = _titleController.text.trim();
    if (title.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Назва рівня обовʼязкова')),
      );
      return;
    }

    if (_levelType != 'final' && lessons.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Додайте хоча б один урок')),
      );
      return;
    }

    final levelData = {
      "title": title,
      "type": _levelType,
      "lessons": lessons,
    };

    Navigator.pop(context, levelData);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Редактор рівня'),
        actions: [
          TextButton(
            onPressed: _finishLevel,
            child: const Text('Готово', style: TextStyle(color: Colors.blue)),
          )
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: ListView(
          children: [
            // Индикатор типа уровня
            Row(
              children: [
                const Text('Тип рівня:', style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(width: 16),
                _buildTypeIndicator(),
              ],
            ),
            const SizedBox(height: 20),

            // Поле названия
            TextField(
              controller: _titleController,
              decoration: const InputDecoration(labelText: 'Назва рівня'),
            ),
            const SizedBox(height: 20),
            ...lessons.asMap().entries.map((entry) {
              final index = entry.key;
              final lesson = entry.value;

              String subtitle;
              if (_levelType == 'practice') {
                final groups = (lesson['task_groups'] as List?)?.length ?? 0;
                final vocab = (lesson['vocabulary'] as List?)?.length ?? 0;
                subtitle = '$groups груп, $vocab слів';
              } else if (_levelType == 'revision') {
                subtitle = '${lesson['task_count'] ?? 0} завдань';
              } else {
                subtitle = '${(lesson['slides'] as List?)?.length ?? 0} слайдів';
              }

              return ListTile(
                leading: Icon(_levelType == 'practice' ? Icons.assignment
                    : _levelType == 'revision' ? Icons.repeat
                    : Icons.book),
                title: Text(lesson['title'] ?? 'Без назви'),
                subtitle: Text(subtitle),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      icon: const Icon(Icons.edit, color: Colors.blue),
                      onPressed: () => _editLesson(index),
                    ),
                    IconButton(
                      icon: const Icon(Icons.delete, color: Colors.red),
                      onPressed: () => _removeLesson(index),
                    ),
                  ],
                ),
              );
            }),
            const SizedBox(height: 20),
            OutlinedButton.icon(
              icon: const Icon(Icons.add),
              label: const Text('Додати урок'),
              onPressed: _addNewLesson,
            )
          ],
        ),
      ),
    );
  }
}