import 'package:flutter/material.dart';
import 'vocabulary_search_dialog.dart';
import '../services/firestore_service.dart';

class PracticeLessonEditor extends StatefulWidget {
  final Map<String, dynamic>? initialData;
  final String courseId;

  const PracticeLessonEditor({Key? key, this.initialData, required this.courseId}) : super(key: key);

  @override
  State<PracticeLessonEditor> createState() => _PracticeLessonEditorState();
}

class _PracticeLessonEditorState extends State<PracticeLessonEditor> {
  final TextEditingController _titleController = TextEditingController();
  final List<String> _selectedVocabulary = [];
  final List<TaskGroup> _groups = [];
  final Map<String, String> _vocabularyWords = {};

  @override
  void initState() {
    super.initState();
    if (widget.initialData != null) {
      _titleController.text = widget.initialData!['title'] ?? '';
      _selectedVocabulary.addAll(List<String>.from(widget.initialData!['vocabulary'] ?? []));
      _groups.addAll((widget.initialData!['task_groups'] as List?)
          ?.map((e) => TaskGroup.fromMap(e)) ?? []);
    }
    _loadVocabularyWords();
  }

  // Загружаем слова для отображения
  Future<void> _loadVocabularyWords() async {
    final firestoreService = FirestoreService();
    final vocabList = await firestoreService.fetchVocabularyForCourse(widget.courseId);

    setState(() {
      for (final item in vocabList) {
        _vocabularyWords[item['id']] = item['word'] ?? item['id'];
      }
    });
  }

  void _addGroup() {
    setState(() {
      _groups.add(TaskGroup());
    });
  }

  void _removeGroup(int index) {
    setState(() {
      _groups.removeAt(index);
    });
  }


  void _selectVocabulary() async {
    final result = await showDialog<Map<String, dynamic>>(
      context: context,
      builder: (_) => VocabularySearchDialog(
        courseId: widget.courseId,
        initialQuery: '',
      ),
    );

    if (result != null && result['id'] != null && !_selectedVocabulary.contains(result['id'])) {
      setState(() {
        _selectedVocabulary.add(result['id']);
        _vocabularyWords[result['id']] = result['word'] ?? result['id'];
      });
    }
  }

  void _saveLesson() {
    if (_titleController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Введіть назву уроку')),
      );
      return;
    }

    final lessonData = {
      'title': _titleController.text,
      'vocabulary': _selectedVocabulary,
      'task_groups': _groups.map((g) => g.toMap()).toList(),
    };

    Navigator.pop(context, lessonData);
  }

  String _getTypeName(String key) {
    const map = {
      'reading_and_wordchips': 'Читання та словоблоки',
      'reading_and_keyboard_input': 'Читання та клавіатура',
      'reading_and_speaking': 'Читання та вимова',
      'listening_and_wordchips': 'Слухання та словоблоки',
      'listening_and_keyboard_input': 'Слухання та клавіатура',
      'select_1_out_of_4': 'Обери 1 з 4',
    };
    return map[key] ?? key;
  }

  /*
  * reading_and_wordchips
reading_and_keyboard_input
reading_and_speaking
listening_and_wordchips
listening_and_keyboard_input
select_1_out_of_4
  * */

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Редактор практики'),
        actions: [
          IconButton(
            icon: const Icon(Icons.save),
            onPressed: _saveLesson,
            tooltip: 'Зберегти урок',
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Expanded(
              child: ListView(
                children: [
                  TextField(
                    controller: _titleController,
                    decoration: const InputDecoration(
                      labelText: 'Назва уроку',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 16),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      'Лексика уроку',
                      style: Theme.of(context).textTheme.titleMedium,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    children: [
                      for (final id in _selectedVocabulary)
                        Chip(
                          label: Text(_vocabularyWords[id] ?? id),
                          onDeleted: () => setState(() => _selectedVocabulary.remove(id)),
                        ),
                      ActionChip(
                        label: const Text('Додати'),
                        avatar: const Icon(Icons.add),
                        onPressed: _selectVocabulary,
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  for (int i = 0; i < _groups.length; i++)
                    TaskGroupCard(
                      group: _groups[i],
                      index: i,
                      onDelete: () => _removeGroup(i),
                      onUpdate: (g) => setState(() => _groups[i] = g),
                      getTypeName: _getTypeName,
                    ),
                  const SizedBox(height: 16),
                  Center(
                    child: ElevatedButton.icon(
                      onPressed: _addGroup,
                      icon: const Icon(Icons.add),
                      label: const Text('Додати групу завдань'),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class TaskGroup {
  int exercisesCount;
  List<String> types;

  TaskGroup({this.exercisesCount = 1, List<String>? types})
      : types = types ?? ['reading_and_wordchips'];

  factory TaskGroup.fromMap(Map<String, dynamic> map) {
    return TaskGroup(
      exercisesCount: map['exercises_count'] ?? 1,
      types: List<String>.from(map['types'] ?? ['reading_and_wordchips']),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'exercises_count': exercisesCount,
      'types': types,
    };
  }
}


class TaskGroupCard extends StatelessWidget {
  final TaskGroup group;
  final int index;
  final VoidCallback onDelete;
  final ValueChanged<TaskGroup> onUpdate;
  final String Function(String) getTypeName;

  const TaskGroupCard({
    Key? key,
    required this.group,
    required this.index,
    required this.onDelete,
    required this.onUpdate,
    required this.getTypeName,
  }) : super(key: key);

  void _pickType(BuildContext context, int typeIdx) async {
    final availableTypes = {
      'reading_and_wordchips': 'Читання та словоблоки',
      'reading_and_keyboard_input': 'Читання та клавіатура',
      'reading_and_speaking': 'Читання та вимова',
      'listening_and_wordchips': 'Слухання та словоблоки',
      'listening_and_keyboard_input': 'Слухання та клавіатура',
      'select_1_out_of_4': 'Обери 1 з 4',
    };
    String? selected = group.types[typeIdx];
    final result = await showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Оберіть тип вправи'),
        content: StatefulBuilder(
          builder: (ctx, setState) {
            return DropdownButton<String>(
              isExpanded: true,
              value: selected,
              items: availableTypes.entries
                  .map((e) => DropdownMenuItem(value: e.key, child: Text(e.value)))
                  .toList(),
              onChanged: (v) => setState(() => selected = v),
            );
          },
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Скасувати')),
          TextButton(
            onPressed: () => Navigator.pop(context, selected),
            child: const Text('ОК'),
          ),
        ],
      ),
    );
    if (result != null) {
      final updated = TaskGroup(exercisesCount: group.exercisesCount, types: [...group.types]);
      updated.types[typeIdx] = result;
      onUpdate(updated);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text('Група ${index + 1}', style: Theme.of(context).textTheme.titleMedium),
                const Spacer(),
                IconButton(
                  icon: const Icon(Icons.delete),
                  onPressed: onDelete,
                ),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                const Text('Кількість'),
                const SizedBox(width: 16),
                SizedBox(
                  width: 80,
                  child: TextField(
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(border: OutlineInputBorder()),
                    controller: TextEditingController(text: group.exercisesCount.toString()),
                    onSubmitted: (val) {
                      final num = int.tryParse(val) ?? group.exercisesCount;
                      onUpdate(TaskGroup(exercisesCount: num, types: group.types));
                    },
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            const Text('Типи вправ:'),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              children: [
                for (int t = 0; t < group.types.length; t++)
                  InputChip(
                    label: Text(getTypeName(group.types[t])),
                    onPressed: () => _pickType(context, t),
                    onDeleted: () {
                      final updated = TaskGroup(exercisesCount: group.exercisesCount, types: [...group.types]);
                      updated.types.removeAt(t);
                      onUpdate(updated);
                    },
                  ),
                ActionChip(
                  label: const Text('Додати тип'),
                  avatar: const Icon(Icons.add),
                  onPressed: () {
                    final updated = TaskGroup(exercisesCount: group.exercisesCount, types: [...group.types, 'reading_and_wordchips']);
                    onUpdate(updated);
                  },
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}