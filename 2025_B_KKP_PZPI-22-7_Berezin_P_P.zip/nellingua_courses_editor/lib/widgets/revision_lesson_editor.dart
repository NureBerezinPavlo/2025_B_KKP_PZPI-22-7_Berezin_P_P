import 'package:flutter/material.dart';

class RevisionLessonEditor extends StatefulWidget {
  final Map<String, dynamic>? initialData;

  const RevisionLessonEditor({Key? key, this.initialData}) : super(key: key);

  @override
  State<RevisionLessonEditor> createState() => _RevisionLessonEditorState();
}

class _RevisionLessonEditorState extends State<RevisionLessonEditor> {
  final TextEditingController _titleController = TextEditingController();
  int _taskCount = 5;

  @override
  void initState() {
    super.initState();
    if (widget.initialData != null) {
      _titleController.text = widget.initialData!['title'] ?? '';
      _taskCount = widget.initialData!['task_count'] ?? 5;
    }
  }

  void _saveLesson() {
    if (_titleController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Введіть назву уроку')),
      );
      return;
    }

    final lessonData = {
      'title': _titleController.text,
      'task_count': _taskCount,
    };

    Navigator.pop(context, lessonData);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Редактор повторення'),
        actions: [
          IconButton(
            icon: const Icon(Icons.save),
            onPressed: _saveLesson,
            tooltip: 'Зберегти урок',
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: _titleController,
              decoration: const InputDecoration(
                labelText: 'Назва уроку',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 20),
            const Text('Кількість завдань:'),
            Slider(
              value: _taskCount.toDouble(),
              min: 3,
              max: 20,
              divisions: 17,
              label: _taskCount.toString(),
              onChanged: (v) => setState(() => _taskCount = v.round()),
            ),
          ],
        ),
      ),
    );
  }
}