import 'package:flutter/material.dart';

class SelectCardsSlideEditor extends StatefulWidget {
  final List<Map<String, dynamic>>? initialContent;

  const SelectCardsSlideEditor({super.key, this.initialContent});

  @override
  State<SelectCardsSlideEditor> createState() => _SelectCardsSlideEditorState();
}

class _SelectCardsSlideEditorState extends State<SelectCardsSlideEditor> {
  late TextEditingController _instructionController;
  List<String> _options = [];
  List<String> _correct = [];

  @override
  void initState() {
    super.initState();
    _instructionController = TextEditingController();

    if (widget.initialContent != null) {
      for (var block in widget.initialContent!) {
        if (block['type'] == 'text') {
          _instructionController.text = block['value'] ?? '';
        } else if (block['type'] == 'cards') {
          _options = List<String>.from(block['value']['options'] ?? []);
          _correct = List<String>.from(block['value']['correct'] ?? []);
        }
      }
    }
  }

  @override
  void dispose() {
    _instructionController.dispose();
    super.dispose();
  }

  void _addOption() {
    setState(() {
      _options.add('');
    });
  }

  void _updateOption(int index, String value) {
    setState(() {
      _options[index] = value;
      if (_correct.contains(_options[index]) && value.isEmpty) {
        _correct.remove(_options[index]);
      }
    });
  }

  void _removeOption(int index) {
    setState(() {
      final option = _options[index];
      _options.removeAt(index);
      _correct.remove(option);
    });
  }

  void _toggleCorrect(String option) {
    setState(() {
      if (_correct.contains(option)) {
        _correct.remove(option);
      } else {
        _correct.add(option);
      }
    });
  }

  void _saveSlide() {
    final instruction = _instructionController.text.trim();
    if (instruction.isEmpty || _options.isEmpty || _correct.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Заповніть інструкцію, додайте варіанти та виберіть правильні відповіді')),
      );
      return;
    }

    // Remove empty options
    _options.removeWhere((option) => option.isEmpty);

    final content = [
      {
        "type": "text",
        "value": instruction,
      },
      {
        "type": "cards",
        "value": {
          "options": _options,
          "correct": _correct,
        },
      },
    ];

    Navigator.pop(context, content);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Редактор слайду вибору карток'),
        actions: [
          TextButton(
            onPressed: _saveSlide,
            child: const Text('Зберегти', style: TextStyle(color: Colors.blue)),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            TextField(
              controller: _instructionController,
              decoration: const InputDecoration(
                labelText: 'Інструкція',
                border: OutlineInputBorder(),
              ),
              maxLines: 3,
            ),
            const SizedBox(height: 20),
            const Text('Варіанти:', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            ..._options.asMap().entries.map((entry) {
              final index = entry.key;
              final option = entry.value;
              return Padding(
                padding: const EdgeInsets.only(bottom: 8.0),
                child: Row(
                  children: [
                    Checkbox(
                      value: _correct.contains(option),
                      onChanged: option.isNotEmpty
                          ? (value) => _toggleCorrect(option)
                          : null,
                    ),
                    Expanded(
                      child: TextField(
                        decoration: const InputDecoration(
                          hintText: 'Введіть ієрогліф або слово',
                          border: OutlineInputBorder(),
                        ),
                        onChanged: (value) => _updateOption(index, value),
                        controller: TextEditingController(text: option),
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.delete, color: Colors.red),
                      onPressed: () => _removeOption(index),
                    ),
                  ],
                ),
              );
            }),
            const SizedBox(height: 10),
            ElevatedButton.icon(
              icon: const Icon(Icons.add),
              label: const Text('Додати варіант'),
              onPressed: _addOption,
            ),
          ],
        ),
      ),
    );
  }
}