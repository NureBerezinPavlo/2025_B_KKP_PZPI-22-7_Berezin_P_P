import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import '../services/firestore_service.dart';

class ImageLibraryScreen extends StatefulWidget {
  final bool selectMode; // Додано параметр selectMode

  const ImageLibraryScreen({super.key, this.selectMode = false});

  @override
  State<ImageLibraryScreen> createState() => _ImageLibraryScreenState();
}

class _ImageLibraryScreenState extends State<ImageLibraryScreen> {
  final FirestoreService _fs = FirestoreService();
  final TextEditingController _searchController = TextEditingController();
  final TextEditingController _tagController = TextEditingController();
  List<Map<String, dynamic>> _images = [];
  List<String> _selectedTags = [];

  @override
  void initState() {
    super.initState();
    _loadImages();
  }

  void _loadImages() async {
    final result = await _fs.fetchImageLibrary(tags: _selectedTags.isEmpty ? null : _selectedTags);
    setState(() => _images = result);
  }

  void _addNewImage() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);

    if (pickedFile != null) {
      final bytes = await pickedFile.readAsBytes();
      final fileName = 'img_${DateTime.now().millisecondsSinceEpoch}';

      try {
        final url = await _fs.uploadImageToLibrary(bytes, fileName);

        // Запит на теги
        final tags = await showDialog<List<String>>(
          context: context,
          builder: (context) => AddTagsDialog(),
        );

        if (tags != null) {
          await _fs.saveImageToLibrary({
            "id": fileName,
            "url": url,
            "tags": tags,
            "created_at": DateTime.now().toIso8601String(),
          });

          _loadImages();
        }
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Помилка завантаження: $e")),
        );
      }
    }
  }

  void _deleteImage(Map<String, dynamic> image) async {
    final id = image['id'];

    try {
      // Видаляємо з Firestore
      await _fs.deleteImageFromLibrary(id);

      // Видаляємо з Storage
      final ref = FirebaseStorage.instance.refFromURL(image['url']);
      await ref.delete();

      _loadImages();
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Помилка видалення: $e")),
      );
    }
  }

  void _toggleTag(String tag) {
    setState(() {
      if (_selectedTags.contains(tag)) {
        _selectedTags.remove(tag);
      } else {
        _selectedTags.add(tag);
      }
      _loadImages();
    });
  }

  void _selectImage(Map<String, dynamic> image) {
    if (widget.selectMode) {
      Navigator.pop(context, image);
    }
  }

  @override
  Widget build(BuildContext context) {
    // Отримуємо всі унікальні теги
    /*final allTags = _images
        .expand((img) => (img['tags'] as List<dynamic>? ?? []).cast<String>())
        .toSet()
        .toList();*/

    return Scaffold(
      appBar: AppBar(
        title: const Text('Бібліотека зображень'),
        actions: widget.selectMode ? [] : [
          IconButton(
            icon: const Icon(Icons.add),
            onPressed: _addNewImage,
            tooltip: 'Додати зображення',
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: TextField(
              controller: _searchController,
              decoration: const InputDecoration(
                labelText: 'Пошук',
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(),
              ),
              onChanged: (_) => setState(() {}), // TODO!
            ),
          ),

          // Відображення тегів для фільтрації
          /*Container(
            padding: const EdgeInsets.symmetric(horizontal: 16), // Додаємо padding через Container
            child: Wrap(
              spacing: 8,
              children: allTags.map((tag) => FilterChip(
                label: Text(tag),
                selected: _selectedTags.contains(tag),
                onSelected: (_) => _toggleTag(tag),
              )).toList(),
            ),
          ),

          const SizedBox(height: 16),*/

          Expanded(
            child: GridView.builder(
              padding: const EdgeInsets.all(16),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 4,
                crossAxisSpacing: 8,
                mainAxisSpacing: 8,
                childAspectRatio: 1,
              ),
              itemCount: _images.length,
              itemBuilder: (context, index) {
                final image = _images[index];
                return _buildImageCard(image);
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildImageCard(Map<String, dynamic> image) {
    return Stack(
      fit: StackFit.expand,
      children: [
        InkWell(
          onTap: () => _selectImage(image),
          child: Image.network(
            image['url'],
            fit: BoxFit.cover,
            errorBuilder: (context, error, stackTrace) {
              return const Center(child: Icon(Icons.broken_image));
            },
          ),
        ),
        if (!widget.selectMode)
          Positioned(
            top: 4,
            right: 4,
            child: IconButton(
              icon: const Icon(Icons.delete, color: Colors.red),
              onPressed: () => _deleteImage(image),
            ),
          ),
        Positioned(
          bottom: 0,
          left: 0,
          right: 0,
          child: Container(
            padding: const EdgeInsets.all(4),
            color: Colors.black54,
            child: Wrap(
              spacing: 4,
              children: (image['tags'] as List<dynamic>? ?? [])
                  .cast<String>()
                  .map((tag) => Chip(
                label: Text(tag, style: const TextStyle(fontSize: 10)),
                backgroundColor: Colors.blue[200],
              ))
                  .toList(),
            ),
          ),
        ),
      ],
    );
  }
}

class AddTagsDialog extends StatefulWidget {
  const AddTagsDialog({super.key});

  @override
  State<AddTagsDialog> createState() => _AddTagsDialogState();
}

class _AddTagsDialogState extends State<AddTagsDialog> {
  final TextEditingController _tagController = TextEditingController();
  final List<String> _tags = [];

  void _addTag() {
    final tag = _tagController.text.trim();
    if (tag.isNotEmpty && !_tags.contains(tag)) {
      setState(() => _tags.add(tag));
      _tagController.clear();
    }
  }

  void _removeTag(String tag) {
    setState(() => _tags.remove(tag));
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Додати теги'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          TextField(
            controller: _tagController,
            decoration: InputDecoration(
              labelText: 'Тег',
              suffixIcon: IconButton(
                icon: const Icon(Icons.add),
                onPressed: _addTag,
              ),
            ),
            onSubmitted: (_) => _addTag(),
          ),
          const SizedBox(height: 16),
          Wrap(
            spacing: 8,
            children: _tags.map((tag) => Chip(
              label: Text(tag),
              deleteIcon: const Icon(Icons.close, size: 16),
              onDeleted: () => _removeTag(tag),
            )).toList(),
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Скасувати'),
        ),
        ElevatedButton(
          onPressed: () => Navigator.pop(context, _tags),
          child: const Text('Зберегти'),
        ),
      ],
    );
  }
}