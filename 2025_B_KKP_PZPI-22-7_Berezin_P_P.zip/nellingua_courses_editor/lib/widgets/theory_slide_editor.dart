import 'package:flutter/material.dart';

class TheorySlideEditor extends StatefulWidget {
  final List<Map<String, dynamic>>? initialBlocks;

  const TheorySlideEditor({super.key, this.initialBlocks});

  @override
  State<TheorySlideEditor> createState() => _TheorySlideEditorState();
}

class _TheorySlideEditorState extends State<TheorySlideEditor> {
  final List<Map<String, dynamic>> _blocks = [];
  final List<TextEditingController> _controllers = [];
  final List<TextEditingController> _imageCaptionControllers = [
  ]; // Додано для підписів
  final List<FocusNode> _focusNodes = [];
  int? _currentFocusIndex;

  @override
  void dispose() {
    for (var controller in _controllers) {
      controller.dispose();
    }
    for (var controller in _imageCaptionControllers) {
      controller.dispose();
    }
    for (var focusNode in _focusNodes) {
      focusNode.dispose();
    }
    super.dispose();
  }

  void _addBlock(String type, {int? index}) {
    setState(() {
      final Map<String, dynamic> newBlock = switch (type) {
        'heading' => {'type': 'heading', 'value': ''},
        'text' => {'type': 'text', 'value': ''},
        'image' => {'type': 'image', 'value': {'src': '', 'caption': ''}},
        'quote' => {'type': 'quote', 'value': ''},
        'list' => {'type': 'list', 'value': ''},
        _ => throw Exception('Unknown block type'),
      };

      final controller = TextEditingController(text: '');
      final focusNode = FocusNode();
      final captionController = TextEditingController(
          text: ''); // Для підпису зображення

      if (index != null) {
        _blocks.insert(index + 1, newBlock);
        _controllers.insert(index + 1, controller);
        _focusNodes.insert(index + 1, focusNode);
        _imageCaptionControllers.insert(index + 1, captionController);
        _currentFocusIndex = index + 1;
      } else {
        _blocks.add(newBlock);
        _controllers.add(controller);
        _focusNodes.add(focusNode);
        _imageCaptionControllers.add(captionController);
        _currentFocusIndex = _blocks.length - 1;
      }

      WidgetsBinding.instance.addPostFrameCallback((_) {
        focusNode.requestFocus();
        if (controller.text.isEmpty) {
          controller.selection = TextSelection.collapsed(offset: 0);
        }
      });
    });
  }

  void _updateBlock(int index, dynamic newValue) {
    setState(() {
      _blocks[index]['value'] = newValue;
    });
  }

  void _removeBlock(int index) {
    setState(() {
      _blocks.removeAt(index);
      _controllers[index].dispose();
      _controllers.removeAt(index);
      _focusNodes[index].dispose();
      _focusNodes.removeAt(index);
      if (_currentFocusIndex != null && _currentFocusIndex! >= index) {
        _currentFocusIndex =
        _currentFocusIndex! > 0 ? _currentFocusIndex! - 1 : null;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Редактор теорії'),
        backgroundColor: Colors.white,
        elevation: 0,
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context, _blocks); // Повертаємо результат
            },
            child: const Text('Зберегти', style: TextStyle(color: Colors.blue)),
          ),
        ],
      ),
      body: Container(
        color: Colors.white,
        child: ListView.builder(
          padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 20),
          itemCount: _blocks.length + 1,
          itemBuilder: (context, index) {
            if (index == _blocks.length) {
              return _buildEmptyState();
            }

            final block = _blocks[index];
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildBlockEditor(index, block),
                const SizedBox(height: 16),
              ],
            );
          },
        ),
      ),
    );
  }

  @override
  void initState() {
    super.initState();

    // Якщо були передані блоки, додаємо їх
    if (widget.initialBlocks != null) {
      // Додайте явне приведення типів
      final initialBlocks = List<Map<String, dynamic>>.from(widget.initialBlocks!);

      for (var block in initialBlocks) {
        _blocks.add(Map<String, dynamic>.from(block));

        final type = block['type'];
        final value = block['value'];

        if (type == 'image') {
          _controllers.add(TextEditingController(text: value['src']));
          _imageCaptionControllers.add(TextEditingController(text: value['caption']));
        } else {
          _controllers.add(TextEditingController(text: value));
          _imageCaptionControllers.add(TextEditingController()); // Заповнюємо, щоб не зсувалося
        }

        _focusNodes.add(FocusNode());
      }
    }
  }

  Widget _buildBlockEditor(int index, Map<String, dynamic> block) {
    final type = block['type'];
    final controller = _controllers[index];
    final focusNode = _focusNodes[index];

    if (type == 'heading' || type == 'text' || type == 'quote' ||
        type == 'list') {
      if (controller.text != block['value']) {
        controller.text = block['value'] as String;
      }
    } else if (type == 'image') {
      final captionController = _imageCaptionControllers[index];
      if (controller.text != block['value']['src']) {
        controller.text = block['value']['src'] as String? ?? '';
      }
      if (captionController.text != block['value']['caption']) {
        captionController.text = block['value']['caption'] as String? ?? '';
      }
    }

    if (type == 'heading') {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          TextField(
            controller: controller,
            focusNode: focusNode,
            onTap: () => setState(() => _currentFocusIndex = index),
            decoration: const InputDecoration.collapsed(
              hintText: 'Заголовок',
              hintStyle: TextStyle(fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: Colors.grey),
            ),
            style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
            maxLines: null,
            onChanged: (value) => _updateBlock(index, value),
          ),
          _buildBlockControls(index),
        ],
      );
    } else if (type == 'text') {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          TextField(
            controller: controller,
            focusNode: focusNode,
            onTap: () => setState(() => _currentFocusIndex = index),
            decoration: const InputDecoration.collapsed(
              hintText: 'Текст',
              hintStyle: TextStyle(fontSize: 16, color: Colors.grey),
            ),
            style: const TextStyle(fontSize: 16),
            maxLines: null,
            onChanged: (value) => _updateBlock(index, value),
          ),
          _buildBlockControls(index),
        ],
      );
    } else if (type == 'image') {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          TextField(
            controller: controller,
            focusNode: focusNode,
            onTap: () => setState(() => _currentFocusIndex = index),
            decoration: const InputDecoration.collapsed(
              hintText: 'Вставте посилання на зображення',
              hintStyle: TextStyle(fontSize: 16, color: Colors.grey),
            ),
            style: const TextStyle(fontSize: 16),
            onChanged: (value) {
              setState(() {
                _blocks[index]['value'] = {
                  'src': value,
                  'caption': _blocks[index]['value']['caption'] ?? ''
                };
              });
            },
          ),
          if ((block['value']['src'] as String?)?.isNotEmpty ?? false)
            Column(
              children: [
                const SizedBox(height: 8),
                Image.network(
                    block['value']['src'] as String, fit: BoxFit.cover),
                TextField(
                  controller: _imageCaptionControllers[index],
                  decoration: const InputDecoration.collapsed(
                    hintText: 'Підпис до зображення',
                    hintStyle: TextStyle(fontSize: 14, color: Colors.grey),
                  ),
                  style: const TextStyle(fontSize: 14, color: Colors.grey),
                  onChanged: (value) {
                    setState(() {
                      _blocks[index]['value'] = {
                        'src': _blocks[index]['value']['src'],
                        'caption': value
                      };
                    });
                  },
                ),
              ],
            ),
          _buildBlockControls(index),
        ],
      );
    } else if (type == 'quote') {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            decoration: BoxDecoration(
              border: Border(
                  left: BorderSide(color: Colors.grey.shade300, width: 4)),
            ),
            child: TextField(
              controller: controller,
              focusNode: focusNode,
              onTap: () => setState(() => _currentFocusIndex = index),
              decoration: const InputDecoration.collapsed(
                hintText: 'Цитата',
                hintStyle: TextStyle(fontSize: 16,
                    color: Colors.grey,
                    fontStyle: FontStyle.italic),
              ),
              style: const TextStyle(fontSize: 16, fontStyle: FontStyle.italic),
              maxLines: null,
              onChanged: (value) => _updateBlock(index, value),
            ),
          ),
          _buildBlockControls(index),
        ],
      );
    } else if (type == 'list') {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          TextField(
            controller: controller,
            focusNode: focusNode,
            onTap: () => setState(() => _currentFocusIndex = index),
            decoration: const InputDecoration.collapsed(
              hintText: 'Список (кожен елемент з нового рядка)',
              hintStyle: TextStyle(fontSize: 16, color: Colors.grey),
            ),
            style: const TextStyle(fontSize: 16),
            maxLines: null,
            onChanged: (value) => _updateBlock(index, value),
          ),
          _buildBlockControls(index),
        ],
      );
    }

    return const SizedBox.shrink();
  }

  Widget _buildBlockControls(int index) {
    return Row(
      children: [
        IconButton(
          icon: const Icon(Icons.add, size: 20),
          onPressed: () => _showBlockTypeMenu(index),
        ),
        IconButton(
          icon: const Icon(Icons.close, size: 20),
          onPressed: () => _removeBlock(index),
        ),
      ],
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Text('Починайте писати або додайте блок',
              style: TextStyle(color: Colors.grey)),
          const SizedBox(height: 16),
          Wrap(
            spacing: 8,
            children: [
              _buildBlockTypeButton('heading', 'Заголовок'),
              _buildBlockTypeButton('text', 'Текст'),
              _buildBlockTypeButton('image', 'Зображення'),
              _buildBlockTypeButton('quote', 'Цитата'),
              _buildBlockTypeButton('list', 'Список'),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildBlockTypeButton(String type, String label) {
    return OutlinedButton(
      onPressed: () => _addBlock(type),
      child: Text(label),
    );
  }

  void _showBlockTypeMenu(int index) {
    showModalBottomSheet(
      context: context,
      builder: (context) {
        return SafeArea(
          child: Wrap(
            children: [
              ListTile(
                leading: const Icon(Icons.title),
                title: const Text('Заголовок'),
                onTap: () {
                  Navigator.pop(context);
                  _addBlock('heading', index: index);
                },
              ),
              ListTile(
                leading: const Icon(Icons.text_fields),
                title: const Text('Текст'),
                onTap: () {
                  Navigator.pop(context);
                  _addBlock('text', index: index);
                },
              ),
              ListTile(
                leading: const Icon(Icons.image),
                title: const Text('Зображення'),
                onTap: () {
                  Navigator.pop(context);
                  _addBlock('image', index: index);
                },
              ),
              ListTile(
                leading: const Icon(Icons.format_quote),
                title: const Text('Цитата'),
                onTap: () {
                  Navigator.pop(context);
                  _addBlock('quote', index: index);
                },
              ),
              ListTile(
                leading: const Icon(Icons.list),
                title: const Text('Список'),
                onTap: () {
                  Navigator.pop(context);
                  _addBlock('list', index: index);
                },
              ),
            ],
          ),
        );
      },
    );
  }
}