import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:nellingua_courses_editor/widgets/sentence_list_screen.dart';
import 'course_editor_screen.dart';
import 'vocabulary_editor_screen.dart';
import 'image_library_screen.dart';
import '../services/firestore_service.dart';

class CoursesDashboardScreen extends StatefulWidget {
  const CoursesDashboardScreen({super.key});

  @override
  State<CoursesDashboardScreen> createState() => _CoursesDashboardScreenState();
}

class _CoursesDashboardScreenState extends State<CoursesDashboardScreen> {
  final List<Map<String, dynamic>> _courses = [];

  @override
  void initState() {
    super.initState();
    _loadCoursesFromCloud();
  }

  void _loadCoursesFromCloud() async {
    final result = await FirestoreService().fetchCourses();
    setState(() {
      _courses.clear();
      _courses.addAll(result);
    });
  }

  void _addCourse() async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const CourseEditorScreen()),
    );

    if (result != null && result is Map<String, dynamic>) {
      setState(() => _courses.add(result));
    }
  }

  void _editCourse(int index) async {
    final current = _courses[index];

    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => CourseEditorScreen(initialData: current),
      ),
    );

    if (result != null && result is Map<String, dynamic>) {
      setState(() => _courses[index] = result);
    }
  }

  void _openVocabularyEditor(String courseId) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => VocabularyEditorScreen(courseId: courseId),
      ),
    );
  }

  void _openSentenceEditor(String courseId) {
    final course = _courses.firstWhere((c) => c['id'] == courseId);
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => SentenceListScreen(
          courseId: courseId,
          baseLanguage: course['base_language'],
          targetLanguage: course['target_language'],
        ),
      ),
    );
  }

  void _openImageLibrary() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const ImageLibraryScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Курси"),
        actions: [
          IconButton(
            icon: const Icon(Icons.photo_library),
            tooltip: "Бібліотека зображень",
            onPressed: _openImageLibrary,
          ),
          IconButton(
            icon: const Icon(Icons.add),
            tooltip: "Новий курс",
            onPressed: _addCourse,
          ),
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () async {
              await FirebaseAuth.instance.signOut();
            },
          ),
        ],
      ),
      body: _courses.isEmpty
          ? const Center(child: Text("Немає створених курсів"))
          : Padding(
        padding: const EdgeInsets.all(12),
        child: GridView.builder(
          itemCount: _courses.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 5, // 5 колонок
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            childAspectRatio: 1.2,
          ),
          itemBuilder: (context, index) {
            final course = _courses[index];
            return GestureDetector(
              onTap: () => _editCourse(index),
              child: Card(
                elevation: 3,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(course['name'] ?? "Без назви",
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          )),
                      const SizedBox(height: 8),
                      Text("ID: ${course['id']}", style: const TextStyle(fontSize: 12)),
                      const Spacer(),
                      Text(
                        "Мови: ${course['base_language'] ?? '-'} → ${course['target_language'] ?? '-'}",
                        style: const TextStyle(fontSize: 12, color: Colors.grey),
                      ),
                      const SizedBox(height: 8),
                      ElevatedButton(
                        onPressed: () => _openVocabularyEditor(course['id']),
                        child: const Text("Редагувати вокабуляр"),
                        style: ElevatedButton.styleFrom(
                          minimumSize: const Size(double.infinity, 30),
                          padding: const EdgeInsets.symmetric(vertical: 4),
                        ),
                      ),
                      const SizedBox(height: 4),
                      ElevatedButton(
                        onPressed: () => _openSentenceEditor(course['id']),
                        child: const Text("Редагувати речення"),
                        style: ElevatedButton.styleFrom(
                          minimumSize: const Size(double.infinity, 30),
                          padding: const EdgeInsets.symmetric(vertical: 4),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}