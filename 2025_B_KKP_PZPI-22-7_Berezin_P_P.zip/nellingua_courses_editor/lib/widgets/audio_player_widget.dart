import 'package:flutter/material.dart';

class AudioPlayerWidget extends StatelessWidget {
  final String? audioUrl;
  final Future<void> Function(double)? onPlay;
  final Future<void> Function()? onStop;

  const AudioPlayerWidget({
    super.key,
    required this.audioUrl,
    required this.onPlay,
    required this.onStop,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        IconButton(
          icon: const Icon(Icons.play_arrow),
          onPressed: audioUrl == null || onPlay == null
              ? null
              : () => onPlay!(1.0),
          tooltip: 'Відтворити',
        ),
        IconButton(
          icon: const Icon(Icons.stop),
          onPressed: onStop,
          tooltip: 'Зупинити',
        ),
      ],
    );
  }
}