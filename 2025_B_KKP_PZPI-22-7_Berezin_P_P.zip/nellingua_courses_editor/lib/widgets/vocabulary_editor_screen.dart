import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import '../services/firestore_service.dart';
import 'image_library_screen.dart';

class VocabularyEditorScreen extends StatefulWidget {
  final String courseId;

  const VocabularyEditorScreen({super.key, required this.courseId});

  @override
  State<VocabularyEditorScreen> createState() => _VocabularyEditorScreenState();
}

class _VocabularyEditorScreenState extends State<VocabularyEditorScreen> {
  final FirestoreService _fs = FirestoreService();
  final TextEditingController _searchController = TextEditingController();
  List<Map<String, dynamic>> _vocabulary = [];
  List<Map<String, dynamic>> _filteredVocabulary = [];

  @override
  void initState() {
    super.initState();
    _loadVocabulary();
  }

  void _loadVocabulary() async {
    final result = await _fs.fetchVocabularyForCourse(widget.courseId);
    setState(() {
      _vocabulary = result;
      _filteredVocabulary = result;
    });
  }

  void _addNewItem() {
    showDialog(
      context: context,
      builder: (context) => VocabularyItemEditor(
        courseId: widget.courseId,
        onSave: (newItem) {
          setState(() {
            _vocabulary.add(newItem);
            _updateFilteredList();
          });
        },
      ),
    );
  }

  void _editItem(Map<String, dynamic> item) {
    final index = _vocabulary.indexWhere((v) => v['id'] == item['id']);
    if (index == -1) return;

    showDialog(
      context: context,
      builder: (context) => VocabularyItemEditor(
        courseId: widget.courseId,
        initialData: _vocabulary[index],
        onSave: (updatedItem) {
          setState(() {
            _vocabulary[index] = updatedItem;
            _updateFilteredList();
          });
        },
      ),
    );
  }

  void _deleteItem(Map<String, dynamic> item) async {
    final index = _vocabulary.indexWhere((v) => v['id'] == item['id']);
    if (index == -1) return;

    final id = item['id'];

    // Видаляємо з Firestore
    await _fs.deleteVocabularyItem(id);

    setState(() {
      _vocabulary.removeAt(index);
      _updateFilteredList();
    });
  }

  void _updateFilteredList() {
    final query = _searchController.text.toLowerCase();
    if (query.isEmpty) {
      _filteredVocabulary = _vocabulary;
    } else {
      _filteredVocabulary = _vocabulary.where((item) {
        return (item['word']?.toLowerCase().contains(query) ?? false) ||
            (item['short_translation']?.toLowerCase().contains(query) ?? false) ||
            (item['long_translation']?.toLowerCase().contains(query) ?? false);
      }).toList();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Редактор вокабуляра'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _loadVocabulary,
            tooltip: 'Оновити список',
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: TextField(
              controller: _searchController,
              decoration: const InputDecoration(
                labelText: 'Пошук',
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(),
                filled: true,
                fillColor: Colors.white,
              ),
              onChanged: (_) => setState(_updateFilteredList),
            ),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: GridView.builder(
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 5, // п'ять колонок
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 10,
                  childAspectRatio: 0.8, // Співвідношення висоти до ширини
                ),
                itemCount: _filteredVocabulary.length,
                itemBuilder: (context, index) {
                  final item = _filteredVocabulary[index];
                  return _buildVocabularyCard(item);
                },
              ),
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _addNewItem,
        child: const Icon(Icons.add),
        tooltip: 'Додати нову лексичну одиницю',
      ),
    );
  }

  Widget _buildVocabularyCard(Map<String, dynamic> item) {
    return Card(
      elevation: 3,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: InkWell(
        onTap: () => _editItem(item),
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(12.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Зображення
              Expanded(
                child: Container(
                  width: double.infinity,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    color: Colors.grey[200],
                  ),
                  child: item['image'] != null
                      ? ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: Image.network(
                      item['image'],
                      headers: const {"Accept": "image/*"},
                      fit: BoxFit.cover,
                      errorBuilder: (context, error, stackTrace) {
                        return const Center(
                          child: Icon(Icons.broken_image, size: 40),
                        );
                      },
                    ),
                  )
                      : const Center(
                    child: Icon(Icons.image, size: 40, color: Colors.grey),
                  ),
                ),
              ),
              const SizedBox(height: 10),
              // Слово
              Text(
                item['word'] ?? 'Без назви',
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              // Короткий переклад
              Text(
                item['short_translation'] ?? '',
                style: TextStyle(
                  color: Colors.grey[700],
                  fontSize: 14,
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              // Кнопки дій
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  IconButton(
                    icon: const Icon(Icons.edit, size: 20),
                    onPressed: () => _editItem(item),
                    tooltip: 'Редагувати',
                  ),
                  IconButton(
                    icon: const Icon(Icons.delete, size: 20, color: Colors.red),
                    onPressed: () => _deleteItem(item),
                    tooltip: 'Видалити',
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class VocabularyItemEditor extends StatefulWidget {
  final String courseId;
  final Map<String, dynamic>? initialData;
  final Function(Map<String, dynamic>) onSave;

  const VocabularyItemEditor({
    super.key,
    required this.courseId,
    this.initialData,
    required this.onSave,
  });

  @override
  State<VocabularyItemEditor> createState() => _VocabularyItemEditorState();
}

class _VocabularyItemEditorState extends State<VocabularyItemEditor> {
  final TextEditingController _idController = TextEditingController();
  final TextEditingController _wordController = TextEditingController();
  final TextEditingController _longTranslationController = TextEditingController();
  final TextEditingController _shortTranslationController = TextEditingController();
  String? _imageUrl;
  String? _imageId;

  @override
  void initState() {
    super.initState();
    if (widget.initialData != null) {
      _idController.text = widget.initialData!['id'] ?? '';
      _wordController.text = widget.initialData!['word'] ?? '';
      _longTranslationController.text = widget.initialData!['long_translation'] ?? '';
      _shortTranslationController.text = widget.initialData!['short_translation'] ?? '';
      _imageUrl = widget.initialData!['image'];
      _imageId = widget.initialData!['image_id'];
    } else {
      _idController.text = 'vocab_${DateTime.now().millisecondsSinceEpoch}';
    }
  }

  Future<void> _selectImageFromLibrary() async {
    final selectedImage = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => const ImageLibraryScreen(selectMode: true),
      ),
    );

    if (selectedImage != null && selectedImage is Map<String, dynamic>) {
      setState(() {
        _imageId = selectedImage['id'];
        _imageUrl = selectedImage['url'];
      });
    }
  }

  void _saveItem() async {
    final item = {
      "id": _idController.text,
      "course_id": widget.courseId,
      "word": _wordController.text,
      "long_translation": _longTranslationController.text,
      "short_translation": _shortTranslationController.text,
      "image": _imageUrl,
      "image_id": _imageId,
    };

    try {
      await FirestoreService().saveVocabularyItem(item);
      widget.onSave(item);
      if (mounted) Navigator.pop(context);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Помилка збереження: $e")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.initialData == null ? 'Нова картка' : 'Редагувати картку'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: _idController,
              decoration: const InputDecoration(labelText: "ID"),
              readOnly: true,
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _wordController,
              decoration: const InputDecoration(labelText: "Слово"),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _longTranslationController,
              decoration: const InputDecoration(labelText: "Довгий переклад"),
              maxLines: 2,
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _shortTranslationController,
              decoration: const InputDecoration(labelText: "Короткий переклад"),
            ),
            const SizedBox(height: 20),

            // Відображення зображення
            if (_imageUrl != null)
              Image.network(_imageUrl!, height: 100),

            const SizedBox(height: 10),
            ElevatedButton(
              onPressed: _selectImageFromLibrary,
              child: const Text('Вибрати зображення з бібліотеки'),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Скасувати'),
        ),
        ElevatedButton(
          onPressed: _saveItem,
          child: const Text('Зберегти'),
        ),
      ],
    );
  }
}