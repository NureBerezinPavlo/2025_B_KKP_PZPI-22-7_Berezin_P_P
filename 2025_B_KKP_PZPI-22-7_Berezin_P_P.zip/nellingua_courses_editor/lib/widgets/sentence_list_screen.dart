import 'package:flutter/material.dart';
import 'package:nellingua_courses_editor/widgets/word_highlight_editor_screen.dart';
import '../services/firestore_service.dart';
import 'sentence_editor_screen.dart';

class SentenceListScreen extends StatefulWidget {
  final String courseId;
  final String baseLanguage;
  final String targetLanguage;

  const SentenceListScreen({
    super.key,
    required this.courseId,
    required this.baseLanguage,
    required this.targetLanguage,
  });

  @override
  State<SentenceListScreen> createState() => _SentenceListScreenState();
}

class _SentenceListScreenState extends State<SentenceListScreen> {
  final FirestoreService _fs = FirestoreService();
  final TextEditingController _searchController = TextEditingController();
  List<Map<String, dynamic>> _sentences = [];
  List<Map<String, dynamic>> _filteredSentences = [];

  @override
  void initState() {
    super.initState();
    _loadSentences();
  }

  void _loadSentences() async {
    final result = await _fs.fetchSentencesForCourse(widget.courseId);
    setState(() {
      _sentences = result;
      _filteredSentences = result;
    });
  }

  void _addNewSentence() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => SentenceEditorScreen(
          courseId: widget.courseId,
          baseLanguage: widget.baseLanguage,
          targetLanguage: widget.targetLanguage,
          onSave: (newSentence) {
            setState(() {
              _sentences.add(newSentence);
              _updateFilteredList();
            });
          },
        ),
      ),
    );
  }

  void _editSentence(Map<String, dynamic> sentence) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => SentenceEditorScreen(
          courseId: widget.courseId,
          baseLanguage: widget.baseLanguage,
          targetLanguage: widget.targetLanguage,
          initialData: sentence,
          onSave: (updatedSentence) {
            setState(() {
              final index = _sentences.indexWhere(
                      (s) => s['sentence_id'] == updatedSentence['sentence_id']
              );
              if (index != -1) {
                _sentences[index] = updatedSentence;
              }
              _updateFilteredList();
            });
          },
        ),
      ),
    );
  }

  void _deleteSentence(Map<String, dynamic> sentence) async {
    final index = _sentences.indexWhere((s) => s['sentence_id'] == sentence['sentence_id']);
    if (index == -1) return;

    final id = sentence['sentence_id'];

    // Видаляємо з Firestore
    await _fs.deleteSentence(id);

    setState(() {
      _sentences.removeAt(index);
      _updateFilteredList();
    });
  }

  void _updateFilteredList() {
    final query = _searchController.text.toLowerCase();
    if (query.isEmpty) {
      _filteredSentences = _sentences;
    } else {
      _filteredSentences = _sentences.where((sentence) {
        return (sentence['sentence_id']?.toLowerCase().contains(query) ?? false) ||
            (sentence['foreign']?['default_options']?[0]?['sentence']?.toLowerCase().contains(query) ?? false);
      }).toList();
    }
  }

  void _openWordTipsEditor(Map<String, dynamic> sentence) async {
    final foreignSentence = sentence['foreign']['default_options'][0]['sentence'] ?? '';
    final highlights = sentence['foreign']['default_options'][0]['highlighted_words'] ?? [];

    final updatedHighlights = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => WordHighlightEditorScreen(
          sentence: foreignSentence,
          courseId: widget.courseId,
          language: widget.targetLanguage, // Используем targetLanguage из виджета
          initialHighlights: highlights,
          onSave: (newHighlights) => newHighlights,
        ),
      ),
    );

    if (updatedHighlights != null) {
      // Обновляем данные в Firestore
      sentence['foreign']['default_options'][0]['highlighted_words'] = updatedHighlights;
      await _fs.saveSentence(sentence);

      // Обновляем UI
      setState(() {
        final index = _sentences.indexWhere(
                (s) => s['sentence_id'] == sentence['sentence_id']
        );
        if (index != -1) {
          _sentences[index] = sentence;
          _updateFilteredList();
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Редактор речень'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _loadSentences,
            tooltip: 'Оновити список',
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: TextField(
              controller: _searchController,
              decoration: const InputDecoration(
                labelText: 'Пошук',
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(),
                filled: true,
                fillColor: Colors.white,
              ),
              onChanged: (_) => setState(_updateFilteredList),
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: _filteredSentences.length,
              itemBuilder: (context, index) {
                final sentence = _filteredSentences[index];
                final foreignText = sentence['foreign']?['default_options']?[0]?['sentence'] ?? 'Без тексту';
                return Card(
                  margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: ListTile(
                    title: Text(sentence['sentence_id'] ?? 'Без ID'),
                    subtitle: Text(foreignText, maxLines: 2, overflow: TextOverflow.ellipsis),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon: const Icon(Icons.edit),
                          onPressed: () => _editSentence(sentence),
                          tooltip: 'Редагувати',
                        ),
                        IconButton(
                          icon: const Icon(Icons.delete, color: Colors.red),
                          onPressed: () => _deleteSentence(sentence),
                          tooltip: 'Видалити',
                        ),
                      ],
                    ),
                    onTap: () => _editSentence(sentence),
                  ),
                );
              },
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _addNewSentence,
        child: const Icon(Icons.add),
        tooltip: 'Додати нове речення',
      ),
    );
  }
}