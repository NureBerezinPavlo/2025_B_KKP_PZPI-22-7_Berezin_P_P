import 'package:flutter/material.dart';
import 'package:nellingua_courses_editor/widgets/vocabulary_editor_screen.dart';
import 'unit_editor_screen.dart';
import '../services/firestore_service.dart';
import 'sentence_list_screen.dart';

class CourseEditorScreen extends StatefulWidget {
  const CourseEditorScreen({super.key, this.initialData});
  final Map<String, dynamic>? initialData;

  @override
  State<CourseEditorScreen> createState() => _CourseEditorScreenState();
}

class _CourseEditorScreenState extends State<CourseEditorScreen> {
  final TextEditingController _idController = TextEditingController();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _descController = TextEditingController();

  final List<Map<String, dynamic>> _units = [];

  String? _baseLang;
  String? _targetLang;
  String? courseId;

  final List<String> _availableLanguages = ['uk', 'zh', 'en', 'pl', 'es', 'de'];

  List<String> get _baseLangOptions =>
      _availableLanguages.where((lang) => lang != _targetLang).toList();

  List<String> get _targetLangOptions =>
      _availableLanguages.where((lang) => lang != _baseLang).toList();

  @override
  void initState() {
    super.initState();

    if (widget.initialData != null) {
      final data = widget.initialData!;
      courseId = data["id"] ?? '';
      _idController.text = courseId ?? '';
      _nameController.text = data["name"] ?? '';
      _descController.text = data["description"] ?? '';
      _baseLang = data["base_language"];
      _targetLang = data["target_language"];

      _units.clear();

      final unitObjects = data["unit_objects"];
      final unitIds = List<String>.from(data["units"] ?? []);

      if (unitObjects != null) {
        _units.addAll(List<Map<String, dynamic>>.from(unitObjects));
      } else if (unitIds.isNotEmpty) {
        FirestoreService()
            .fetchUnitsByIds(unitIds)
            .then((fetchedUnits) => setState(() => _units.addAll(fetchedUnits)));
      }
    }
  }

  void _addNewUnit() async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => UnitEditorScreen(courseId: courseId?? '')),
    );

    if (result != null && result is Map<String, dynamic>) {
      setState(() {
        _units.add(result);
      });
    }
  }

  void _editUnit(int index) async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => UnitEditorScreen(initialData: _units[index], courseId: courseId ?? ''),
      ),
    );

    if (result != null && result is Map<String, dynamic>) {
      setState(() {
        _units[index] = result;
      });
    }
  }

  void _removeUnit(int index) {
    setState(() {
      _units.removeAt(index);
    });
  }

  void _exportCourseJson() async {
    final id = _idController.text.trim();
    final name = _nameController.text.trim();
    final desc = _descController.text.trim();

    if (id.isEmpty || name.isEmpty || _baseLang == null || _targetLang == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Будь ласка, заповніть всі поля та виберіть мови')),
      );
      return;
    }

    final courseData = {
      "id": id,
      "name": name,
      "description": desc,
      "base_language": _baseLang,
      "target_language": _targetLang,
      "units": _units.map((u) => u["id"]).toList(),
      "unit_objects": _units,
    };

    try {
      final fs = FirestoreService();

      // зберігаємо курс
      await fs.saveCourse(courseData);

      // зберігаємо кожен юніт окремо
      for (final unit in _units) {
        await fs.saveUnit(unit);
      }

      Navigator.pop(context, courseData);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Помилка при збереженні: $e")),
      );
    }
  }

  void _openVocabularyEditor() {
    if (_idController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Будь ласка, спочатку введіть ID курсу')),
      );
      return;
    }

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => VocabularyEditorScreen(courseId: _idController.text),
      ),
    );
  }

  void _openSentenceEditor() {
    if (_idController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Будь ласка, спочатку введіть ID курсу')),
      );
      return;
    }

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => SentenceListScreen(
          courseId: _idController.text,
          baseLanguage: _baseLang!,
          targetLanguage: _targetLang!,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Редактор курсу'),
        actions: [
          IconButton(
            icon: const Icon(Icons.download),
            onPressed: _exportCourseJson,
          ),
          // Редактор вокабуляра
          IconButton(
            icon: const Icon(Icons.library_books),
            tooltip: 'Редактор вокабуляра',
            onPressed: _openVocabularyEditor,
          ),
          // Редактор речень
          IconButton(
            icon: const Icon(Icons.format_quote),
            tooltip: 'Редактор речень',
            onPressed: _openSentenceEditor,
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: ListView(
          children: [
            TextField(
              controller: _idController,
              decoration: const InputDecoration(labelText: "ID курсу (у форматі course_uk_zh)"),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _nameController,
              decoration: const InputDecoration(labelText: "Назва курсу"),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _descController,
              decoration: const InputDecoration(labelText: "Опис курсу"),
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: DropdownButtonFormField<String>(
                    decoration: const InputDecoration(labelText: "Базова мова"),
                    value: _baseLang,
                    items: _baseLangOptions
                        .map((lang) =>
                        DropdownMenuItem(value: lang, child: Text(lang)))
                        .toList(),
                    onChanged: (val) => setState(() => _baseLang = val),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: DropdownButtonFormField<String>(
                    decoration: const InputDecoration(labelText: "Цільова мова"),
                    value: _targetLang,
                    items: _targetLangOptions
                        .map((lang) =>
                        DropdownMenuItem(value: lang, child: Text(lang)))
                        .toList(),
                    onChanged: (val) => setState(() => _targetLang = val),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
            const Divider(),
            const Text("Юніти:", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            ..._units.asMap().entries.map((entry) {
              final index = entry.key;
              final unit = entry.value;
              return ListTile(
                leading: const Icon(Icons.map),
                title: Text(unit['name'] ?? "Без назви"),
                subtitle: Text("ID: ${unit['id']}"),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      icon: const Icon(Icons.edit, color: Colors.blue),
                      onPressed: () => _editUnit(index),
                    ),
                    IconButton(
                      icon: const Icon(Icons.delete, color: Colors.red),
                      onPressed: () => _removeUnit(index),
                    ),
                  ],
                ),
              );
            }),
            const SizedBox(height: 10),
            OutlinedButton.icon(
              icon: const Icon(Icons.add),
              label: const Text("Додати юніт"),
              onPressed: _addNewUnit,
            )
          ],
        ),
      ),
    );
  }
}