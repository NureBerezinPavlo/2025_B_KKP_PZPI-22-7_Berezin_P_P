import 'package:file_picker/file_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:audioplayers/audioplayers.dart';
import 'audio_player_widget.dart';

class AudioRecordEditor extends StatefulWidget {
  final Map<String, dynamic> audioRecord;
  final String sentenceId;
  final int optionIndex;
  final int recordIndex;
  final Function(Map<String, dynamic>) onUpdate;
  final Function() onDelete;

  const AudioRecordEditor({
    super.key,
    required this.audioRecord,
    required this.sentenceId,
    required this.optionIndex,
    required this.recordIndex,
    required this.onUpdate,
    required this.onDelete,
  });

  @override
  State<AudioRecordEditor> createState() => _AudioRecordEditorState();
}

class _AudioRecordEditorState extends State<AudioRecordEditor> {
  final AudioPlayer _audioPlayer = AudioPlayer();
  final TextEditingController _authorController = TextEditingController();
  bool _isUploading = false;
  double _playbackSpeed = 1.0;

  @override
  void initState() {
    super.initState();
    _authorController.text = widget.audioRecord['author'] ?? '';
  }

  @override
  void dispose() {
    _audioPlayer.dispose();
    _authorController.dispose();
    super.dispose();
  }

  Future<void> _uploadAudioFile(String speedKey) async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.audio,
      allowMultiple: false,
      withData: true, // важно: чтобы bytes были доступны
    );

    if (result == null || result.files.isEmpty) return;

    setState(() => _isUploading = true);
    try {
      final pickedFile = result.files.single;
      final fileBytes = pickedFile.bytes;
      if (fileBytes == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Не вдалося прочитати файл')),
        );
        return;
      }

      final fileName =
          '${widget.sentenceId}_${widget.optionIndex}_${speedKey}_${_authorController.text.replaceAll(' ', '_')}.mp3';

      final storageRef = FirebaseStorage.instance.ref().child('audio/$fileName');

      final uploadTask = storageRef.putData(
        fileBytes,
        SettableMetadata(contentType: 'audio/mpeg'),
      );

      final snapshot = await uploadTask;
      final downloadUrl = await snapshot.ref.getDownloadURL();

      setState(() {
        widget.audioRecord[speedKey] = downloadUrl;
        widget.onUpdate(widget.audioRecord);
      });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Помилка завантаження аудіо: $e')),
      );
    } finally {
      setState(() => _isUploading = false);
    }
  }

  void _removeAudio(String speedKey) {
    setState(() {
      widget.audioRecord[speedKey] = null;
      widget.onUpdate(widget.audioRecord);
    });
  }

  Future<void> _playAudio(String speedKey) async {
    final url = widget.audioRecord[speedKey];
    if (url == null || url.isEmpty) return;

    try {
      await _audioPlayer.stop();
      await _audioPlayer.setPlaybackRate(1.0); // всегда нормальная скорость
      await _audioPlayer.play(UrlSource(url));
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Помилка відтворення: $e')),
      );
    }
  }

  Future<void> _stopAudio() async {
    await _audioPlayer.stop();
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: _authorController,
              decoration: const InputDecoration(
                labelText: "Ім'я диктора",
                border: OutlineInputBorder(),
              ),
              onChanged: (value) {
                widget.audioRecord['author'] = value;
                widget.onUpdate(widget.audioRecord);
              },
            ),
            const SizedBox(height: 20),
            _buildAudioControl("Звичайна швидкість", "normal"),
            _buildAudioControl("Трохи повільніше", "a_little_bit_more_slowly"),
            _buildAudioControl("Повільніше", "more_slowly"),
            _buildAudioControl("Набагато повільніше", "much_more_slowly"),
            _buildAudioControl("Дуже повільно", "super_slowly"),
            const SizedBox(height: 10),
            if (_isUploading) const LinearProgressIndicator(),
            const SizedBox(height: 10),
            Align(
              alignment: Alignment.centerRight,
              child: IconButton(
                icon: const Icon(Icons.delete, color: Colors.red),
                onPressed: widget.onDelete,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAudioControl(String label, String speedKey) {
    final audioUrl = widget.audioRecord[speedKey];
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(fontWeight: FontWeight.w500)),
          const SizedBox(height: 5),
          Row(
            children: [
              Expanded(
                child: Text(
                    audioUrl != null ? "Аудіо завантажено" : "Аудіо відсутнє",
                    style: TextStyle(
                        color: audioUrl != null ? Colors.green : Colors.grey)),
              ),
              IconButton(
                icon: const Icon(Icons.upload),
                onPressed: () => _uploadAudioFile(speedKey),
                tooltip: 'Завантажити аудіо',
              ),
              if (audioUrl != null) ...[
                IconButton(
                  icon: const Icon(Icons.delete),
                  onPressed: () => _removeAudio(speedKey),
                  color: Colors.red,
                  tooltip: 'Видалити аудіо',
                ),
                AudioPlayerWidget(
                  audioUrl: audioUrl,
                  onPlay: (_) => _playAudio(speedKey),
                  onStop: _stopAudio,
                ),
              ],
            ],
          ),
        ],
      ),
    );
  }
}