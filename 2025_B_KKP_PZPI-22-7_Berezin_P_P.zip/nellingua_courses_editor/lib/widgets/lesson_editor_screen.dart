import 'package:flutter/material.dart';
import 'theory_slide_editor.dart';
import 'stroke_practice_slide_editor.dart';
import 'select_cards_slide_editor.dart';
import 'matching_pairs_slide_editor.dart';

class LessonEditorScreen extends StatefulWidget {
  final String? initialTitle;
  final List<Map<String, dynamic>>? initialSlides;

  const LessonEditorScreen({
    super.key,
    this.initialTitle,
    this.initialSlides,
  });

  @override
  State<LessonEditorScreen> createState() => _LessonEditorScreenState();
}

class _LessonEditorScreenState extends State<LessonEditorScreen> {
  late TextEditingController _titleController;
  final List<Map<String, dynamic>> slides = [];
  String _selectedSlideType = 'theory'; // Default slide type

  @override
  void initState() {
    super.initState();
    _titleController = TextEditingController(text: widget.initialTitle ?? '');
    if (widget.initialSlides != null) {
      slides.addAll(widget.initialSlides!);
    }
  }

  @override
  void dispose() {
    _titleController.dispose();
    super.dispose();
  }

  void _addNewSlide() async {
    Widget editor;
    if (_selectedSlideType == 'stroke_practice') {
      editor = const StrokePracticeSlideEditor();
    } else if (_selectedSlideType == 'select_cards') {
      editor = const SelectCardsSlideEditor();
    } else if (_selectedSlideType == 'matching_pairs') {
      editor = const MatchingPairsSlideEditor();
    } else {
      editor = const TheorySlideEditor();
    }

    final result = await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => editor),
    );

    if (result != null) {
      setState(() {
        if (_selectedSlideType == 'stroke_practice') {
          slides.add({
            "id": "slide_${DateTime.now().millisecondsSinceEpoch}",
            "type": "stroke_practice",
            "characters": result['characters'],
            "showMode": result['showMode'],
            "allowModeSwitch": result['allowModeSwitch'],
          });
        } else if (_selectedSlideType == 'select_cards') {
          slides.add({
            "id": "slide_${DateTime.now().millisecondsSinceEpoch}",
            "type": "select_cards",
            "content": result,
          });
        } else if (_selectedSlideType == 'matching_pairs') {
          slides.add({
            "id": "slide_${DateTime.now().millisecondsSinceEpoch}",
            "type": "matching_pairs",
            "selectCount": result['selectCount'],
            "matchingPairs": result['matchingPairs'],
          });
        } else {
          slides.add({
            "id": "slide_${DateTime.now().millisecondsSinceEpoch}",
            "type": "theory",
            "content": result,
          });
        }
      });
    }
  }

  void _editSlide(int index) async {
    final slide = slides[index];
    Widget editor;

    if (slide['type'] == 'stroke_practice') {
      editor = StrokePracticeSlideEditor(
        initialCharacters: slide['characters'],
        initialShowMode: slide['showMode'],
        initialAllowModeSwitch: slide['allowModeSwitch'],
      );
    } else if (slide['type'] == 'select_cards') {
      editor = SelectCardsSlideEditor(
        initialContent: List<Map<String, dynamic>>.from(slide['content']),
      );
    } else if (slide['type'] == 'matching_pairs') {
      editor = MatchingPairsSlideEditor(
        initialSelectCount: slide['selectCount'],
        initialMatchingPairs: List<Map<String, String>>.from(slide['matchingPairs']),
      );
    } else {
      editor = TheorySlideEditor(
        initialBlocks: List<Map<String, dynamic>>.from(slide["content"]),
      );
    }

    final result = await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => editor),
    );

    if (result != null) {
      setState(() {
        if (slide['type'] == 'stroke_practice') {
          slides[index] = {
            "id": slide['id'],
            "type": "stroke_practice",
            "characters": result['characters'],
            "showMode": result['showMode'],
            "allowModeSwitch": result['allowModeSwitch'],
          };
        } else if (slide['type'] == 'matching_pairs') {
          slides[index] = {
            "id": slide['id'],
            "type": "matching_pairs",
            "selectCount": result['selectCount'],
            "matchingPairs": result['matchingPairs'],
          };
        } else {
          slides[index] = {
            "id": slide['id'],
            "type": slide['type'],
            "content": result,
          };
        }
      });
    }
  }

  void _removeSlide(int index) {
    setState(() {
      slides.removeAt(index);
    });
  }

  String _extractPreview(dynamic content) {
    if (content is! List || content.isEmpty) return "(порожній)";
    final firstBlock = content.first;
    if (firstBlock is! Map) return "Невірний формат";

    final type = firstBlock["type"];
    final value = firstBlock["value"];

    if (type == "text" && value is String) {
      return value.length > 50 ? value.substring(0, 50) + "..." : value;
    } else if (type == "heading" && value is String) {
      return "Заголовок: $value";
    } else if (type == "image" && value is Map) {
      return "Зображення: ${value['src']}";
    } else if (type == "cards" && value is Map) {
      return "Картки: ${value['options'].join(', ')}";
    }
    return "Блок: $type";
  }

  String _getSlidePreview(Map<String, dynamic> slide) {
    if (slide['type'] == 'stroke_practice') {
      return "Прописи: ${slide['characters']} (режим: ${slide['showMode']})";
    } else if (slide['type'] == 'matching_pairs') {
      return "Пари: ${slide['matchingPairs'].map((pair) => "${pair['first']} - ${pair['second']}").join(', ')}";
    } else {
      return _extractPreview(slide['content']);
    }
  }

  void _finishLesson() {
    final title = _titleController.text.trim();
    if (title.isEmpty || slides.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Будь ласка, введіть назву уроку та додайте слайди.')),
      );
      return;
    }

    Navigator.pop(context, {
      "title": title,
      "slides": slides,
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Редактор уроку'),
        actions: [
          TextButton(
            onPressed: _finishLesson,
            child: const Text('Готово', style: TextStyle(color: Colors.blue)),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: ListView(
          children: [
            TextField(
              controller: _titleController,
              decoration: const InputDecoration(labelText: 'Назва уроку'),
            ),
            const SizedBox(height: 20),
            Row(
              children: [
                Expanded(
                  child: DropdownButtonFormField<String>(
                    decoration: const InputDecoration(
                      labelText: 'Тип слайду',
                      border: OutlineInputBorder(),
                    ),
                    value: _selectedSlideType,
                    items: const [
                      DropdownMenuItem(
                        value: 'theory',
                        child: Text('Теорія'),
                      ),
                      DropdownMenuItem(
                        value: 'stroke_practice',
                        child: Text('Китайські прописи'),
                      ),
                      DropdownMenuItem(
                        value: 'select_cards',
                        child: Text('Вибір карток'),
                      ),
                      DropdownMenuItem(
                        value: 'matching_pairs',
                        child: Text('Збери пари'),
                      ),
                    ],
                    onChanged: (value) {
                      setState(() {
                        _selectedSlideType = value!;
                      });
                    },
                  ),
                ),
                const SizedBox(width: 16),
                ElevatedButton.icon(
                  icon: const Icon(Icons.add),
                  label: const Text('Додати слайд'),
                  onPressed: _addNewSlide,
                ),
              ],
            ),
            const SizedBox(height: 20),
            ...slides.asMap().entries.map((entry) {
              final index = entry.key;
              final slide = entry.value;
              final preview = _getSlidePreview(slide);

              return ListTile(
                leading: Icon(
                  slide['type'] == 'stroke_practice'
                      ? Icons.brush
                      : slide['type'] == 'select_cards'
                      ? Icons.view_carousel
                      : slide['type'] == 'matching_pairs'
                      ? Icons.join_inner
                      : Icons.article_outlined,
                ),
                title: Text(slide['id']),
                subtitle: Text(preview),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      icon: const Icon(Icons.edit, color: Colors.blue),
                      onPressed: () => _editSlide(index),
                    ),
                    IconButton(
                      icon: const Icon(Icons.delete, color: Colors.red),
                      onPressed: () => _removeSlide(index),
                    ),
                  ],
                ),
              );
            }),
          ],
        ),
      ),
    );
  }
}