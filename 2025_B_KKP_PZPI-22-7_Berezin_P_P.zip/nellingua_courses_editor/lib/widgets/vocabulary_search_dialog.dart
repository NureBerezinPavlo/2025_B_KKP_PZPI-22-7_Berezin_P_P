import 'package:flutter/material.dart';
import 'package:nellingua_courses_editor/services/firestore_service.dart';

class VocabularySearchDialog extends StatefulWidget {
  final String courseId;
  final String initialQuery;

  const VocabularySearchDialog({
    super.key,
    required this.courseId,
    required this.initialQuery,
  });

  @override
  State<VocabularySearchDialog> createState() => _VocabularySearchDialogState();
}

class _VocabularySearchDialogState extends State<VocabularySearchDialog> {
  final FirestoreService _fs = FirestoreService();
  final TextEditingController _searchController = TextEditingController();
  List<Map<String, dynamic>> _results = [];
  List<Map<String, dynamic>> _filteredResults = [];

  @override
  void initState() {
    super.initState();
    _searchController.text = widget.initialQuery;
    _loadVocabulary();
  }

  void _loadVocabulary() async {
    final result = await _fs.fetchVocabularyForCourse(widget.courseId);
    setState(() {
      _results = result;
      _filteredResults = result;
    });
  }

  void _updateSearch(String query) {
    if (query.isEmpty) {
      setState(() => _filteredResults = _results);
      return;
    }

    setState(() {
      _filteredResults = _results.where((item) {
        return (item['word']?.toLowerCase().contains(query.toLowerCase()) ?? false) ||
            (item['short_translation']?.toLowerCase().contains(query.toLowerCase()) ?? false) ||
            (item['long_translation']?.toLowerCase().contains(query.toLowerCase()) ?? false);
      }).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      child: Container(
        padding: const EdgeInsets.all(16),
        width: 600,
        height: 500,
        child: Column(
          children: [
            TextField(
              controller: _searchController,
              decoration: const InputDecoration(
                labelText: 'Пошук у словнику',
                prefixIcon: Icon(Icons.search),
              ),
              onChanged: _updateSearch,
            ),
            const SizedBox(height: 16),
            Expanded(
              child: ListView.builder(
                itemCount: _filteredResults.length,
                itemBuilder: (context, index) {
                  final item = _filteredResults[index];
                  return ListTile(
                    title: Text(item['word'] ?? ''),
                    subtitle: Text(item['short_translation'] ?? ''),
                    onTap: () => Navigator.pop(context, {
                      'id': item['id'],
                      'word': item['word'],
                    }),
                  );
                },
              ),
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Скасувати'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}