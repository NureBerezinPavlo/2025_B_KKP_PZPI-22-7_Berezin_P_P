import 'package:flutter/material.dart';

class StrokePracticeSlideEditor extends StatefulWidget {
  final String? initialCharacters;
  final int? initialShowMode;
  final bool? initialAllowModeSwitch;

  const StrokePracticeSlideEditor({
    super.key,
    this.initialCharacters,
    this.initialShowMode,
    this.initialAllowModeSwitch,
  });

  @override
  State<StrokePracticeSlideEditor> createState() => _StrokePracticeSlideEditorState();
}

class _StrokePracticeSlideEditorState extends State<StrokePracticeSlideEditor> {
  late TextEditingController _charactersController;
  late int _showMode;
  late bool _allowModeSwitch;

  @override
  void initState() {
    super.initState();
    _charactersController = TextEditingController(text: widget.initialCharacters ?? '');
    _showMode = widget.initialShowMode ?? 1;
    _allowModeSwitch = widget.initialAllowModeSwitch ?? false;
  }

  @override
  void dispose() {
    _charactersController.dispose();
    super.dispose();
  }

  void _saveSlide() {
    final characters = _charactersController.text.trim();
    if (characters.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Будь ласка, введіть ієрогліфи')),
      );
      return;
    }

    Navigator.pop(context, {
      'characters': characters,
      'showMode': _showMode,
      'allowModeSwitch': _allowModeSwitch,
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Редактор слайду прописи'),
        actions: [
          TextButton(
            onPressed: _saveSlide,
            child: const Text('Зберегти', style: TextStyle(color: Colors.blue)),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: _charactersController,
              decoration: const InputDecoration(
                labelText: 'Ієрогліфи (введіть як рядок)',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 20),
            DropdownButtonFormField<int>(
              decoration: const InputDecoration(
                labelText: 'Режим відображення',
                border: OutlineInputBorder(),
              ),
              value: _showMode,
              items: const [
                DropdownMenuItem(
                  value: 0,
                  child: Text('Видно всі риски'),
                ),
                DropdownMenuItem(
                  value: 1,
                  child: Text('Видно лише наступну риску'),
                ),
                DropdownMenuItem(
                  value: 2,
                  child: Text('Всі риски сховано (просунутий рівень)'),
                ),
              ],
              onChanged: (value) {
                setState(() {
                  _showMode = value!;
                });
              },
            ),
            const SizedBox(height: 20),
            CheckboxListTile(
              title: const Text('Дозволити перемикання режиму'),
              value: _allowModeSwitch,
              onChanged: (value) {
                setState(() {
                  _allowModeSwitch = value!;
                });
              },
            ),
          ],
        ),
      ),
    );
  }
}