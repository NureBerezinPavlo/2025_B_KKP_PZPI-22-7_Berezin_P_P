import 'package:flutter/material.dart';
import 'package:nellingua_courses_editor/services/firestore_service.dart';
import 'package:nellingua_courses_editor/widgets/vocabulary_search_dialog.dart';
import 'dart:math' as math;

class WordHighlightEditorScreen extends StatefulWidget {
  final String sentence;
  final String courseId;
  final String language;
  final List<dynamic> initialHighlights;
  final Function(List<Map<String, dynamic>>)? onSave;

  const WordHighlightEditorScreen({
    super.key,
    required this.sentence,
    required this.courseId,
    required this.language,
    required this.initialHighlights,
    this.onSave,
  });

  @override
  State<WordHighlightEditorScreen> createState() => _WordHighlightEditorScreenState();
}

class _WordHighlightEditorScreenState extends State<WordHighlightEditorScreen> {
  final FirestoreService _fs = FirestoreService();
  List<Map<String, dynamic>> _highlights = [];
  int? _selectedHighlightIndex;
  bool _isAdjustingStart = false;
  bool _isAdjustingEnd = false;
  bool _hasChanges = false;

  // Для ручного виділення
  int? _draggingStartIndex;
  int? _draggingEndIndex;
  bool _isDragging = false;
  List<GlobalKey> _charKeys = [];
  List<Rect> _charRects = [];

  // Додаємо список контролерів для варіантів перекладу
  List<TextEditingController> _translationControllers = [];

  @override
  void initState() {
    super.initState();
    _highlights = List<Map<String, dynamic>>.from(widget.initialHighlights);
    _charKeys = List.generate(widget.sentence.length, (i) => GlobalKey());
    WidgetsBinding.instance.addPostFrameCallback((_) => _updateCharRects());
  }

  @override
  void dispose() {
    // Звільняємо всі контролери, щоб уникнути витоків пам’яті
    for (var controller in _translationControllers) {
      controller.dispose();
    }
    super.dispose();
  }

  void _updateCharRects() {
    _charRects = _charKeys.map((key) {
      final renderBox = key.currentContext?.findRenderObject() as RenderBox?;
      if (renderBox != null) {
        final offset = renderBox.localToGlobal(Offset.zero);
        return offset & renderBox.size;
      }
      return Rect.zero;
    }).toList();
  }

  void _markChanges() {
    if (!_hasChanges) {
      setState(() {
        _hasChanges = true;
      });
    }
  }

  void _addHighlight(int start, int end) {
    // Проверка на пересечение с существующими выделениями
    for (var h in _highlights) {
      if ((start <= h['to'] && end >= h['from']) ||
          (h['from'] <= end && h['to'] >= start)) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Виділення не повинні перетинатися!')),
        );
        return;
      }
    }

    setState(() {
      _highlights.add({
        'from': start,
        'to': end,
        'wordID': '',
        'translation_options': [],
      });
      _selectedHighlightIndex = _highlights.length - 1;
      _updateControllersForHighlight();
      _hasChanges = true;
    });
  }

  void _updateHighlightBoundary(int delta) {
    if (_selectedHighlightIndex == null) return;

    setState(() {
      final highlight = _highlights[_selectedHighlightIndex!];
      if (_isAdjustingStart) {
        int newStart = highlight['from'] + delta;
        if (newStart >= 0 && newStart <= highlight['to']) {
          highlight['from'] = newStart;
          _hasChanges = true;
        }
      } else if (_isAdjustingEnd) {
        int newEnd = highlight['to'] + delta;
        if (newEnd >= highlight['from'] && newEnd < widget.sentence.length) {
          highlight['to'] = newEnd;
          _hasChanges = true;
        }
      }
    });
  }

  Future<void> _confirmRemoveHighlight(int index) async {
    final result = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Видалити підказку?'),
        content: const Text('Ви впевнені, що хочете видалити цю підказку? Цю дію не можна скасувати.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Скасувати'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Видалити', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );

    if (result == true) {
      _removeHighlight(index);
    }
  }

  void _removeHighlight(int index) {
    setState(() {
      // Сохраняем текущий ID выделенного элемента для восстановления
      final currentHighlightId = _selectedHighlightIndex != null
          ? _highlights[_selectedHighlightIndex!]
          : null;

      _highlights.removeAt(index);

      // Обновляем индекс выделенного элемента
      if (_selectedHighlightIndex != null) {
        if (index == _selectedHighlightIndex) {
          // Если удалили выбранный элемент - сбрасываем выбор
          _selectedHighlightIndex = null;
          _updateControllersForHighlight();
        } else if (index < _selectedHighlightIndex!) {
          // Если удалили элемент перед выбранным - уменьшаем индекс
          _selectedHighlightIndex = _selectedHighlightIndex! - 1;
          _updateControllersForHighlight();
        }
      }

      // Восстанавливаем выделение по ID, если это возможно
      if (currentHighlightId != null && _selectedHighlightIndex == null) {
        for (int i = 0; i < _highlights.length; i++) {
          if (_highlights[i] == currentHighlightId) {
            _selectedHighlightIndex = i;
            _updateControllersForHighlight();
            break;
          }
        }
      }

      _hasChanges = true;
    });
  }

  Future<void> _searchVocabulary() async {
    if (_selectedHighlightIndex == null) return;

    final selectedText = widget.sentence.substring(
      _highlights[_selectedHighlightIndex!]['from'],
      _highlights[_selectedHighlightIndex!]['to'] + 1,
    );

    final selectedWord = await showDialog<Map<String, dynamic>>(
      context: context,
      builder: (context) => VocabularySearchDialog(
        courseId: widget.courseId,
        initialQuery: selectedText,
      ),
    );

    if (selectedWord != null && selectedWord['id'] != null) {
      setState(() {
        _highlights[_selectedHighlightIndex!]['wordID'] = selectedWord['id'];
        _hasChanges = true;
      });
    }
  }

  void _addTranslationOption() {
    if (_selectedHighlightIndex == null) return;

    setState(() {
      _highlights[_selectedHighlightIndex!]['translation_options'].add('');
      _translationControllers.add(TextEditingController(text: ''));
      _hasChanges = true;
    });
  }

  void _updateTranslationOption(int index, String value) {
    if (_selectedHighlightIndex == null) return;

    setState(() {
      _highlights[_selectedHighlightIndex!]['translation_options'][index] = value;
      _hasChanges = true;
    });
  }

  Future<void> _confirmRemoveTranslationOption(int index) async {
    final result = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Видалити варіант перекладу?'),
        content: const Text('Ви впевнені, що хочете видалити цей варіант перекладу?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Скасувати'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Видалити', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );

    if (result == true) {
      _removeTranslationOption(index);
    }
  }

  void _removeTranslationOption(int index) {
    if (_selectedHighlightIndex == null) return;

    setState(() {
      _highlights[_selectedHighlightIndex!]['translation_options'].removeAt(index);
      _translationControllers[index].dispose();
      _translationControllers.removeAt(index);
      _hasChanges = true;
    });
  }

  void _autoFormat() {
    List<Map<String, dynamic>> newHighlights = [];
    int start = -1;
    bool isChinese = widget.language == 'zh';

    for (int i = 0; i < widget.sentence.length; i++) {
      final char = widget.sentence[i];
      final isWordChar = isChinese
          ? true // Для китайского каждый символ - слово
          : RegExp(r"[\p{L}\p{M}'-]", unicode: true).hasMatch(char);

      if (isWordChar && start == -1) {
        start = i; // Начало слова
      } else if (!isWordChar && start != -1) {
        // Конец слова
        newHighlights.add({
          'from': start,
          'to': i - 1,
          'wordID': '',
          'translation_options': [],
        });
        start = -1;
      }
    }

    // Добавляем последнее слово
    if (start != -1) {
      newHighlights.add({
        'from': start,
        'to': widget.sentence.length - 1,
        'wordID': '',
        'translation_options': [],
      });
    }

    setState(() {
      _highlights = newHighlights;
      _hasChanges = true;
    });
  }

  // Методы для ручного выделения
  void _startSelection(int index) {
    // Проверяем, не находится ли символ уже в существующем выделении
    for (int i = 0; i < _highlights.length; i++) {
      if (index >= _highlights[i]['from'] && index <= _highlights[i]['to']) {
        // Символ уже в выделении - открываем его редактор
        setState(() {
          _selectedHighlightIndex = i;
          _updateControllersForHighlight();
          _isDragging = false;
          _draggingStartIndex = null;
          _draggingEndIndex = null;
        });
        return;
      }
    }

    // Начинаем новое выделение
    setState(() {
      _draggingStartIndex = index;
      _draggingEndIndex = index;
      _isDragging = true;
    });
  }

  void _updateSelection(int index) {
    if (_isDragging) {
      setState(() => _draggingEndIndex = index);
    }
  }

  void _endSelection() {
    if (_isDragging && _draggingStartIndex != null && _draggingEndIndex != null) {
      final start = math.min(_draggingStartIndex!, _draggingEndIndex!);
      final end = math.max(_draggingStartIndex!, _draggingEndIndex!);

      // Минимальное выделение - 1 символ
      if (start == end && !_hasOverlap(start, end)) {
        _addHighlight(start, end);
      }
      // Выделение больше 1 символа
      else if (start < end && !_hasOverlap(start, end)) {
        _addHighlight(start, end);
      }
    }

    setState(() {
      _isDragging = false;
      _draggingStartIndex = null;
      _draggingEndIndex = null;
    });
  }

  bool _hasOverlap(int newStart, int newEnd) {
    for (var h in _highlights) {
      if ((newStart <= h['to'] && newEnd >= h['from']) ||
          (h['from'] <= newEnd && h['to'] >= newStart)) {
        return true;
      }
    }
    return false;
  }

  int? _getIndexAtPos(Offset globalPos) {
    for (int i = 0; i < _charRects.length; i++) {
      if (_charRects[i].contains(globalPos)) return i;
    }
    return null;
  }

  Widget _buildCharWidget(int index, String char) {
    bool isHighlighted = false;
    bool isSelected = false;
    int? highlightIndex;

    for (int i = 0; i < _highlights.length; i++) {
      if (index >= _highlights[i]['from'] && index <= _highlights[i]['to']) {
        isHighlighted = true;
        if (i == _selectedHighlightIndex) {
          isSelected = true;
        }
        highlightIndex = i;
        break;
      }
    }

    bool isInSelection = _isDragging &&
        index >= math.min(_draggingStartIndex ?? index, _draggingEndIndex ?? index) &&
        index <= math.max(_draggingStartIndex ?? index, _draggingEndIndex ?? index);

    return GestureDetector(
      onTapDown: (_) => _startSelection(index),
      onPanUpdate: (details) {
        final newIndex = _getIndexAtPos(details.globalPosition);
        if (newIndex != null) _updateSelection(newIndex);
      },
      onPanEnd: (_) => _endSelection(),
      child: Container(
        key: _charKeys[index],
        padding: const EdgeInsets.symmetric(horizontal: 2, vertical: 4),
        decoration: BoxDecoration(
          border: isInSelection
              ? Border.all(color: Colors.red, width: 2)
              : isSelected
              ? Border.all(color: Colors.blue, width: 2)
              : isHighlighted
              ? Border.all(color: Colors.blue)
              : null,
          color: isSelected ? Colors.blue[50] : (isHighlighted ? Colors.blue[50] : null),
        ),
        child: Text(char),
      ),
    );
  }

  Widget _buildHighlightEditor() {
    // Перевірка на валидність індексу
    if (_selectedHighlightIndex == null ||
        _selectedHighlightIndex! >= _highlights.length) {
      return const SizedBox.shrink();
    }

    final highlight = _highlights[_selectedHighlightIndex!];
    final selectedText = widget.sentence.substring(
      highlight['from'],
      highlight['to'] + 1,
    );

    // Синхронізуємо контролери зі списком translation_options
    while (_translationControllers.length < highlight['translation_options'].length) {
      _translationControllers.add(TextEditingController(
          text: highlight['translation_options'][_translationControllers.length]));
    }
    while (_translationControllers.length > highlight['translation_options'].length) {
      _translationControllers.last.dispose();
      _translationControllers.removeLast();
    }

    return Card(
      elevation: 3,
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Виділено: $selectedText",
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            // Управление границами
            Row(
              children: [
                ElevatedButton(
                  onPressed: () {
                    setState(() {
                      _isAdjustingStart = true;
                      _isAdjustingEnd = false;
                    });
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _isAdjustingStart ? Colors.blue : null,
                  ),
                  child: const Text('Початок'),
                ),
                const SizedBox(width: 8),
                ElevatedButton(
                  onPressed: () {
                    setState(() {
                      _isAdjustingStart = false;
                      _isAdjustingEnd = true;
                    });
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _isAdjustingEnd ? Colors.blue : null,
                  ),
                  child: const Text('Кінець'),
                ),
                const SizedBox(width: 16),
                IconButton(
                  icon: const Icon(Icons.arrow_left),
                  onPressed: () => _updateHighlightBoundary(-1),
                ),
                IconButton(
                  icon: const Icon(Icons.arrow_right),
                  onPressed: () => _updateHighlightBoundary(1),
                ),
              ],
            ),
            const SizedBox(height: 10),
            // Связь с вокабуляром
            Row(
              children: [
                Text("ID слова: ${highlight['wordID']}"),
                const SizedBox(width: 8),
                ElevatedButton(
                  onPressed: _searchVocabulary,
                  child: const Text('Знайти в словнику'),
                ),
              ],
            ),
            const SizedBox(height: 10),
            // Варианты перевода
            const Text("Варіанти перекладу:", style: TextStyle(fontWeight: FontWeight.bold)),
            ...highlight['translation_options'].asMap().entries.map((entry) {
              final idx = entry.key;
              final option = entry.value;

              return Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _translationControllers[idx], // Використовуємо збережений контролер
                      onChanged: (value) => _updateTranslationOption(idx, value),
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.delete, color: Colors.red),
                    onPressed: () => _confirmRemoveTranslationOption(idx),
                  ),
                ],
              );
            }).toList(),
            ElevatedButton(
              onPressed: _addTranslationOption,
              child: const Text('Додати варіант'),
            ),
          ],
        ),
      ),
    );
  }

  Future<bool> _confirmExit() async {
    if (!_hasChanges) return true;

    final result = await showDialog<int>(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: const Text('Незбережені зміни'),
        content: const Text('У вас є незбережені зміни. Що ви хочете зробити?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, 1),
            child: const Text('Зберегти та вийти'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, 2),
            child: const Text('Вийти без збереження', style: TextStyle(color: Colors.red)),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, 0),
            child: const Text('Не виходити'),
          ),
        ],
      ),
    );

    switch (result) {
      case 1: // Сохранить и выйти
        if (widget.onSave != null) {
          widget.onSave!(_highlights);
        }
        return true;
      case 2: // Выйти без сохранения
        return true;
      default: // Не выходить
        return false;
    }
  }

  void _updateControllersForHighlight() {
    if (_selectedHighlightIndex == null ||
        _selectedHighlightIndex! >= _highlights.length) {
      // Очищаємо контролери, якщо немає виділення
      for (var controller in _translationControllers) {
        controller.dispose();
      }
      _translationControllers.clear();
      return;
    }

    final highlight = _highlights[_selectedHighlightIndex!];
    final options = highlight['translation_options'] as List<dynamic>;

    // Синхронізуємо контролери зі списком варіантів перекладу
    while (_translationControllers.length > options.length) {
      _translationControllers.last.dispose();
      _translationControllers.removeLast();
    }
    while (_translationControllers.length < options.length) {
      _translationControllers.add(TextEditingController(
          text: options[_translationControllers.length]));
    }

    // Оновлюємо текст у контролерах
    for (int i = 0; i < options.length; i++) {
      _translationControllers[i].text = options[i];
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        final shouldExit = await _confirmExit();
        if (shouldExit) {
          Navigator.pop(context, _highlights);
        }
        return false;
      },
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Редактор підказок'),
          actions: [
            IconButton(
              icon: const Icon(Icons.auto_fix_high),
              onPressed: _autoFormat,
              tooltip: 'Автоформатування',
            ),
            IconButton(
              icon: const Icon(Icons.save),
              onPressed: () {
                if (widget.onSave != null) {
                  widget.onSave!(_highlights);
                }
                setState(() => _hasChanges = false);
                Navigator.pop(context, _highlights);
              },
            ),
          ],
        ),
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Визуализация предложения с выделениями
              GestureDetector(
                onPanEnd: (_) => _endSelection(),
                child: Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.grey),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Wrap(
                    children: widget.sentence.split('').asMap().entries.map((entry) {
                      return _buildCharWidget(entry.key, entry.value);
                    }).toList(),
                  ),
                ),
              ),

              const SizedBox(height: 20),

              // Панель управления выделением
              if (_selectedHighlightIndex != null &&
                  _selectedHighlightIndex! < _highlights.length) ...[
                _buildHighlightEditor(),
                const SizedBox(height: 20),
              ],

              // Список всех выделений
              Expanded(
                child: ListView.builder(
                  itemCount: _highlights.length,
                  itemBuilder: (context, index) {
                    final highlight = _highlights[index];
                    final text = widget.sentence.substring(
                      highlight['from'],
                      highlight['to'] + 1,
                    );

                    return ListTile(
                      title: Text(text),
                      subtitle: Text("${highlight['from']}-${highlight['to']}"),
                      selected: index == _selectedHighlightIndex,
                      onTap: () {
                        setState(() {
                          _selectedHighlightIndex = index;
                          _isAdjustingStart = false;
                          _isAdjustingEnd = false;
                          _updateControllersForHighlight();
                        });
                      },
                      trailing: IconButton(
                        icon: const Icon(Icons.delete, color: Colors.red),
                        onPressed: () => _confirmRemoveHighlight(index),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}