import 'package:flutter/material.dart';
import 'package:nellingua_courses_editor/widgets/word_highlight_editor_screen.dart';
import '../services/firestore_service.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:image_picker/image_picker.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:audioplayers/audioplayers.dart';
import 'dart:io';

import 'audio_record_editor.dart';

class SentenceEditorScreen extends StatefulWidget {
  final String courseId;
  final String baseLanguage;
  final String targetLanguage;
  final Map<String, dynamic>? initialData;
  final Function(Map<String, dynamic>)? onSave;

  const SentenceEditorScreen({
    super.key,
    required this.courseId,
    required this.baseLanguage,
    required this.targetLanguage,
    this.initialData,
    this.onSave,
  });

  @override
  State<SentenceEditorScreen> createState() => _SentenceEditorScreenState();
}

class _SentenceEditorScreenState extends State<SentenceEditorScreen> {
  final TextEditingController _idController = TextEditingController();
  final Map<String, dynamic> _sentenceData = {
    "sentence_id": "",
    "course_id": "",
    "exercise_types": [],
    "foreign": {
      "default_options": [],
      "alternative_options": []
    },
    "native": {
      "default_options": [],
      "alternative_options": []
    },
    "alternative_options": []
  };

  final List<TextEditingController> _foreignDefaultControllers = [];
  final List<TextEditingController> _foreignAlternativeControllers = [];
  final List<TextEditingController> _nativeDefaultControllers = [];
  final List<TextEditingController> _alternativeOptionControllers = [];

  final List<String> _exerciseTypes = [
    "reading_and_wordchips",
    "reading_and_keyboard_input",
    "reading_and_speaking",
    "listening_and_wordchips",
    "listening_and_keyboard_input"
  ];

  final Map<String, String> _exerciseTypeNames = {
    'reading_and_wordchips': 'Читання та словоблоки',
    'reading_and_keyboard_input': 'Читання та клавіатура',
    'reading_and_speaking': 'Читання та вимова',
    'listening_and_wordchips': 'Слухання та словоблоки',
    'listening_and_keyboard_input': 'Слухання та клавіатура',
  };

  @override
  void initState() {
    super.initState();

    if (widget.initialData != null) {
      _sentenceData.addAll(widget.initialData!);
      _idController.text = widget.initialData!['sentence_id'] ?? '';

      _initControllers();
    } else {
      _idController.text = 'sentence_${DateTime.now().millisecondsSinceEpoch}';
      _sentenceData['sentence_id'] = _idController.text;
      _sentenceData['course_id'] = widget.courseId;
    }
  }

  void _initControllers() {
    for (var option in _sentenceData['foreign']['default_options']) {
      _foreignDefaultControllers.add(TextEditingController(text: option['sentence']));
    }

    for (var option in _sentenceData['foreign']['alternative_options']) {
      _foreignAlternativeControllers.add(TextEditingController(text: option));
    }

    for (var option in _sentenceData['native']['default_options']) {
      _nativeDefaultControllers.add(TextEditingController(text: option['sentence']));
    }

    for (var option in _sentenceData['alternative_options']) {
      _alternativeOptionControllers.add(TextEditingController(text: option));
    }
  }

  @override
  void dispose() {
    _idController.dispose();
    for (var controller in _foreignDefaultControllers) {
      controller.dispose();
    }
    for (var controller in _foreignAlternativeControllers) {
      controller.dispose();
    }
    for (var controller in _nativeDefaultControllers) {
      controller.dispose();
    }
    for (var controller in _alternativeOptionControllers) {
      controller.dispose();
    }
    super.dispose();
  }

  void _addDefaultForeignOption() {
    setState(() {
      _sentenceData['foreign']['default_options'].add({
        "native_speakers_audio": [],
        "sentence": "",
        "highlighted_words": []
      });
      _foreignDefaultControllers.add(TextEditingController());
    });
  }

  void _addAlternativeForeignOption() {
    setState(() {
      _sentenceData['foreign']['alternative_options'].add("");
      _foreignAlternativeControllers.add(TextEditingController());
    });
  }

  void _addDefaultNativeOption() {
    setState(() {
      _sentenceData['native']['default_options'].add({
        "sentence": "",
        "highlighted_words": []
      });
      _nativeDefaultControllers.add(TextEditingController());
    });
  }

  void _addAlternativeOption() {
    setState(() {
      _sentenceData['alternative_options'].add("");
      _alternativeOptionControllers.add(TextEditingController());
    });
  }

  void _saveSentence() {
    for (int i = 0; i < _foreignDefaultControllers.length; i++) {
      _sentenceData['foreign']['default_options'][i]['sentence'] =
          _foreignDefaultControllers[i].text;
    }
    for (int i = 0; i < _foreignAlternativeControllers.length; i++) {
      _sentenceData['foreign']['alternative_options'][i] =
          _foreignAlternativeControllers[i].text;
    }
    for (int i = 0; i < _nativeDefaultControllers.length; i++) {
      _sentenceData['native']['default_options'][i]['sentence'] =
          _nativeDefaultControllers[i].text;
    }
    for (int i = 0; i < _alternativeOptionControllers.length; i++) {
      _sentenceData['alternative_options'][i] =
          _alternativeOptionControllers[i].text;
    }

    _sentenceData['sentence_id'] = _idController.text;

    FirestoreService().saveSentence(_sentenceData);

    if (widget.onSave != null) {
      widget.onSave!(_sentenceData);
    }

    Navigator.pop(context);
  }

  void _removeDefaultForeignOption(int index) {
    setState(() {
      _sentenceData['foreign']['default_options'].removeAt(index);
      _foreignDefaultControllers[index].dispose();
      _foreignDefaultControllers.removeAt(index);
    });
  }

  void _removeAlternativeForeignOption(int index) {
    setState(() {
      _sentenceData['foreign']['alternative_options'].removeAt(index);
      _foreignAlternativeControllers[index].dispose();
      _foreignAlternativeControllers.removeAt(index);
    });
  }

  void _removeDefaultNativeOption(int index) {
    setState(() {
      _sentenceData['native']['default_options'].removeAt(index);
      _nativeDefaultControllers[index].dispose();
      _nativeDefaultControllers.removeAt(index);
    });
  }

  void _removeAlternativeOption(int index) {
    setState(() {
      _sentenceData['alternative_options'].removeAt(index);
      _alternativeOptionControllers[index].dispose();
      _alternativeOptionControllers.removeAt(index);
    });
  }

  void _openWordHighlightEditor(
      String sentence,
      List<dynamic> highlights,
      String languageType,
      int index,
      ) async {
    final updatedHighlights = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => WordHighlightEditorScreen(
          sentence: sentence,
          courseId: widget.courseId,
          language: languageType == 'foreign'
              ? widget.targetLanguage
              : widget.baseLanguage,
          initialHighlights: highlights,
        ),
      ),
    );

    if (updatedHighlights != null) {
      setState(() {
        if (languageType == 'foreign') {
          _sentenceData['foreign']['default_options'][index]['highlighted_words'] =
              updatedHighlights;
        } else {
          _sentenceData['native']['default_options'][index]['highlighted_words'] =
              updatedHighlights;
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.initialData == null
            ? 'Нове речення'
            : 'Редагування речення'),
        actions: [
          IconButton(
            icon: const Icon(Icons.save),
            onPressed: _saveSentence,
            tooltip: 'Зберегти речення',
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: _idController,
              decoration: const InputDecoration(
                labelText: "ID речення",
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 20),

            const Text("Типи вправ:",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            ..._exerciseTypes.map((type) =>
                CheckboxListTile(
                  title: Text(_exerciseTypeNames[type] ?? type),
                  value: _sentenceData['exercise_types'].contains(type),
                  onChanged: (value) {
                    setState(() {
                      if (value == true) {
                        _sentenceData['exercise_types'].add(type);
                      } else {
                        _sentenceData['exercise_types'].remove(type);
                      }
                    });
                  },
                )),
            const SizedBox(height: 20),

            const Text("Іноземна мова:",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            ..._sentenceData['foreign']['default_options']
                .asMap()
                .entries
                .map((entry) {
              final index = entry.key;
              return Card(
                margin: const EdgeInsets.only(bottom: 16),
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          const Text("Основне речення:",
                              style: TextStyle(fontWeight: FontWeight.w500)),
                          const Spacer(),
                          IconButton(
                            icon: const Icon(Icons.delete, color: Colors.red),
                            onPressed: () => _removeDefaultForeignOption(index),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      TextField(
                        controller: _foreignDefaultControllers[index],
                        decoration: const InputDecoration(
                          labelText: "Речення",
                          border: OutlineInputBorder(),
                        ),
                        maxLines: 2,
                      ),
                      const SizedBox(height: 20),

                      Row(
                        children: [
                          const Text("Підказки до слів:",
                              style: TextStyle(fontWeight: FontWeight.w500)),
                          const SizedBox(width: 10),
                          ElevatedButton(
                            onPressed: () =>
                                _openWordHighlightEditor(
                                  _foreignDefaultControllers[index].text,
                                  _sentenceData['foreign']['default_options'][index]['highlighted_words'] ?? [],
                                  'foreign',
                                  index,
                                ),
                            child: const Text("Редагувати"),
                            style: ElevatedButton.styleFrom(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 12, vertical: 8),
                            ),
                          ),
                        ],
                      ),
                      if ((_sentenceData['foreign']['default_options'][index]['highlighted_words'] ?? []).isNotEmpty)
                        Padding(
                          padding: const EdgeInsets.only(top: 8.0),
                          child: Text(
                            "Додано ${_sentenceData['foreign']['default_options'][index]['highlighted_words'].length} підказок",
                            style: TextStyle(color: Colors.grey[600]),
                          ),
                        ),
                      const SizedBox(height: 20),

                      const Text("Native Speakers Audio:", style: TextStyle(fontWeight: FontWeight.w500)),
                      const SizedBox(height: 10),
                      ..._sentenceData['foreign']['default_options'][index]['native_speakers_audio']
                          .asMap()
                          .entries
                          .map((entry) {
                        final recordIndex = entry.key;
                        final record = entry.value;
                        return AudioRecordEditor(
                          audioRecord: record,
                          sentenceId: _idController.text,
                          optionIndex: index,
                          recordIndex: recordIndex,
                          onUpdate: (updatedRecord) => _updateAudioRecord(index, recordIndex, updatedRecord),
                          onDelete: () => _removeAudioRecord(index, recordIndex),
                        );
                      }).toList(),
                      ElevatedButton(
                        onPressed: () => _addAudioRecord(index),
                        child: const Text("Add Audio Record"),
                      ),
                    ],
                  ),
                ),
              );
            }),
            ElevatedButton(
              onPressed: _addDefaultForeignOption,
              child: const Text("Додати основне речення"),
            ),
            const SizedBox(height: 20),

            const Text("Альтернативні варіанти (іноземна):",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            ..._sentenceData['foreign']['alternative_options']
                .asMap()
                .entries
                .map((entry) {
              final index = entry.key;
              return Card(
                margin: const EdgeInsets.only(bottom: 10),
                child: Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: Row(
                    children: [
                      Expanded(
                          child: TextField(
                            controller: _foreignAlternativeControllers[index],
                            decoration: InputDecoration(
                              labelText: "Альтернативний варіант ${index + 1}",
                              border: const OutlineInputBorder(),
                            ),
                          )),
                      IconButton(
                        icon: const Icon(Icons.delete, color: Colors.red),
                        onPressed: () => _removeAlternativeForeignOption(index),
                      ),
                    ],
                  ),
                ),
              );
            }),
            ElevatedButton(
              onPressed: _addAlternativeForeignOption,
              child: const Text("Додати альтернативний варіант"),
            ),
            const SizedBox(height: 30),

            const Text("Рідна мова:",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            ..._sentenceData['native']['default_options']
                .asMap()
                .entries
                .map((entry) {
              final index = entry.key;
              return Card(
                margin: const EdgeInsets.only(bottom: 16),
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          const Text("Основне речення:",
                              style: TextStyle(fontWeight: FontWeight.w500)),
                          const Spacer(),
                          IconButton(
                            icon: const Icon(Icons.delete, color: Colors.red),
                            onPressed: () => _removeDefaultNativeOption(index),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      TextField(
                        controller: _nativeDefaultControllers[index],
                        decoration: const InputDecoration(
                          labelText: "Речення",
                          border: OutlineInputBorder(),
                        ),
                        maxLines: 2,
                      ),
                      const SizedBox(height: 20),

                      Row(
                        children: [
                          const Text("Підказки до слів:",
                              style: TextStyle(fontWeight: FontWeight.w500)),
                          const SizedBox(width: 10),
                          ElevatedButton(
                            onPressed: () =>
                                _openWordHighlightEditor(
                                  _nativeDefaultControllers[index].text,
                                  _sentenceData['native']['default_options'][index]['highlighted_words'] ?? [],
                                  'native',
                                  index,
                                ),
                            child: const Text("Редагувати"),
                            style: ElevatedButton.styleFrom(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 12, vertical: 8),
                            ),
                          ),
                        ],
                      ),
                      if ((_sentenceData['native']['default_options'][index]['highlighted_words'] ?? []).isNotEmpty)
                        Padding(
                          padding: const EdgeInsets.only(top: 8.0),
                          child: Text(
                            "Додано ${_sentenceData['native']['default_options'][index]['highlighted_words'].length} підказок",
                            style: TextStyle(color: Colors.grey[600]),
                          ),
                        ),
                    ],
                  ),
                ),
              );
            }),
            ElevatedButton(
              onPressed: _addDefaultNativeOption,
              child: const Text("Додати основне речення"),
            ),
            const SizedBox(height: 20),

            const Text("Альтернативні варіанти (рідна):",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            ..._sentenceData['alternative_options']
                .asMap()
                .entries
                .map((entry) {
              final index = entry.key;
              return Card(
                margin: const EdgeInsets.only(bottom: 10),
                child: Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: _alternativeOptionControllers[index],
                          decoration: InputDecoration(
                            labelText: "Альтернативний варіант ${index + 1}",
                            border: const OutlineInputBorder(),
                          ),
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.delete, color: Colors.red),
                        onPressed: () => _removeAlternativeOption(index),
                      ),
                    ],
                  ),
                ),
              );
            }),
            ElevatedButton(
              onPressed: _addAlternativeOption,
              child: const Text("Додати альтернативний варіант"),
            ),
            const SizedBox(height: 30),
          ],
        ),
      ),
    );
  }

  void _addAudioRecord(int optionIndex) {
    setState(() {
      _sentenceData['foreign']['default_options'][optionIndex]['native_speakers_audio'].add({
        "author": "",
        "normal": null,
        "a_little_bit_more_slowly": null,
        "more_slowly": null,
        "much_more_slowly": null,
        "super_slowly": null
      });
    });
  }

  void _updateAudioRecord(int optionIndex, int recordIndex, Map<String, dynamic> updatedRecord) {
    setState(() {
      _sentenceData['foreign']['default_options'][optionIndex]['native_speakers_audio'][recordIndex] = updatedRecord;
    });
  }

  void _removeAudioRecord(int optionIndex, int recordIndex) {
    setState(() {
      _sentenceData['foreign']['default_options'][optionIndex]['native_speakers_audio'].removeAt(recordIndex);
    });
  }
}