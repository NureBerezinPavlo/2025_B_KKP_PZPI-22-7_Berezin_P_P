import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:nellingua_courses_editor/services/firestore_service.dart';
import 'level_editor_screen.dart';
import 'dart:math';

class UnitEditorScreen extends StatefulWidget {
  final Map<String, dynamic>? initialData;
  final String courseId;

  const UnitEditorScreen({super.key, this.initialData, required this.courseId});

  @override
  State<UnitEditorScreen> createState() => _UnitEditorScreenState();
}

class _UnitEditorScreenState extends State<UnitEditorScreen> {
  String unitId = '';
  String unitName = '';
  final List<Map<String, dynamic>> levels = [];
  final List<Map<String, dynamic>> linePoints = [];
  Color lineColor = Colors.blue;
  final ScrollController _scrollController = ScrollController();
  final ScrollController _sidePanelScrollController = ScrollController();
  bool isDrawingMode = false;
  String? selectedElementId;
  String? selectedElementType;
  double canvasHeight = 1200;
  final GlobalKey _canvasKey = GlobalKey();
  Offset? _lastPointPosition;
  Offset? _dragStartPosition;
  Map<String, dynamic>? _draggingLevel;
  Map<String, dynamic>? _draggingPoint;

  @override
  void initState() {
    super.initState();

    if (widget.initialData != null) {
      final data = widget.initialData!;
      unitId = data["id"] ?? '';
      unitName = data["name"] ?? '';

      if (data["levels"] != null && data["levels"] is List) {
        levels.addAll(List<Map<String, dynamic>>.from(data["levels"]));
      }

      if (data["linePoints"] != null && data["linePoints"] is List) {
        linePoints.addAll(List<Map<String, dynamic>>.from(data["linePoints"]));
      }

      if (data["lineColor"] != null) {
        lineColor = Color(data["lineColor"]);
      }
    }
    _updateCanvasHeight();
  }

  @override
  void dispose() {
    _scrollController.dispose();
    _sidePanelScrollController.dispose();
    super.dispose();
  }

  void _addLevel() {
    final newLevelId = 'level_${DateTime.now().millisecondsSinceEpoch}';
    setState(() {
      levels.add({
        'id': newLevelId,
        'name': 'Новий рівень',
        'type': 'theory',
        'position': levels.length,
        'lessons': [],
        'x': 100.0,
        'y': 100.0
      });
      _updateCanvasHeight();
    });
  }

  void _addLinePoint(Offset position) {
    final newPointId = 'point_${DateTime.now().millisecondsSinceEpoch}';
    setState(() {
      if (linePoints.isNotEmpty && _lastPointPosition != null) {
        final distance = (position - _lastPointPosition!).distance;
        final newPosition = distance > 50 ? position : _lastPointPosition! + const Offset(50, 0);

        linePoints.add({
          'id': newPointId,
          'x': newPosition.dx,
          'y': newPosition.dy,
        });
        _lastPointPosition = newPosition;
      } else {
        linePoints.add({
          'id': newPointId,
          'x': position.dx,
          'y': position.dy,
        });
        _lastPointPosition = position;
      }
      _updateCanvasHeight();
    });
  }

  void _updateCanvasHeight() {
    double maxY = 0;
    for (final level in levels) {
      if (level['y'] > maxY) maxY = level['y'].toDouble();
    }
    for (final point in linePoints) {
      if (point['y'] > maxY) maxY = point['y'].toDouble();
    }
    setState(() {
      canvasHeight = maxY + 200;
    });
  }

  void _editLevel(int index) async {
    final currentLevel = levels[index];

    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => LevelEditorScreen(
          initialTitle: currentLevel['name'],
          initialLessons: currentLevel['lessons'] != null
              ? List<Map<String, dynamic>>.from(currentLevel['lessons'])
              : null,
          initialType: currentLevel['type'] ?? 'theory', // Передаем текущий тип
          courseId: widget.courseId,
        ),
      ),
    );

    if (result != null && result is Map<String, dynamic>) {
      setState(() {
        levels[index] = {
          ...levels[index],
          'name': result['title'] ?? currentLevel['name'],
          'lessons': result['lessons'] ?? currentLevel['lessons'],
          'type': result['type'] ?? currentLevel['type'] ?? 'theory',
        };
      });
    }
  }

  void _removeSelectedElement() {
    if (selectedElementId == null || selectedElementType == null) return;

    setState(() {
      if (selectedElementType == 'level') {
        levels.removeWhere((element) => element['id'] == selectedElementId);
      } else if (selectedElementType == 'point') {
        linePoints.removeWhere((element) => element['id'] == selectedElementId);
      }
      selectedElementId = null;
      selectedElementType = null;
      _updateCanvasHeight();
    });
  }

  void _moveLevel(int index, Offset newPosition) {
    setState(() {
      levels[index]['x'] = newPosition.dx;
      levels[index]['y'] = newPosition.dy;
      _updateCanvasHeight();
    });
  }

  void _moveLinePoint(int index, Offset newPosition) {
    setState(() {
      linePoints[index]['x'] = newPosition.dx;
      linePoints[index]['y'] = newPosition.dy;
      _updateCanvasHeight();
    });
  }

  void _saveAndExit() async {
    if (unitId.trim().isEmpty || unitName.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Заповніть ID та назву юніта")),
      );
      return;
    }

    final unitData = {
      "id": unitId,
      "name": unitName,
      "levels": levels,
      "linePoints": linePoints,
      "lineColor": lineColor.value,
    };

    try {
      await FirestoreService().saveUnit(unitData);
      Navigator.pop(context, unitData);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Помилка при збереженні: $e")),
      );
    }
  }

  // для тестування
  void _showUnitData() {
    final unitData = {
      "id": unitId,
      "name": unitName,
      "levels": levels,
      "linePoints": linePoints,
      "lineColor": lineColor.value,
    };

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Дані юніта (JSON)'),
        content: SizedBox(
          width: double.maxFinite,
          child: SingleChildScrollView(
            child: SelectableText(
              const JsonEncoder.withIndent('  ').convert(unitData),
              style: const TextStyle(fontFamily: 'monospace'),
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  void _showLevelContextMenu(BuildContext context, Map<String, dynamic> level, int index, Offset position) {
    final RenderBox overlay = Overlay.of(context).context.findRenderObject() as RenderBox;

    showMenu(
      context: context,
      position: RelativeRect.fromRect(
        Rect.fromPoints(position, position),
        Offset.zero & overlay.size,
      ),
      items: [
        PopupMenuItem(
          onTap: () => _editLevel(index),
          child: const Row(
            children: [
              Icon(Icons.edit, size: 20),
              SizedBox(width: 8),
              Text('Редагувати вміст'),
            ],
          ),
        ),
        PopupMenuItem(
          onTap: () {
            setState(() {
              levels.removeAt(index);
              _updateCanvasHeight();
            });
          },
          child: const Row(
            children: [
              Icon(Icons.delete, size: 20, color: Colors.red),
              SizedBox(width: 8),
              Text('Видалити рівень', style: TextStyle(color: Colors.red)),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildLevelItem(Map<String, dynamic> level, int index) {
    final lessonCount = (level['lessons'] as List?)?.length ?? 0;
    final type = level['type'] ?? 'theory';
    final colors = _getLevelColors(index);

    // Добавляем иконку в зависимости от типа
    IconData icon;
    switch (type) {
      case 'practice':
        icon = Icons.assignment;
        break;
      case 'revision':
        icon = Icons.repeat;
        break;
      case 'final':
        icon = Icons.star;
        break;
      default:
        icon = Icons.book;
    }

    return GestureDetector(
      onPanStart: (details) {
        _dragStartPosition = details.globalPosition;
        _draggingLevel = level;
      },
      onPanUpdate: (details) {
        if (_draggingLevel != null) {
          final renderBox = _canvasKey.currentContext?.findRenderObject() as RenderBox?;
          if (renderBox == null) return;

          final localPosition = renderBox.globalToLocal(details.globalPosition);
          _moveLevel(index, localPosition);
        }
      },
      onPanEnd: (_) {
        _draggingLevel = null;
        _dragStartPosition = null;
      },
      onTapDown: (details) {
        setState(() {
          selectedElementId = level['id'];
          selectedElementType = 'level';
        });
        _showLevelContextMenu(context, level, index, details.globalPosition);
      },
      child: Container(
        width: 60,
        height: 60,
        decoration: BoxDecoration(
          color: colors.backgroundColor,
          borderRadius: BorderRadius.circular(30),
          border: Border.all(
            color: selectedElementId == level['id']
                ? Colors.red
                : colors.borderColor,
            width: selectedElementId == level['id'] ? 3 : 2,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              blurRadius: 5,
              offset: const Offset(0, 3),
            )
          ],
        ),
        child: Stack(
          alignment: Alignment.center,
          children: [
            Icon(icon, color: colors.textColor),
            Text(
              '${index + 1}',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: colors.textColor,
              ),
            ),
            if (lessonCount > 0)
              Positioned(
                right: 0,
                bottom: 0,
                child: Container(
                  padding: const EdgeInsets.all(4),
                  decoration: BoxDecoration(
                    color: Colors.orange,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Text(
                    '$lessonCount',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 10,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildLinePoint(Map<String, dynamic> point, int index) {
    return GestureDetector(
      onPanStart: (details) {
        _dragStartPosition = details.globalPosition;
        _draggingPoint = point;
      },
      onPanUpdate: (details) {
        if (_draggingPoint != null) {
          final renderBox = _canvasKey.currentContext?.findRenderObject() as RenderBox?;
          if (renderBox == null) return;

          final localPosition = renderBox.globalToLocal(details.globalPosition);
          _moveLinePoint(index, localPosition);
        }
      },
      onPanEnd: (_) {
        _draggingPoint = null;
        _dragStartPosition = null;
      },
      onTap: () {
        if (!isDrawingMode) {
          setState(() {
            selectedElementId = point['id'];
            selectedElementType = 'point';
          });
        }
      },
      child: Container(
        width: 16,
        height: 16,
        decoration: BoxDecoration(
          color: selectedElementId == point['id'] ? Colors.red : lineColor,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: Colors.white,
            width: 2,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.2),
              blurRadius: 3,
              offset: const Offset(0, 2),
            )
          ],
        ),
      ),
    );
  }

  LevelColors _getLevelColors(int index) {
    final type = levels[index]['type'] ?? 'theory';

    switch (type) {
      case 'practice':
        return LevelColors(
          backgroundColor: Colors.blue.shade50,
          borderColor: Colors.blue,
          textColor: Colors.blue.shade800,
        );
      case 'revision':
        return LevelColors(
          backgroundColor: Colors.orange.shade50,
          borderColor: Colors.orange,
          textColor: Colors.orange.shade800,
        );
      case 'final':
        return LevelColors(
          backgroundColor: Colors.purple.shade50,
          borderColor: Colors.purple,
          textColor: Colors.purple.shade800,
        );
      default: // theory
        return LevelColors(
          backgroundColor: Colors.green.shade50,
          borderColor: Colors.green,
          textColor: Colors.green.shade800,
        );
    }
  }

  CustomPaint _buildLineRenderer() {
    return CustomPaint(
      size: Size.infinite,
      painter: LineRendererPainter(
        linePoints: linePoints,
        lineColor: lineColor,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Редактор юніта'),
        actions: [
          IconButton(
            icon: const Icon(Icons.save),
            onPressed: _saveAndExit,
            tooltip: 'Зберегти юніт',
          ),
        ],
      ),
      body: Row(
        children: [
          // Боковая панель
          Container(
            width: 200,
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.grey.shade100,
              border: Border(right: BorderSide(color: Colors.grey.shade300)),
            ),
            child: SingleChildScrollView(
              controller: _sidePanelScrollController,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  TextField(
                    decoration: const InputDecoration(
                      labelText: "ID юніта",
                      border: OutlineInputBorder(),
                      contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 12),
                    ),
                    controller: TextEditingController(text: unitId),
                    onChanged: (val) => unitId = val,
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    decoration: const InputDecoration(
                      labelText: "Назва юніта",
                      border: OutlineInputBorder(),
                      contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 12),
                    ),
                    controller: TextEditingController(text: unitName),
                    onChanged: (val) => unitName = val,
                  ),
                  const SizedBox(height: 24),
                  ElevatedButton.icon(
                    icon: const Icon(Icons.add, size: 20),
                    label: const Text("Додати рівень"),
                    onPressed: _addLevel,
                    style: ElevatedButton.styleFrom(
                      minimumSize: const Size(double.infinity, 40),
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                    ),
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      const Text("Колір лінії:"),
                      const SizedBox(width: 8),
                      GestureDetector(
                        onTap: () {
                          showDialog(
                            context: context,
                            builder: (context) => AlertDialog(
                              title: const Text('Оберіть колір'),
                              content: SingleChildScrollView(
                                child: ColorPicker(
                                  colors: const [
                                    Colors.blue,
                                    Colors.green,
                                    Colors.purple,
                                    Colors.orange,
                                    Colors.red,
                                    Colors.teal,
                                  ],
                                  onColorSelected: (color) {
                                    setState(() => lineColor = color);
                                    Navigator.pop(context);
                                  },
                                ),
                              ),
                            ),
                          );
                        },
                        child: Container(
                          width: 30,
                          height: 30,
                          decoration: BoxDecoration(
                            color: lineColor,
                            borderRadius: BorderRadius.circular(4),
                            border: Border.all(color: Colors.grey),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  ElevatedButton.icon(
                    icon: Icon(
                      isDrawingMode ? Icons.edit_off : Icons.polyline,
                      size: 20,
                    ),
                    label: Text(isDrawingMode ? "Вийти з режиму лінії" : "Режим малювання лінії"),
                    onPressed: () {
                      setState(() {
                        isDrawingMode = !isDrawingMode;
                        selectedElementId = null;
                        selectedElementType = null;
                        _lastPointPosition = null;
                      });
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: isDrawingMode ? Colors.blue[100] : null,
                      minimumSize: const Size(double.infinity, 40),
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                    ),
                  ),
                  const SizedBox(height: 16),
                  if (selectedElementId == 'point')
                    ElevatedButton.icon(
                      icon: const Icon(Icons.delete, size: 20),
                      label: Text("Видалити ${selectedElementType == 'point' ? 'точку' : 'щось :)'}"),
                      onPressed: _removeSelectedElement,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.red[100],
                        minimumSize: const Size(double.infinity, 40),
                        padding: const EdgeInsets.symmetric(horizontal: 12),
                      ),
                    ),
                  const SizedBox(height: 24),
                  //const SizedBox(height: 16),
                  ElevatedButton.icon(
                    icon: const Icon(Icons.code, size: 20),
                    label: const Text("Показати JSON"),
                    onPressed: _showUnitData,
                    style: ElevatedButton.styleFrom(
                      minimumSize: const Size(double.infinity, 40),
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                    ),
                  ),
                  const Divider(),
                  const SizedBox(height: 8),
                  const Text(
                    "Інструкція:",
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    "• Натисніть на рівень для переміщення\n"
                        "• Натисніть на рівень для керування\n"
                        "• Режим малювання: додає точки лінії\n"
                        "• Видаліть елемент кнопкою справа",
                    style: TextStyle(fontSize: 12, color: Colors.grey),
                  ),
                ],
              ),
            ),
          ),

          // Основная область с картой
          Expanded(
            child: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Color(0xFFE3F2FD), Color(0xFFF5F5F5)],
                ),
              ),
              child: Stack(
                children: [
                  // Линия соединения
                  _buildLineRenderer(),

                  // Область для добавления точек линии
                  GestureDetector(
                    onTapDown: (details) {
                      if (isDrawingMode) {
                        _addLinePoint(details.localPosition);
                      } else {
                        setState(() {
                          selectedElementId = null;
                          selectedElementType = null;
                        });
                      }
                    },
                    behavior: HitTestBehavior.opaque,
                    child: SingleChildScrollView(
                      controller: _scrollController,
                      scrollDirection: Axis.vertical,
                      child: Container(
                        key: _canvasKey,
                        height: canvasHeight,
                        padding: const EdgeInsets.only(bottom: 100),
                        child: Stack(
                          children: [
                            // Точки линии
                            for (int i = 0; i < linePoints.length; i++)
                              Positioned(
                                left: linePoints[i]['x'] - 8,
                                top: linePoints[i]['y'] - 8,
                                child: _buildLinePoint(linePoints[i], i),
                              ),

                            // Уровни
                            for (int i = 0; i < levels.length; i++)
                              Positioned(
                                left: levels[i]['x'] - 30,
                                top: levels[i]['y'] - 30,
                                child: Column(
                                  children: [
                                    _buildLevelItem(levels[i], i),
                                    const SizedBox(height: 8),
                                    Container(
                                      constraints: const BoxConstraints(maxWidth: 150),
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 8, vertical: 4),
                                      decoration: BoxDecoration(
                                        color: Colors.white.withOpacity(0.9),
                                        borderRadius: BorderRadius.circular(8),
                                        boxShadow: [
                                          BoxShadow(
                                            color: Colors.black.withOpacity(0.1),
                                            blurRadius: 2,
                                            offset: const Offset(0, 1),
                                          )
                                        ],
                                      ),
                                      child: Column(
                                        children: [
                                          Text(
                                            levels[i]['name'] ?? 'Новий рівень',
                                            style: const TextStyle(
                                              fontSize: 12,
                                              fontWeight: FontWeight.bold,
                                            ),
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                          const SizedBox(height: 2),
                                          Text(
                                            '${(levels[i]['lessons'] as List?)?.length ?? 0} уроків',
                                            style: TextStyle(
                                              fontSize: 10,
                                              color: Colors.grey.shade600,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                          ],
                        ),
                      ),
                    ),
                  ),

                  // Подсказка в режиме рисования
                  if (isDrawingMode)
                    Positioned(
                      bottom: 20,
                      left: 0,
                      right: 0,
                      child: Center(
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 16, vertical: 8),
                          decoration: BoxDecoration(
                            color: Colors.blue[700],
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: const Text(
                            'Режим малювання: клікайте на карту, щоб додати точки',
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class LineRendererPainter extends CustomPainter {
  final List<Map<String, dynamic>> linePoints;
  final Color lineColor;

  LineRendererPainter({
    required this.linePoints,
    required this.lineColor,
  });

  @override
  void paint(Canvas canvas, Size size) {
    if (linePoints.length < 2) return;

    final paint = Paint()
      ..color = lineColor
      ..strokeWidth = 3
      ..strokeCap = StrokeCap.round
      ..style = PaintingStyle.stroke
      ..strokeJoin = StrokeJoin.round;

    // Создаем пунктирный эффект
    final dashPaint = Paint()
      ..color = lineColor.withOpacity(0.5)
      ..strokeWidth = 3
      ..strokeCap = StrokeCap.round
      ..style = PaintingStyle.stroke
      ..strokeJoin = StrokeJoin.round;

    final path = Path();
    path.moveTo(linePoints[0]['x'], linePoints[0]['y']);

    for (int i = 1; i < linePoints.length; i++) {
      path.lineTo(linePoints[i]['x'], linePoints[i]['y']);
    }

    // Рисуем основную линию
    canvas.drawPath(path, paint);

    // Рисуем дополнительную линию для эффекта (без использования pathEffect)
    canvas.drawPath(path, dashPaint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}

class ColorPicker extends StatelessWidget {
  final List<Color> colors;
  final Function(Color) onColorSelected;

  const ColorPicker({
    super.key,
    required this.colors,
    required this.onColorSelected,
  });

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: colors
          .map((color) => GestureDetector(
        onTap: () => onColorSelected(color),
        child: Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(4),
            border: Border.all(color: Colors.grey),
          ),
        ),
      ))
          .toList(),
    );
  }
}

class LevelColors {
  final Color backgroundColor;
  final Color borderColor;
  final Color textColor;

  LevelColors({
    required this.backgroundColor,
    required this.borderColor,
    required this.textColor,
  });
}