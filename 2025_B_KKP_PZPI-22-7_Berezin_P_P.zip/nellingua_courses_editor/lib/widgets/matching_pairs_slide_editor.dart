import 'package:flutter/material.dart';

class MatchingPairsSlideEditor extends StatefulWidget {
  final int? initialSelectCount;
  final List<Map<String, String>>? initialMatchingPairs;

  const MatchingPairsSlideEditor({
    super.key,
    this.initialSelectCount,
    this.initialMatchingPairs,
  });

  @override
  State<MatchingPairsSlideEditor> createState() => _MatchingPairsSlideEditorState();
}

class _MatchingPairsSlideEditorState extends State<MatchingPairsSlideEditor> {
  late TextEditingController _selectCountController;
  List<Map<String, String>> _matchingPairs = [];

  @override
  void initState() {
    super.initState();
    _selectCountController = TextEditingController(
      text: widget.initialSelectCount?.toString() ?? '5',
    );
    if (widget.initialMatchingPairs != null) {
      _matchingPairs = List<Map<String, String>>.from(widget.initialMatchingPairs!);
    }
  }

  @override
  void dispose() {
    _selectCountController.dispose();
    super.dispose();
  }

  void _addPair() {
    setState(() {
      _matchingPairs.add({'first': '', 'second': ''});
    });
  }

  void _updatePair(int index, String key, String value) {
    setState(() {
      _matchingPairs[index][key] = value;
    });
  }

  void _removePair(int index) {
    setState(() {
      _matchingPairs.removeAt(index);
    });
  }

  void _saveSlide() {
    final selectCountText = _selectCountController.text.trim();
    if (selectCountText.isEmpty || _matchingPairs.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Додайте пари та вкажіть кількість для вибору')),
      );
      return;
    }

    final selectCount = int.tryParse(selectCountText);
    if (selectCount == null || selectCount <= 0 || selectCount > _matchingPairs.length) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Вкажіть коректну кількість пар (не більше, ніж створено пар)')),
      );
      return;
    }

    // Remove empty pairs
    _matchingPairs.removeWhere((pair) => pair['first']!.isEmpty || pair['second']!.isEmpty);

    if (_matchingPairs.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Додайте хоча б одну заповнену пару')),
      );
      return;
    }

    Navigator.pop(context, {
      'selectCount': selectCount,
      'matchingPairs': _matchingPairs,
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Редактор слайду "Збери пари"'),
        actions: [
          TextButton(
            onPressed: _saveSlide,
            child: const Text('Зберегти', style: TextStyle(color: Colors.blue)),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            TextField(
              controller: _selectCountController,
              decoration: const InputDecoration(
                labelText: 'Кількість пар для вибору',
                border: OutlineInputBorder(),
              ),
              keyboardType: TextInputType.number,
            ),
            const SizedBox(height: 20),
            const Text('Пари:', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            ..._matchingPairs.asMap().entries.map((entry) {
              final index = entry.key;
              final pair = entry.value;
              return Padding(
                padding: const EdgeInsets.only(bottom: 8.0),
                child: Row(
                  children: [
                    Expanded(
                      child: TextField(
                        decoration: const InputDecoration(
                          hintText: 'Перший елемент',
                          border: OutlineInputBorder(),
                        ),
                        onChanged: (value) => _updatePair(index, 'first', value),
                        controller: TextEditingController(text: pair['first']),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: TextField(
                        decoration: const InputDecoration(
                          hintText: 'Другий елемент',
                          border: OutlineInputBorder(),
                        ),
                        onChanged: (value) => _updatePair(index, 'second', value),
                        controller: TextEditingController(text: pair['second']),
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.delete, color: Colors.red),
                      onPressed: () => _removePair(index),
                    ),
                  ],
                ),
              );
            }),
            const SizedBox(height: 10),
            ElevatedButton.icon(
              icon: const Icon(Icons.add),
              label: const Text('Додати пару'),
              onPressed: _addPair,
            ),
          ],
        ),
      ),
    );
  }
}